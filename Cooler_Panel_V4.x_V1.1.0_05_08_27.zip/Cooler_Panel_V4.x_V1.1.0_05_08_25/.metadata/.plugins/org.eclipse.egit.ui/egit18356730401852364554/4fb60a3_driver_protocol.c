#include "driver_protocol.h"
#include "initialization.h"
#include "functions.h"
#include "business_logic.h"
#include "stm8l15x_it.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "variables.h"
#include "lcd_seg.h"
#include "adc_reading.h"
#include "stm8l15x_it.h"

//IMC parameters
#define NUMBER_OF_IMC_CODE_VERSIONS         2       // we currently have 2 code versions
#define APPID_OR_REGINDEX_SELECT            2       // choosing between app ip and register index
#define APP_ID                              0
#define REGISTER_INDEX                      1

#define NUMBER_OF_DRIVER_COMMAND_TYPE       16


//static uint8_t receivedByteCount = 0;
//uint8_t receivedBuffer[256];
uint8_t isPending = 0;
uint16_t pendingTime = 0;
uint8_t lastCommandBuffer[8];
uint8_t powerOffTryCnt = 0;
uint8_t queueBuffer[MAX_NUMBER_OF_CMDS][8];
uint16_t queueBufferTimeOut[MAX_NUMBER_OF_CMDS] = {0};     // values must be multiple of 50ms
uint8_t queueBufferDelay[MAX_NUMBER_OF_CMDS] = {0};        // values must be multiple of 100ms
uint16_t currentBufferSpentTime = 0;


DRV_PACKET packet;
DRV_StructTypeDef drvStruct = {.drvStat = DRV_STAT_NOT_INITED};

// This Lookup Table is made for IMC registers indexes according to the IMC code version
const uint8_t addressTable[NUMBER_OF_IMC_CODE_VERSIONS][NUMBER_OF_DRIVER_COMMAND_TYPE][APPID_OR_REGINDEX_SELECT] = 
{
//    PFC          valve        PUMP        FAULT          VTH        GPIO       CTRL_MODE  STOP_START_CMD TARGET_SPEED TARGET_TRQ TARGET_power SCRIPT_CMD  LOAD_PARAM_CMD  SAVE_PARAM_CMD  DRV_REG_LIMIT_FLAG  DCBUS_VLT
  {{0x03,0x52}, {0x34,0x41}, {0x04,0x70}, {0x00,0x00}, {0x01,0x90}, {0x34,0x40}, {0x01,0x04}, {0x01,0x78}, {0x01,0x79}, {0x01,0x81}, {0xF1,0x00}, {0x04,0x01}, {0x22,0x00}, {0x21,0x00}, {0xF1,0x04}, {0x1B,0x45}},  // version 1  {app id, regindex}
  {{0x03,0x42}, {0x34,0x41}, {0x34,0x41}, {0x00,0x00}, {0x01,0x4C}, {0x34,0x40}, {0xF1,0x02}, {0x01,0x40}, {0xF1,0x00}, {0xF1,0x00}, {0xF1,0x00}, {0x04,0x40}, {0x22,0x00}, {0x21,0x00}, {0xF1,0x04}, {0x1B,0x45}}   // version 2  {app id, regindex}
};

// This Lookup Table is made for IMC Commands Delay (these delay prevents the micro from sending next command of the queue to the imc for specified time) 
const uint8_t drvDelayTable[] = {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 200, 30, 30, 200}; // scale is ms
const DRV_REG controlMode[3] = {DRV_REG_SPEED, DRV_REG_TORQUE, DRV_REG_POWER};


extern App_State appState;
extern App_Settings appSettings;

//Private functions Prototype
uint16_t Drv_Percent_To_Value(uint16_t percentX2, uint16_t minPercentX10, uint16_t maxPercentX10);
uint8_t Drv_Value_To_Percent(uint32_t value, uint16_t minPercentX10, uint16_t maxPercentX10, uint8_t roundTo5Percent);
uint16_t Drv_Round_Percent(uint16_t percentX2);
uint16_t Drv_Generate_Data(DRV_REG reg, uint16_t regValue);
uint16_t Drv_Cal_CRC(uint8_t* buffer);
uint16_t Drv_Get_CRC(uint8_t* buffer);
void Drv_Generate_Packet(DRV_PACKET* packet);
DRV_REG Drv_Extract_Register(unsigned char* table);
void Drv_Fill_Analyze_Packet(unsigned char* buffer, DRV_PACKET* packet);
void Drv_Queue_Packet(DRV_PACKET* packet, uint16_t TimeOut, uint16_t Delay);
//void Drv_Fill_Generate_Send_Packet(DRV_PACKET* packet, DRV_CMD cmd, DRV_REG reg, uint16_t StatusOrValue);
void Drv_Send_Command_New(void);
unsigned char Drv_Is_Response_For_Command(void);
void Drv_Reset_Queue(void);
void Drv_Parse_Response();
unsigned int Drv_Calculate_Elapsed_Time(unsigned int startTime, unsigned int endTime);
unsigned char Drv_Is_Timeout_Passed(unsigned int endTime);
unsigned char Drv_Is_Delay_Passed(unsigned int endTime);


/**
 * @brief  scale percent (0~200) to value (0~4095)
 * 		   The 0 percent means min percent and 200 percent means max percent
 * @param  percentX2: the percent * 2
 * @param  minPercentX10: the minimum percent * 10
 * @param  maxPercentX10: the maximum percent * 10
 * @retval the value equivalent to the percent
 */
uint16_t Drv_Percent_To_Value(uint16_t percentX2, uint16_t minPercentX10, uint16_t maxPercentX10)
{
	uint16_t value = (uint32_t)percentX2 * (maxPercentX10 - minPercentX10) / 200 + minPercentX10;
	value = (uint32_t)value * 4095 / 1000;
	return value;
}


/**
 * @brief  scale value (0~4095) to percent (0~200)
 * 		   The 0 percent means min percent and 200 percent means max percent
 * @param  value
 * @param  minPercentX10: the minimum percent * 10
 * @param  maxPercentX10: the maximum percent * 10
 * @retval the percent * 2 equivalent to the value
 */
uint8_t Drv_Value_To_Percent(uint32_t value, uint16_t minPercentX10, uint16_t maxPercentX10, uint8_t roundTo5Percent)
{
  uint32_t percentX2;
  
  if((int16_t)value < 0) // if the spin is in reverse mode then multiply the returned value by -1
  {
    value = (uint32_t)((uint16_t)value*(-1));
  }
  
  if (value < (reg[SPEED_MIN_PERCENT_REG] * 4095 / 1000)) // if percent is below the minimum desired value for start
  {
    percentX2 = 0;
  }
  
  else
  {
    percentX2 = ((uint32_t)value * 1000 / 4095 - minPercentX10) * 200;
    percentX2 /= (maxPercentX10 - minPercentX10);

    if(percentX2 > 200)
    {
            percentX2 = 200;
    }
  }
  
  if(roundTo5Percent == ON) // round percentX2 to be multiply of 10 (2x5%)
  {
    if (((uint16_t)percentX2 % 10) >= 5)
      percentX2 += 5;
    percentX2 = (percentX2 / 10) * 10;
  }
  return (uint8_t)percentX2;
}


/**
 * @brief  round percent to be multiply of 10 (2x5%)
 * @param  percentX2: the percent * 2
 * @retval the rounded percent
 */
uint16_t Drv_Round_Percent(uint16_t percentX2)
{
	uint16_t roundedPercent = percentX2;
	if ((roundedPercent % 10) >= 5)
	{
		roundedPercent += 5;
	}
	roundedPercent = (roundedPercent / 10) * 10;
	return roundedPercent;
}


/**
 * @brief  Generate data that should be sent to driver according to register & its value
 * @param  drvReg: the name of the register,
 * @param  regValue: the status or value of the corresponding register
 * @retval the value equivalent to the status to be sent to the driver
 */
uint16_t Drv_Generate_Data(DRV_REG drvReg, uint16_t regValue)
{
  if (drvReg == (DRV_REG_PUMP || DRV_REG_PFC))
  {
    if(regValue == ON)
    {
            return 0x0010;
    }
    else
    {
            return 0x0000;
    }
  }
  else if (drvReg == DRV_REG_VALVE)
  {
    if(regValue == ON)
    {
            return 0x0020;
    }
    else
    {
            return 0x0000;
    }
  }
  else if(drvReg == DRV_REG_SCRIPT)
  {
    if(regValue == ENABLE)
    {
            return 0x0011;
    }
    else
    {
            return 0x0000;
    }
  }
  else if(drvReg == DRV_REG_STOP_START)
  {
    if(regValue == START)
    {
            return 0x0001;
    }
    else
    {
            return 0x0000;
    }
  }
  else if(drvReg == DRV_REG_SPEED) // for this command percent of speed in scale (2*percent)
  {
    if(regValue == 0)
    {
            return 0x0000;
    }
    uint16_t rpm = Drv_Percent_To_Value(regValue, reg[SPEED_MIN_PERCENT_REG], reg[SPEED_MAX_PERCENT_REG]);
    if(reg[MOTOR_SPIN_DIRECTION])
    {
            rpm *= -1;
    }
    return rpm;
  }
  else if((drvReg == DRV_REG_TORQUE) || (drvReg == DRV_REG_POWER))
  {
    if(regValue == 0)
    {
            return 0x0000;
    }
    uint16_t trq = Drv_Percent_To_Value(regValue, reg[TRQ_MIN_PERCENT], reg[TRQ_MAX_PERCENT]);
    if(reg[MOTOR_SPIN_DIRECTION])
    {
            trq *= -1;
    }
    return trq;
  }
  else
  {
          return regValue;
  }
}

/**
  * @brief  this function calculate the received buffer crc
  * @param  buffer: data buffer to be sent 
  * @retval none
  */
uint16_t Drv_Cal_CRC(uint8_t* buffer)
{
  uint32_t crc = 0;

  crc += buffer[0];
  crc += ((uint16_t)buffer[1]) << 8;
  crc += buffer[2];
  crc += ((uint16_t)buffer[3]) << 8;
  crc += buffer[4];
  crc += ((uint16_t)buffer[5]) << 8;
  crc = 65536 - crc;
  crc = ((crc & 0xff) << 8) + ((crc & 0xff00) >> 8);
  return (uint16_t)(crc & 0xffff);
}


/**
  * @brief  this function get the crc of received buffer
  * @param  buffer: data buffer which crc is extracted from it
  * @retval extracted CRC
  */
uint16_t Drv_Get_CRC(uint8_t* buffer)
{
	uint16_t crc = 0;

	crc = buffer[6];
	crc <<= 8;
	crc += buffer[7];
	return crc;
}

/**
  * @brief  this function fills the command buffer to be sent to the driver
  * @param  packet
  * @retval none
  */
void Drv_Generate_Packet(DRV_PACKET* packet)
{
  packet->buffer[0] = 0x01;
  packet->buffer[1] = packet->command;
  packet->buffer[2] = addressTable[reg[IMC_CODE_VERSION]][packet->regiser][APP_ID];
  packet->buffer[3] = addressTable[reg[IMC_CODE_VERSION]][packet->regiser][REGISTER_INDEX];
  packet->buffer[4] = lowByte(packet->data);
  packet->buffer[5] = highByte(packet->data);
  packet->crc = Drv_Cal_CRC(packet->buffer);
  packet->buffer[6] = highByte(packet->crc);
  packet->buffer[7] = lowByte(packet->crc);
}

DRV_REG Drv_Extract_Register(unsigned char* table)
{
  unsigned char i, j = reg[IMC_CODE_VERSION];
  DRV_REG reg = DRV_REG_NOPE;
  for(i=0;i<DRV_REG_NOPE;i++)
  {
    if(table[APP_ID] == addressTable[j][i][APP_ID] && table[REGISTER_INDEX] == addressTable[j][i][REGISTER_INDEX])
    {
      reg = (DRV_REG)i;
      break;
    }
  }
  return reg;
}

void Drv_Fill_Analyze_Packet(unsigned char* buffer, DRV_PACKET* packet)
{
    unsigned short crcCal;

    memcpy(packet->buffer, buffer, 8);
    packet->address = packet->buffer[0];
    packet->command = (DRV_CMD)packet->buffer[1];
    packet->table[0] = packet->buffer[2];
    packet->table[1] = packet->buffer[3];
    packet->regiser = Drv_Extract_Register(packet->table);
    packet->dataL = packet->buffer[4];
    packet->data = (packet->buffer[5] << 8) + packet->buffer[4];
    packet->crc = Drv_Get_CRC(packet->buffer);
    crcCal = Drv_Cal_CRC(packet->buffer);
    if(crcCal == packet->crc)
    {
      appState.globalSucceedPackets += 1;
      appState.localSucceedPackets += 1;
      packet->rcvFlag = DRV_RCV_PACKET_NEW;
    }
    else
    {
      appState.globalFailPackets += 1;
      appState.localFailPackets += 1;
      Drv_Set_Fault(CRC_Fault);
    }
}


/**
 * @brief  if the queue is made before this function put commands at end of the queue , or if the queue inst made ,this function sends one command to driver
 * @param  packet,TimeOut: maximum time out for receiving driver response to the corresponding command , Delay: scale (1 menas 100ms) delay for sending current command (ex: 2 means micro will send the current command to driver after 200 ms )
 * @retval none
 */
void Drv_Queue_Packet(DRV_PACKET* packet, uint16_t TimeOut, uint16_t Delay)
{
  if(drvStruct.queueCnt < MAX_NUMBER_OF_CMDS)
  {
    memcpy(drvStruct.queueBuf[drvStruct.queueCnt], packet->buffer, 8);
    drvStruct.queueBufTimeout[drvStruct.queueCnt] = TimeOut;
    drvStruct.queueBufDelay[drvStruct.queueCnt] = Delay;
    drvStruct.queueCnt++;
    Drv_Send_Command_New();
  }
}


/**
  * @brief  this function fills the driver packet
  * @param  packet, cmd: driver command like reading or writing or fault clearing or ..., reg: the address of register , data: data to be written in specific driver register
  * @retval none
  */
void Drv_Fill_Generate_Send_Packet(DRV_PACKET* packet, DRV_CMD cmd, DRV_REG drv_reg, uint16_t StatusOrValue)
{
  uint16_t delay;
  
  packet->command = cmd;
  packet->regiser = drv_reg;
  packet->data = Drv_Generate_Data(drv_reg, StatusOrValue);
  Drv_Generate_Packet(packet);
  //Delay Generation//
  if(cmd == DRV_CMD_NOPE)
    delay = StatusOrValue;
  else
    delay = drvDelayTable[drv_reg];
  /////////////////////
  Drv_Queue_Packet(packet, DRIVER_RESPONSE_TIMEOUT, delay);
}


/**
  * @brief  sets the driver power ON or OFF according to the input
  * @param  state: ON or OFF
  * @retval none
  */
void Drv_Power(uint8_t state)
{
  if (state == ON)  ///////////////////////////////////  for power on  ///////////////////////////////////
  {
    if(!appState.oneWirePhysicallyConnected)
    {
      Drv_Set_Fault(One_Wire_Disconnected);
      return;
    }
    else if(appState.acVoltageInRange != 1)
    {
      if(appState.acVoltageInRange == 2)
        Drv_Set_Fault(Ac_Voltage_Range_High);
      else // appState.acVoltageInRange == 0
        Drv_Set_Fault(Ac_Voltage_Range_Low);
      return;
    }
    if (drvStruct.drvStat == DRV_STAT_NOT_INITED)
    {
      CMDs_PWR(CMD_REL_PWR, ON);
      appState.powerRelayOn = 0x01;
      ///// Nope command as delay
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 500); //10*25 ms delay

      ///// clearing driver fault
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_CLEAR_STATUS, DRV_REG_FAULT, 0x0000);
      ///// loading parameter into driver ram
      if(reg[DRIVER_CONFIG_NUM] != 0)
        Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, reg[DRIVER_CONFIG_NUM]);

      ///// disable scripting if script_CMD parameter is 0
      if(reg[DRIVER_SCRIPT_EN] == DISABLE)
      {
        Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_SCRIPT, 0x0000);
      }

      ///// updatePumpStatus
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_PUMP, appState.pumpOn);
      
      ///// selecting driver mode (speed , toque, power)
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_CTRL_MODE_SELECT, reg[MOTOR_CONTROL_MODE]);
      
      // ToDo: This should be moved to Drv_Parse_Response
      drvStruct.drvStat = DRV_STAT_INITED;
    }

        
    ///// setting the speed command
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], Drv_Calculate_Percent());
    
    
    ///// start command 
    if(Drv_Calculate_Percent() != 0)
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, START);
  }
  
  else /////////////////////////////////// for power off ///////////////////////////////////
  {
    // setting the setpoint to zero
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], 0x0000);

    // stop command
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, STOP);
  }
}


/**
  * @brief  if mismatch current is detected in driver and lifeguard board is activated , this function is called in order to turn the driver power off
  * @param  none
  * @retval none
  */
// ToDo: should be moved to bussiness-logic library
void Drv_LifeGuard_Action()
{
  if(appSettings.parameterConfirmedValue[LIFE_GUARD_ENABLE - START_OF_PARAMS + 1])
  {
    delay_ms(1);
    unsigned char CLD = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3);
    if(!CLD)
    {
      CMDs_PWR(CMD_REL_PWR, OFF);
      appState.powerRelayOn = 0x00;
      reg[STATUS] |= RCCB; //RCCB status update
      appState.pendingOn = 0;
      drvStruct.queueInd = 0;
      drvStruct.queueCnt = 0;
      Drv_Set_Fault(Driver_Current_Mismatch);
    }
    else
      reg[STATUS] &= (0xFFFF - RCCB); //RCCB status update
  }
}


/**
  * first command : setting speed or trq to 0
  * second command : stopping motor
  * third command : changing mode command
  */
/**
  * @brief  this function change the driver mode(speed or torque) this function stops the motor before changing the mode if the motor is rotating.
  * @param  mode: DRIVER_SPEED_CTRL_MODE or DRIVER_CURRENT_CTRL_MODE
  * @retval none
  */
void Drv_Set_Ctrl_Mode(uint8_t mode)
{
  drvStruct.newPwrRelStat = ON;
  
//////stopping motor
  Drv_Power(OFF);
/////// Nope command as delay
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 250); //10*25 ms delay
////changing mode command  
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_CTRL_MODE_SELECT, mode);
///// Nope command as delay
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 50); //2*25 ms delay
}

/**
  * @brief  this function sets the motor speed or torque according to the input and the current driver mode(speed or torque)
  * @param  speed : desired motor speed or torque percent
  * @retval none
  */
void  Drv_Set_Speed(uint8_t speed)
{
  if ((((appState.actualSpeed != 0) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque != 0) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3))) && speed == 0)
  {
    drvStruct.newPwrRelStat = ON;
    Drv_Power(OFF);
    return;
  }
  else if ((((appState.actualSpeed == 0) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque == 0) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3))) && speed != 0)
  {
    Drv_Power(ON);
    return;
  }
  else if((((appState.actualSpeed == 0) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque == 0) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3))) && speed == 0)
  {
    return;
  }
  
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], (uint16_t)speed);
}

/**
  * @brief  this function set the motor speed direction according to the input (first the motor is stopped then it starts in desired direction)
  * @param  direction: demonstrates the motor spin direction
  * @retval none
  */
void Drv_Set_direction()
{
  drvStruct.newPwrRelStat = ON;
  
  Drv_Power(OFF);
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 1000); //40*25 ms delay
  Drv_Power(ON);
}


/**
  * @brief  this function set the driver and pannel fault according to the latest fault (this clears the previous faults)
  * @param  fault: the fault to be written in the fault register
  * @retval none
  */
void Drv_Set_Fault(Fault fault)
{
  appState.fault = fault;
  reg[FAULTS] = 0x00;
  reg[FAULTS + 1] = 0x00;
  if(fault > 16)
    reg[FAULTS + 1] = 1 << (fault-17);
  else
    reg[FAULTS] = 1 << fault;
}


/**
  * @brief  this function clears the fault and then restarts the driver
  * @param  none
  * @retval none
  */
void Drv_Clear_Fault_And_Restart()
{
  drvStruct.drvStat = DRV_STAT_NOT_INITED;
  Drv_Power(ON);
}


/**
  * @brief  this function LOADS specified parameter into driver RAM in order the driver to work with dedicated parameter
  * @param  ParameterSetNumber: the number of parameter block which driver is gonna work with
  * @retval none
  */
void Drv_Set_Parameter(uint16_t ParameterSetNumber)
{
  if(ParameterSetNumber != 0)
  {
    drvStruct.newPwrRelStat = ON;
    
    //// 1 :Stop command
    Drv_Power(OFF);
    //// 2 Nope command as delay
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 250); //10*25 ms delay
    //// 3:Loading parameter
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, ParameterSetNumber);
  }
}


/**
  * @brief  this function validates and extracts the received command response buffer and sends the rest of the commands
  * @param  pucBuffer: this input is received buffer which is validated and parsed in this function
  * @retval none
  */
void Drv_Handle_Reception(unsigned char *pucBuffer)
{
  DMA_RX_RECEPTION_RESET();
  Drv_Fill_Analyze_Packet(pucBuffer, &(drvStruct.rcvPkt)); // CRC CHECK IS INSIDE
  if(drvStruct.rcvPkt.rcvFlag == DRV_RCV_PACKET_NEW)       //IF CRC OK
  {
    drvStruct.rcvPkt.rcvFlag = DRV_RCV_PACKET_NO;
    Drv_Parse_Response();
    if(drvStruct.sendStat == DRV_SEND_STAT_WAIT_RESP && Drv_Is_Response_For_Command())
    {
      drvStruct.retryCnt = 0;
      if(drvStruct.queueBufDelay[drvStruct.queueInd] == 0)
      {
        drvStruct.queueInd++;
        drvStruct.sendStat = DRV_SEND_STAT_IDLE;
        Drv_Send_Command_New();
      }
      else
      {
        drvStruct.sendStat = DRV_SEND_STAT_WAIT_RUN;
        drvStruct.startTimeDelay = TIME_GetTime();
      }
    }

  }  
}

/**
  * @brief  this function checks the time passed after receving start cmd response, and if the time reaches to specefic value (like 5 sec) the check fualt is sent and if some specific faults are recevied : clear fault and start cmds are sent again
  * @param  none
  * @retval none
  */
void Drv_Start_Activity_Timeout()
{
  DRV_PACKET pkt;
  if(appState.drvStartTimeOut < DRIVER_CHECKFAULT_AFTER_START_TIMEOUT && appState.drvStartTimeOut > 0)
    appState.drvStartTimeOut += 1;
  else if(appState.drvStartTimeOut == DRIVER_CHECKFAULT_AFTER_START_TIMEOUT && drvStruct.queueCnt == 0)
  {
    Drv_Fill_Generate_Send_Packet(&pkt, DRV_CMD_READ_STATUS, DRV_REG_FAULT, 0x0000);
    appState.drvStartTimeOut += 1;
  }
}

/**
  * @brief  this function checks if a response to the previous command was received in the certain time then sends the rest of the commands
  * @param  none
  * @retval none
  */
void Drv_Handle_Timeout(void)
{
  unsigned int time;
  time = TIME_GetTime();
  if(drvStruct.sendStat == DRV_SEND_STAT_WAIT_RESP)
  {
    if(Drv_Is_Timeout_Passed(time))
    {
      drvStruct.retryCnt++;
      if(drvStruct.retryCnt < DRIVER_RESPONSE_MAX_RETRY_COUNT)
      {
        appState.globalFailPackets += 1;
        appState.localFailPackets += 1;
        drvStruct.sendStat = DRV_SEND_STAT_IDLE;
        Drv_Send_Command_New();
      }
      else
      {
        drvStruct.retryCnt = 0;
        if(appState.fault != Driver_Current_Mismatch)
        {
          Drv_Set_Fault(Timeout_Fault);
        }
      
        if(appSettings.settingModeEnable && appSettings.waitingForDrvResponse)
        {
          appSettings.parameterValue[appSettings.currentParameter] = appSettings.parameterConfirmedValue[appSettings.currentParameter];
          appSettings.waitingForDrvResponse = 0;
        }
        
        if(reg[FIRST_BOOT_FLAG_AFTER_POWERON] && appState.pendingOn)        
        {
          CMDs_PWR(CMD_REL_PWR, OFF);
          appState.powerRelayOn = 0x00;
          reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
          appState.powerOn = 0;
          appState.pendingOn = 0;
          reg[POWER] = appState.powerOn;
          eepromWriteData(POWER, (uint8_t*)&reg[POWER], 2);
        }
        
        Drv_Reset_Queue();
        
        if(appState.pendingOff && appSettings.keyPowerPressFlag)
        {
          powerOffTryCnt++;
          appSettings.keyPowerPressFlag = 0;
        }
        if(powerOffTryCnt >= MAX_POWER_OFF_TRY_COUNT)
        {
          powerOffTryCnt = 0;
          CMDs_PWR(CMD_REL_PWR, OFF);
          appState.powerRelayOn = 0x00;
          appState.powerOn = OFF;
          reg[POWER] = OFF;
          eepromWriteData(POWER, (uint8_t*)&reg[POWER],2);
          appState.pendingOn = 0;
          appState.pendingOff = 0;
          drvStruct.drvStat = DRV_STAT_NOT_INITED;
          if(appState.fault == Driver_Current_Mismatch)
          {
            Drv_Set_Fault(No_Fault);
          }
        }
      }
    }
  }
  else if(drvStruct.sendStat == DRV_SEND_STAT_WAIT_RUN)
  {
    if(Drv_Is_Delay_Passed(time))
    {
      drvStruct.queueInd++;
      drvStruct.sendStat = DRV_SEND_STAT_IDLE;
      Drv_Send_Command_New();
    }
  }
  else if(drvStruct.sendStat == DRV_SEND_STAT_ERROR_BUSY)
  {
    // ToDo: the number of send tries should be counted
    drvStruct.sendStat = DRV_SEND_STAT_IDLE;
    Drv_Send_Command_New();
  }
}

unsigned int Drv_Calculate_Elapsed_Time(unsigned int startTime, unsigned int endTime)
{
	unsigned int elapsedTime;
	if(endTime > startTime)
	{
		elapsedTime = endTime - startTime;
	}
	else
	{
		elapsedTime = 0xFFFFFFFF - startTime + endTime;
	}
	return elapsedTime;
}

unsigned char Drv_Is_Timeout_Passed(unsigned int endTime)
{
	drvStruct.elapsedTimeTimeout = 10*Drv_Calculate_Elapsed_Time(drvStruct.startTimeTimeout, endTime); // *10 : due to time scale is 10ms
	if(drvStruct.elapsedTimeTimeout >= drvStruct.queueBufTimeout[drvStruct.queueInd])
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

unsigned char Drv_Is_Delay_Passed(unsigned int endTime)
{
	drvStruct.elapsedTimeDelay = 10*Drv_Calculate_Elapsed_Time(drvStruct.startTimeDelay, endTime); // *10 : due to time scale is 10ms
	if(drvStruct.elapsedTimeDelay >= drvStruct.queueBufDelay[drvStruct.queueInd])
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

/**
  * @brief this function will sends driver the commands queued in the buffer
  * @param  pucBuffer: the 8-byte command pointer is given to be sent via uart channel 1
  * @retval none
  */
void Drv_Send_Command_New(void)
{
  unsigned char sendStart;
  if(drvStruct.sendStat == DRV_SEND_STAT_IDLE)
  {
    if(drvStruct.queueInd < drvStruct.queueCnt)
    {
      if(drvStruct.queueBuf[drvStruct.queueInd][1] == DRV_CMD_NOPE)
      {
              drvStruct.startTimeDelay = TIME_GetTime();
              drvStruct.sendStat = DRV_SEND_STAT_WAIT_RUN;
      }
      else
      {
        DMA_RX_RECEPTION_RESET();
        sendStart = UART1_Send_DMA((char*)&drvStruct.queueBuf[drvStruct.queueInd], 8);
        if(sendStart == 1)
        {
                drvStruct.sendStat = DRV_SEND_STAT_SENDING;
        }
        else
        {
                drvStruct.sendStat = DRV_SEND_STAT_ERROR_BUSY;
        }

      }
    }
    else
    {
            Drv_Reset_Queue();
    }
  }
}

void Drv_Handle_Send(void)
{
  drvStruct.sendStat = DRV_SEND_STAT_WAIT_RESP;
  drvStruct.startTimeTimeout = TIME_GetTime();
}

unsigned char Drv_Is_Response_For_Command(void)
{
  if(drvStruct.rcvPkt.buffer[1] == (drvStruct.queueBuf[drvStruct.queueInd][1]+ 0x80))
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

void Drv_Reset_Queue(void)
{
  drvStruct.sendStat = DRV_SEND_STAT_IDLE;
  drvStruct.queueInd = 0;
  drvStruct.queueCnt = 0;
}

/**
  * @brief  this function extracts the received buffer and operates the needed functionalities such as(updating registers , turning on or off the driver, clearing faults and ect)
  * @param  buffer: the received buffer to be extracted
  * @retval none
  */
void Drv_Parse_Response(void)
{
//   do actions
  if (drvStruct.rcvPkt.command == DRV_RSP_CLEAR_STATUS)
  {
    Drv_Set_Fault(No_Fault);
  }
  else if (drvStruct.rcvPkt.command == DRV_RSP_READ)
  {
    if(drvStruct.rcvPkt.regiser == DRV_REG_VTH) // Driver Temp Calculation
    {
      float driverTemp = Drv_Calculate_Ntc_Temp(drvStruct.rcvPkt.data);
      
      if(appState.driverActualTemp == 0)
        appState.driverActualTemp = driverTemp;
      appState.driverActualTemp = 0.8*appState.driverActualTemp + 0.2*driverTemp + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0);
    }
    else if(drvStruct.rcvPkt.regiser == DRV_REG_LIMIT_FLAG)
    {
      appState.limitFlag = drvStruct.rcvPkt.dataL;
    }
    else if(drvStruct.rcvPkt.regiser == DRV_REG_DC_BUS_VOLTAGE)
    {
      appState.driverDcBusVoltage = drvStruct.rcvPkt.data*10;
      appState.driverDcBusVoltage /= 61;
      if(appState.driverDcBusVoltage < DC_BUS_VOLTAGE_LOWER_HAZARD || appState.driverDcBusVoltage > DC_BUS_VOLTAGE_UPPER_HAZARD)
        Buzzer_Operation(Valve);
    }
  }
  
  else if (drvStruct.rcvPkt.command == DRV_RSP_WRITE)
  {
    // pump
    if (drvStruct.rcvPkt.regiser == DRV_REG_PUMP)
    {
      if (drvStruct.rcvPkt.dataL == 0x20) //valve on
      {
        appState.valveOn = 1;
        appState.valveTimeout = 0;
        appState.pumpOn = 0;
        reg[PUMP] = 0;
        
      }
      else if (drvStruct.rcvPkt.dataL == 0x10) // pump on       former value was :0x27
      {
        appState.valveOn = 0;
        appState.valveTimeout = 0;
        appState.pumpOn = 1;
        reg[PUMP] = 1;
      }
      else if (drvStruct.rcvPkt.dataL == 0x00) //both off       former value was :0x28
      {
        appState.valveOn = 0;
        appState.valveTimeout = 0;
        appState.pumpOn = 0;
        reg[PUMP] = 0;
      }
      appState.pumpFlag = 1;
      LCD_Glass_Update_By_State();
      eepromWriteData(PUMP, (uint8_t*)&reg[PUMP], 2);
    }
    // power
    else if (drvStruct.rcvPkt.regiser == DRV_REG_STOP_START)
    {
      if (drvStruct.rcvPkt.dataL == 0x0) // motor stopped
      {
        if (drvStruct.newPwrRelStat == OFF)
        {
          if(appState.fault == Driver_Current_Mismatch)
          {
            Drv_Set_Fault(No_Fault);
          }
          appState.powerOn = 0;
          reg[POWER] = 0;
          appState.pendingOff = 0;
          appSettings.keyPowerPressFlag = 0;
          powerOffTryCnt = 0;
          
          appState.timerChangingTimeout = 0;
          appState.dayTimeOff = -1;
          
          CMDs_PWR(CMD_REL_PWR, OFF);
          appState.powerRelayOn = 0x00;
          
          drvStruct.drvStat = DRV_STAT_NOT_INITED;
        }
        drvStruct.newPwrRelStat = OFF;
        appState.actualSpeed = 0;
        appState.actualTorque = 0;
      }
      else if (drvStruct.rcvPkt.dataL == 0x1) // motor started
      {
        appState.powerOn = 1;
        reg[POWER] = 1;
        appState.pendingOn = 0;
        reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
        appState.dayTimeOn = -1;
        appState.drvStartTimeOut = 1;
      }
      
      updateTempOffsetTimeOut();
      LCD_Glass_Update_By_State();
      eepromWriteData(POWER, (uint8_t*)&reg[POWER], 2);
    }
    // pfc
    else if (drvStruct.rcvPkt.regiser == DRV_REG_PFC)
    {
      if (drvStruct.rcvPkt.dataL == 0x1)
      {
        appState.pfcOn = 1;
        reg[PFC] = 1;
      }
      else if (drvStruct.rcvPkt.dataL == 0x0)
      {
        appState.pfcOn = 0;
        reg[PFC] = 0;
      }
      eepromWriteData(PFC, (uint8_t*)&reg[PFC], 2);
    }
    // speed
    else if(drvStruct.rcvPkt.regiser == DRV_REG_SPEED || drvStruct.rcvPkt.regiser == DRV_REG_TORQUE || drvStruct.rcvPkt.regiser == DRV_REG_POWER)
    {
      uint32_t value = drvStruct.rcvPkt.data;
      uint8_t percent = 0;
      
      if(appState.powerOn)
      {
        if ((controlMode[reg[MOTOR_CONTROL_MODE]-1] == DRV_REG_SPEED))
        {
          percent = Drv_Value_To_Percent(value, reg[SPEED_MIN_PERCENT_REG], reg[SPEED_MAX_PERCENT_REG], ON);
          appState.actualSpeed = percent;
          reg[SPEED] = appState.actualSpeed;
        }
         else if((controlMode[reg[MOTOR_CONTROL_MODE]-1] == DRV_REG_TORQUE) || (controlMode[reg[MOTOR_CONTROL_MODE]-1] == DRV_REG_POWER))
         {
           percent = Drv_Value_To_Percent(value, reg[TRQ_MIN_PERCENT], reg[TRQ_MAX_PERCENT], ON);
           appState.actualTorque = percent;
           reg[TORQUE] = appState.actualTorque;
         }
      }
      updateTempOffsetTimeOut();
        
      if (value || drvStruct.newPwrRelStat && appState.autoMode == 0)
      {
        appState.speedSetPoint = (uint8_t)percent;
        appState.speedSetpointFlag = 1;
        reg[SPEED_SETPOINT] = appState.speedSetPoint;
        eepromWriteData(SPEED_SETPOINT, (uint8_t*)&reg[SPEED_SETPOINT], 2);
        LCD_Glass_Update_By_State();
      }
      reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
    }
    //Motor Ctrl Mode
    else if(drvStruct.rcvPkt.regiser == DRV_REG_CTRL_MODE_SELECT)
    {
      if(drvStruct.rcvPkt.dataL == 0x01 || drvStruct.rcvPkt.dataL == 0x02 || drvStruct.rcvPkt.dataL == 0x03)
      {
        appSettings.parameterConfirmedValue[MOTOR_CONTROL_MODE - START_OF_PARAMS + 1] = appSettings.parameterValue[MOTOR_CONTROL_MODE - START_OF_PARAMS + 1];
        reg[MOTOR_CONTROL_MODE] = appSettings.parameterConfirmedValue[MOTOR_CONTROL_MODE - START_OF_PARAMS + 1];
        eepromWriteData(MOTOR_CONTROL_MODE, (uint8_t*)&reg[MOTOR_CONTROL_MODE], 2);
        appSettings.waitingForDrvResponse = 0;
      }
    }
    //SCRIPT_COMMAND
    else if(drvStruct.rcvPkt.regiser == DRV_REG_SCRIPT)
    {
      if(drvStruct.rcvPkt.dataL == 0x11)
        appSettings.parameterValue[DRIVER_SCRIPT_EN - START_OF_PARAMS + 1] = 1;        
      else if(drvStruct.rcvPkt.dataL == 0x00)
       appSettings.parameterValue[DRIVER_SCRIPT_EN - START_OF_PARAMS + 1] = 0;
      
      appSettings.parameterConfirmedValue[DRIVER_SCRIPT_EN - START_OF_PARAMS + 1] = appSettings.parameterValue[DRIVER_SCRIPT_EN - START_OF_PARAMS + 1];
      reg[DRIVER_SCRIPT_EN] = appSettings.parameterConfirmedValue[DRIVER_SCRIPT_EN - START_OF_PARAMS + 1];
      eepromWriteData(DRIVER_SCRIPT_EN, (uint8_t*)&reg[DRIVER_SCRIPT_EN], 2);
    }
  }
  //parameter loading and saving
  else if ((drvStruct.rcvPkt.command == DRV_RSP_LOAD_PARAM) && appSettings.settingModeEnable)
  {
    if(drvStruct.rcvPkt.regiser == DRV_REG_LOAD_PARAM)
    {
      if(drvStruct.rcvPkt.dataL == 0x00)
      {
        appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1] = appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
        reg[DRIVER_CONFIG_NUM] = appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
        eepromWriteData(DRIVER_CONFIG_NUM, (uint8_t*)&reg[DRIVER_CONFIG_NUM], 2);
      }
      else if(drvStruct.rcvPkt.dataL == 0x01 ||drvStruct.rcvPkt.dataL == 0x02)
      {
        appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1] = appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
        reg[DRIVER_CONFIG_NUM] = appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
        LCD_Glass_Update_By_State();
      }
      appSettings.waitingForDrvResponse = 0;
    }
//    if(drvStruct.rcvPkt.regiser == DRV_REG_SAVE_PARAM)
//    {
//    }
  }
  else if (drvStruct.rcvPkt.command == DRV_RSP_READ_STATUS)
  {
    if(appState.fault != Driver_Current_Mismatch)
    {
      uint16_t faults = drvStruct.rcvPkt.data;
      reg[FAULTS] = faults;
      
      if (faults == 0)
      {
        appState.fault = No_Fault;
      }
      else
      {
        for (int i = 0; i < 16; i++)
        {
          if (faults & (1 << i))
          {
            appState.fault = (Fault)(i + 1);
            break;
          }
        }
      }
      if(appState.drvStartTimeOut == DRIVER_CHECKFAULT_AFTER_START_TIMEOUT + 1)
      {
        appState.drvStartTimeOut = 0;
        
        if(faults && appState.drvStartTry < MAX_DRV_START_RETRY && appState.powerOn == ON)
        {
          drvStruct.drvStat = DRV_STAT_NOT_INITED;
          Drv_Power(ON);
          appState.drvStartTry ++;
        }
        else
        {
          appState.drvStartTry = 0;
        }
      }
    }
  }
}

/**
  * @brief  Calculate the driver temperature according to adcAvg value recieved from driver ntc
  * @param  buffer: recieved 2byte driver ntc data
  * @retval return the calculated temp
  */
float Drv_Calculate_Ntc_Temp(uint16_t buffer)
{
  float vlt, res ;
  vlt = ((float)buffer) * 5/4096;
  res = (1000.0 * vlt) / (5 - vlt);
  return interpolateTemp(res);
}

/**
  * @brief  generating jason as payload for the esp to be sent to site
  * @param  none
  * @retval return the pointer of payload
  */
char* Payload_Generator()
{
  static char payload[75];
  memset(payload, 0, sizeof(payload));
  
  strcat(payload, "{");
  //////////    subscribed variables    //////////
  if(appState.autoFlag)
  {
    sprintf(payload + strlen(payload), "\"mode\":%d,",appState.autoMode);
    appState.autoFlag = 0;
  }
  else if(appState.pumpFlag)
  {
    sprintf(payload + strlen(payload), "\"pump\":%d,",appState.pumpOn);
    appState.pumpFlag = 0;
  }
  else if(appState.powerFlag)
  {
    sprintf(payload + strlen(payload), "\"power\":%d,",appState.powerOn);
    appState.powerFlag = 0;
  }
  else if(appState.speedSetpointFlag)
  {
    sprintf(payload + strlen(payload), "\"sstp\":%d,", appState.speedSetPoint/2);
    appState.speedSetpointFlag = 0;
  }
  else if(appState.tempSetpointFlag)
  {
    sprintf(payload + strlen(payload), "\"tstp\":%.1f,", (float)appState.tempSetPoint/2);
    appState.tempSetpointFlag = 0;
  }
  //////////////////////////////////////////////////////////
  
  //////////  status: pwr,pmp,mde,spd,temp,fault  //////////
  sprintf(payload + strlen(payload), "\"pwr\":%d,\"mde\":%d,\"pmp\":%d,", appState.powerOn, appState.autoMode, appState.pumpOn); //,\"timer\":%.2f, ((appState.dayTimeOff - appState.nowTime - 1)/3600)
  
  if(reg[MOTOR_CONTROL_MODE] == 1)
    sprintf(payload + strlen(payload), "\"spd\":%d,", appState.actualSpeed/2);
  else if(reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)
    sprintf(payload + strlen(payload), "\"spd\":%d,", appState.actualTorque/2);
  
  sprintf(payload + strlen(payload), "\"offset\":%.2f,\"temp\":%.2f",appState.tempOffset, appState.actualTemp); // ,\"flt\":%d,\"dsn\":%d     , appState.fault, appState.disNum
  //////////////////////////////////////////////////////////
  strcat(payload, "}");

  return payload;  // No need to free(), but data may be overwritten in next call
}

char* Payload_Deinit_Generator()
{
  static char payload[75];
  memset(payload, 0, sizeof(payload));
  
  strcat(payload, "{");
  sprintf(payload + strlen(payload), "\"power\":%d,\"mode\":%d,\"pump\":%d,", appState.powerOn, appState.autoMode, appState.pumpOn); //,\"timer\":%.2f, ((appState.dayTimeOff - appState.nowTime - 1)/3600)
  sprintf(payload + strlen(payload), "\"sstp\":%d", appState.speedSetPoint/2);
  strcat(payload, "}");

  return payload;  // No need to free(), but data may be overwritten in next call
}

void Drv_AcInRange_Check(void)
{
  if(appState.acVoltageInRange != 1)
  {
    if(appState.powerRelayOn)
    {
      CMDs_PWR(CMD_REL_PWR, OFF);
      appState.powerRelayOn = 0;
    }
    if(appState.acVoltageInRange == 2)
    {
      Drv_Set_Fault(Ac_Voltage_Range_High);
    }
    else
    {
      Drv_Set_Fault(Ac_Voltage_Range_Low);
    }
  }
  else if((appState.acVoltageInRange == 1) && appState.powerOn && !appState.powerRelayOn)
  {
    Drv_Power(ON);
  }
  if(appState.acVoltageInRange == 1)
    reg[FAULTS+1] &= (0xFFFF - ((1 << (Ac_Voltage_Range_High - 17)) | (1 << (Ac_Voltage_Range_Low - 17))) );
}

//////////// some get and set functions ////////////

uint8_t Drv_Get_Queue_Command_Cnt(void)
{
  return drvStruct.queueCnt;
}

uint8_t Drv_Get_is_Pending(void)
{
  return isPending;
}

float Drv_Get_Actual_Temp(void)
{
  return appState.driverActualTemp;
}

uint8_t Get_Timer_Changing_TimeOut(void)
{
  return appState.timerChangingTimeout;
}

uint8_t Get_Wifi_Auto_Connect(void)
{
  return appSettings.parameterConfirmedValue[WIFI_AUTO_CONNECT - START_OF_PARAMS + 1];
}

void Drv_Set_oneWirePhysicallyConnected(uint8_t newval)
{
  appState.oneWirePhysicallyConnected = newval;
  if(newval == 0x01)
    reg[STATUS] |= OW_CONNECT;  //OW connection status update
  else if(newval == 0x00)
    reg[STATUS] &= (0xFFFF - OW_CONNECT); //OW connection status update
}

void Drv_Set_acVoltageInRange(uint8_t newval)
{
  appState.acVoltageInRange = newval;
  if(newval == 0x00)
  {
    reg[STATUS] |= AC_VLT_LOW; //LOW AC voltage status update
    reg[STATUS] &= (0xFFFF - AC_VLT_HIGH);
  }
  else if(newval == 0x02)
  {
    reg[STATUS] |= AC_VLT_HIGH; //HIGH AC voltage status update
    reg[STATUS] &= (0xFFFF - AC_VLT_LOW);
  }
  else if (newval == 0x01)
    reg[STATUS] &= (0xFFFF - (AC_VLT_HIGH | AC_VLT_LOW)); //AC voltage in range status update
}

