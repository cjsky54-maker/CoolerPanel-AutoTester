/*
 * esp8266.h
 *
 *  Created on: Jun 5, 2024
 *      Author: amirhossein nikzamir
 */
 
#ifndef ESP8266_H_
#define ESP8266_H_

#include "stm8l15x_conf.h"

//wifi model : ESP8266 , , .
#define ESP8266

//CONNECTION
#define DISCONNECTED	                0
#define CONNECTED		        1

// Commands
#define AT_NO_CMD		        ""

#define CHECK_UART_CONFIG               "UART_CUR?"
#define SET_UART_CONFIG                 "UART_CUR"

#define CHECK_SLEEP_MODE                "SLEEP?"
#define SET_SLEEP_MODE                  "SLEEP"

#define AT_TEST                         "AT"
#define WF_RESET_CMD                    "RST"
#define AT_WF_GET_VERSION               "GMR"

#define SET_WIFI_MODE                   "CWMODE_DEF"
#define CHECK_WIFI_MODE                 "CWMODE_DEF?"
  
#define AT_CWLAP_CONFIG                 "CWLAPOPT"
#define LIST_AVAILABLE_APS              "CWLAP"

#define CONNECT_TO_WIFI                 "CWJAP_DEF"
#define CHECK_CONNECTED_WIFI            "CWJAP_DEF?"
#define DISCONNECT_FROM_WIFI            "CWQAP"
   
#define GET_IP_ADDRESS                  "CIFSR"
#define CONNECTION_STATUS               "CIFSR"
#define SET_AUTO_CONNECT_TO_WIFI        "CWAUTOCONN"
#define CHECK_AUTO_CONNECT_TO_WIFI      "CWAUTOCONN?"
#define SET_SOFTAP_MODE_CONFIG          "CWSAP_DEF"
#define CHECK_SOFTAP_MODE_CONFIG        "CWSAP_DEF?"
#define CHECK_MULTIPLE_CONNECTION       "CIPMUX?"
#define SET_MULTIPLE_CONNECTION         "CIPMUX"

#define TCP_SERVER                      "CIPSERVER" //if data is 1 tcp server is started and if data is 0 tcp server is closed
#define STOP_TCP_SERVER                 "CIPCLOSE"

#define CIP_START                       "CIPSTART" // Ex : AT+CIPSTART="TCP","industrial.api.ubidots.com",1883,0<CR><LF> (connection type, target ip, port, 
#define CIP_CLOSE                       "AT+CIPCLOSE"//

#define SET_DATA_SEND_CONFIG            "CIPSEND"
#define SEND_DATA                       ""

#define AT_ECHO                         "E" // if data is 1 echo is on and if data is 0 the echo is turned off



#define WIFI_BAUD                       115200
#define NUMBER_OF_ROWS                  2    
#define NUMBER_OF_COLUMNS               249+1   // max : 149+1 // minimum should be 47(other chars) + 33(selected ssid) + 30(given password) = 110
#define MAX_API_LENGTH                  33
#define MAX_PASS_LENGTH                 30
#define MAX_NUMBER_OF_APIS              9

#define PUBLISH                         0
#define SUBSCRIBE                       1

#define ESP_SENDING_DATA_TIMEOUT        2*4     // in the scale of 4 (2*4 -> 2 sec)
#define ESP_SSID_RECONNECT_TIMEOUT      20*4    // in the scale of 4 (20*4 -> 20 sec)
#define ESP_CONNCET_ACK_FAILURE_TIMEOUT 25*4    // in the scale of 4 (25*4 -> 25 sec)

//const unsigned char wifiConfig_Base_Html[] = "<html>\r\n<head>\r\n  <style>\r\n    body {\r\n      display: flex;\r\n      justify-content: center;\r\n      align-items: flex-start;\r\n      height: 100vh;\r\n      margin: 0;\r\n      font-family: Arial, sans-serif;\r\n    }\r\n    .container {\r\n      text-align: center;\r\n      border: 1px solid #ccc;\r\n      padding: 20px;\r\n      border-radius: 10px;\r\n      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\r\n      margin-top: 150px;\r\n    }\r\n  </style>\r\n</head>\r\n<body>\r\n  <div class=\"container\">\r\n    <h2>Wi-Fi Configuration</h2>\r\n    <form action=\"/wifi_config\" method=\"get\">\r\n      SSID: \r\n      <select name=\"ssid\">\r\n        %s\r\n      </select><br><br>\r\n      Password: <input type=\"text\" name=\"pass\"><br><br>\r\n      <input type=\"submit\" value=\"connect\">\r\n    </form>\r\n  </div>\r\n</body>\r\n</html>";


   
typedef enum {
    WIFI_MODE_IDLE = 0,
    WIFI_MODE_LINE,       // Waiting for '\n'
    WIFI_MODE_IPD_LEN,    // Parsing +IPD length
    WIFI_MODE_IPD_DATA    // Receiving TCP data
} WIFI_Mode;

typedef enum {
  RECEPTION_BUSY = 7,
  RECEPTION_NON_AT_CMD_RESPONSE = 6,
  RECEPTION_OK = 5,
  RECEPTION_ERROR = 4,
  RECEPTION_FAIL = 3,
  RECEPTION_READY = 2,
  RECEPTION_TIMEOUT = 1,
  RECEPTION_NONE = 0
}ReceptionStatus;

typedef enum {
  SPEED_TYPE_SETPOINT,
  TEMPERATURE_TYPE_SETPOINT
}SetpointType;

//typedef enum {
//  SENDING_SUBSCRIBE = 3,
//  SENDING_PUBLISH = 2,
//  SENDING_CONNECT = 1,
//  SENDING_NONE = 0
//}DataSendingMode;

//typedef enum {
//  none = 0,
//  connecting_timeout = 1,
//  wrong_password = 2,
//  target_ap_not_found = 3,
//  connect_fail = 4,
//  connected = 5
//}NetworkConnectionError;

typedef struct
{
	char atCommand[25];			        // The AT command sent to the module
	char data[65];                                  // Data to be sent inside the command
//        unsigned char targetconnectionStatus;		// Show connection to mobile
        unsigned char needForAutoConnectSet;
        unsigned char wifiAutoConnect;
        unsigned char targetRequestsHtml;
        unsigned char targetRequestsConfig;
        unsigned char targetRequestsDisconnect;
        unsigned char targetConnectionId;
        unsigned char siteLinkIdConnection;
        unsigned char wificonnectionstatus;             // Show module connection to network
        unsigned char needForConnectToSsid;             // if this variable becomes 1: the esp will be connect to previous wifi
        unsigned char needForDisconnectFromSsid;        // if this variable becomes 1: the esp will be disconnected from current wifi
        unsigned char serverConnection;                 // shows if esp is connected to the target website(like ubidot)
        unsigned char connAckPacketReception;           //if 1: the connection acknowledgement is received and the connection is acceted
        unsigned char connAckPacketTimeout;
        unsigned char subAckPacketReception;            //if 1: the subscription acknowledgement is received and the subscription is acceted
        unsigned char cmdReceived;                      //when the server cmd is received this flag becomes 1 and when the cmd oparetion is done this will become 0
        unsigned char powerKey;
        unsigned char pumpKey;
        unsigned char modeKey;
        unsigned char spdSetPoint;
        unsigned char tmpSetPoint; //in the scale of 2X
        unsigned char upKey;
        unsigned char downKey;
        unsigned char wifiSendingDataTimer;         // if server connection is stablished and connackpacket is received correctly this timer will be counted and each 2 sec data (like temp , speed ...) is sent to server which esp is connected to
        unsigned char cipMux;                           //if 1: multiple connection is activated  and if 0 : multiple connection is deactivated
        unsigned char EspMode;                                  //1 = station mode  2 = softAp mode  3 = softAP + station mode
        unsigned char EspNamePassConfiged;                 // if the name and password of the esp is configed correctly this variable is 1 else it is 0
//        unsigned char powerstatus;                      // Shows if the module is correctly communicating with the micro and responding to at commands 
	unsigned char sendingAtCmd;			// Should be set for commands that return sth other than OK and should be cleared as soon as possible to avoid conflicting with receiving mobile packets
	char txBuffer[100];
//        char rxBuffer[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];       // response of module after sending AT command
	char apiRxBuffer[2][NUMBER_OF_COLUMNS];
        char extractMode;
        char ssids[9][33];
        char selectedSsid[MAX_API_LENGTH];
        char connectedSsid[MAX_API_LENGTH];
        char receivedPassword[MAX_PASS_LENGTH];
        unsigned char apiRow;
        unsigned char apiCol;
        unsigned char apiReceived;
	unsigned char receivedRow;                              // number of recieved rows
        WIFI_Mode mode;		        			// reception mode
	unsigned short length[NUMBER_OF_ROWS];			// length of received response
	unsigned char receptionComplete;                        // if ok "OK\r\n" or "ERROR\r\n" is recieved as the last line then packet reception is completed
        ReceptionStatus receptionStatus;                        // the status is either OK or ERROR
        
} WIFI_STATUS;

void Esp_1Byte_Reception_Handler(unsigned char data);
void Esp_Main_Handler();
void EspPower(unsigned char state);
void Esp_Request_Internet_Connection_Html_Page();
void Esp_Request_Connect_To_Internet_Config();
void Esp_Request_Disconnect_From_Internet();
void Esp_Wifi_Connected_Operation();
void Esp_Wifi_Not_Connected_Operation();
void Esp_Auto_Connect_To_Wifi_Config(uint8_t staus);
void Esp_Sending_Data_Timeout_Counter();
void Esp_Reconnect_To_Ssid_Timeout_Counter();
void Esp_Conncet_Ack_Pckt_Failure_Timeout_Counter();
void Wifi_Config();
void Wifi_Config_For_AutoConnect();
void One_Line_Reception_Complete(WIFI_STATUS* wfStatus);
void None_At_Command_Extraction(WIFI_STATUS* wfStatus);
//unsigned char recieveWifiAtResponse(WIFI_STATUS* wfStatus);
void WIFI_Recieve(WIFI_STATUS* wfStatus);
void WIFI_Extract_Packet(WIFI_STATUS* wfStatus);
void WIFI_Send_3(WIFI_STATUS* wfStatus, char* command, char* data, unsigned short data_len, unsigned int timeout, unsigned char retryCnt);
void WIFI_Send_2(WIFI_STATUS* wfStatus);
//void Clear_Row(WIFI_STATUS* wfStatus, char rowsNumber);
//void Clear_RxBuffer(WIFI_STATUS* wfStatus);
void Clear_ApiRxBuffer(WIFI_STATUS* wfStatus);
void Clear_lengthBuffer(WIFI_STATUS* wfStatus);
void sendSsidOption(WIFI_STATUS* wfStatus/*char* ssidsBuffer, int sizeOfSsidOptionBuffer, char* ssid, char ssidLength*/);
char ssidIsRepetitive(WIFI_STATUS* wfStatus, char i);
void Decode_Received_Html_Ssid_Password(WIFI_STATUS* wfStatus);
int Hex_To_Int(char c);
void WIFI_Send_Html_Content(WIFI_STATUS* wfStatus, const unsigned char* html, unsigned short len, unsigned char id);
unsigned char Config_Site_Link_Id_Connection(WIFI_STATUS* wfStatus);
unsigned char Setpoint_Value_Derive(char* receive, SetpointType type);

//////// mqtt packet generator and sender functions ////////
void stablishConnectionWithServer(char* connectionType, char* serverAdderess, uint16_t port, WIFI_STATUS* wfStatus);
void mqtt_Connect(char* server_token, char* client_identifier, WIFI_STATUS* wfStatus);
void mqtt_Publish_Subscribe(char packetType, char* topic, char* payload, WIFI_STATUS* wfStatus);

//void WF_ATCommandEcho(WIFI_STATUS* wfStatus, unsigned char state);
//void WF_AtCommandTest(WIFI_STATUS* wfStatus);
//void WF_CheckWifiMode(WIFI_STATUS* wfStatus);
//void WF_SetWifiMode(WIFI_STATUS* wfStatus);


#endif /* ESP8266_H_ */
