/*
 * application.c
 *
 *  Created on: Apr 21, 2026
 *      Author: Mohammad Hossein
 */
#include "main.h"
#include "application.h"


#define TEMP_SETPOINT_MIN_X2    40
#define TEMP_SETPOINT_MAX_X2	70

#define TOUCH_PERCENT_STEP		10	// 5 percent
#define TOUCH_TEMP_STEP			1	// 0.5 degree

#define ERROR_MASK				0x1FFFF07

/* errorCodeTable maps error bit index -> display error number (-1 = no mapping)
 * Marked const and static because this table is file-local and immutable. */
static const signed char errorCodeTable[32] = {0, 22, 23, 18, -1, -1, -1, -1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, -1, -1, -1, -1, -1, -1, -1};
APP_STATE appState;
unsigned char reachFlag = 0;
// Private (file-local) function prototypes
void APP_Deinit(void);
static void APP_Timer_Start(void);
static void APP_Timer_Clear(void);
static void APP_Timer_Decrease(void);
void APP_UpdateDisplay_Lock(void);
void APP_Remote_To_Touch_Key(void);
void APP_Buzzer_Reset(void);
void APP_DisplayParam_Deinit(void);
void APP_DisplayParam_Init(void);
void APP_Timer_Update(ChangeTypeDef change);
unsigned char APP_IsPressShort(void);
unsigned char APP_IsPressLong(void);
unsigned char APP_Check_Update_Value(unsigned char* parameter, unsigned char minMax, unsigned char step, ChangeTypeDef change);
void APP_Perform_ClearFault(void);
void APP_Perform_KeyOff_Power(void);
void APP_Perform_KeyOff(void);
void APP_Perform_KeyNormal(void);
void APP_Perform_KeySettings_Power(void);
void APP_Perform_KeySettings(void);
void APP_Perform_KeyError(void);
void APP_Perform_Key(void);
unsigned char APP_Temp_To_Percent(void);
void APP_Update_PanelState(PANEL_StateTypeDef newState);
void APP_Start_AutoPowerOn(void);
void APP_TempComp_Init(void);
signed short APP_Calculate_Watt(void);
void APP_Set_Power_Relay(Drv_PowerTypedef state);
void APP_Set_Power(Drv_PowerTypedef pwrCmd, Drv_RunTypeDef runCmd);
void APP_Set_Setpoint(void);

PowerState toggledState[2] = {STATE_ON, STATE_OFF};


void APP_Deinit(void)
{
	APP_Update_PanelState(PANEL_STAT_OFF);
	appState.standby = STATE_OFF;
	appState.lock = STATE_OFF;
	appState.displayParam = DISPLAY_PARAM_NO;
	appState.timer.state = TIMER_OFF;
	appState.timer.value = 0;
	appState.errorTotLast = appState.errorTot;
	appState.errorTot = 0;
	TIMING_Clear(&appState.timer.timingTimer);
	TIMING_Clear(&appState.timer.timingSet);
	TIMING_Clear(&appState.timingStandby);
	TIMING_Clear(&appState.timingValve);
	TIMING_Clear(&appState.displayParamComingOut);
	TIMING_Clear(&appState.displayParamUpdate);
	TIMING_Clear(&appState.timingUpdateDisplay);
	TIMING_Clear(&appState.timingAutoPowerOn);
}

void APP_Init(void)
{
	// Init other libraries
	ADCR_Init();
	Drv_Init_Setting();
	Drv_Init_State();
	APP_TempComp_Init();
        ASK_Init_Struct();
        Key_Handle_Init();
        REMOTE_Init();
        
	// pointer to the structures should be inited first
	appState.adcReading = ADCR_Get_Struct();
	appState.drvState = Drv_Get_State();
	appState.drvSetting = Drv_Get_Setting();
	appState.drvStruct = Drv_Get_Struct();
	appState.settings = SETTINGS_Get_Handle();
	appState.display = DISP_Get_Struct();
	appState.remote = REMOTE_Get_Struct();
	APP_Update_PanelState(PANEL_STAT_OFF);
	appState.standby = STATE_OFF;
	appState.lock = STATE_OFF;
	appState.displayParam = DISPLAY_PARAM_NO;
	APP_Clear_PressedKey();
	appState.timer.state = TIMER_OFF;
	appState.timer.value = 0;
	appState.errorNum = -1;
	appState.warningNum = -1;
	appState.timer.timingTimer.limit = 3600000;	// To Update timer value every hour
	appState.timer.timingSet.limit = 8000;
	appState.displayParamComingOut.limit = 15000;
	appState.displayParamUpdate.limit = 500;
	appState.timingUpdateDisplay.limit = 100;
	appState.timingAutoPowerOn.limit = AUTO_POWER_ON_DELAY;
        appState.testComingOut.limit = 10000;
        appState.timingSpeedEncrease.limit = 5400000;
	appState.setPointTempX2 = reg[CMD_SETPOINT_TEMP];
	appState.autoMode = (AUTO_ModeTypeDef)FUNC_GET_BIT(reg[CMD_BITS], BITS_AUTO);
        appState.cntSec = 0;
        appState.cntMin = 0;
        appState.cntHour = 0;
	APP_Load_Parameters();
	APP_Start_AutoPowerOn();
        TIMING_Start(&appState.timingSpeedEncrease);
}

void APP_Check_Timing(void)
{
	if(TIMING_Check_WhenCounting(&appState.buzzerState.timingBuzzer))
	{
		APP_Handle_Buzzer();
	}

	if(TIMING_Check_WhenCounting(&appState.timingStandby))
	{
		//ToDo: go to standby
		if(appState.panelState == PANEL_STAT_NORMAL)
		{
			appState.standby = STATE_ON;
			Init_Display_Brightness(appState.LcdStandByContrastLevel);
			APP_UpdateDisplay();
		}
	}

	if(TIMING_Check_WhenCounting(&appState.timingValve))
	{
		Drv_Set_Valve(DRV_PWR_OFF);
	}

	if(TIMING_Check_WhenCounting(&appState.timingAutoPowerOn))
	{
		if(appState.panelState == PANEL_STAT_OFF)
		{
			APP_Perform_KeyOff_Power();
			APP_UpdateDisplay();
		}
	}

	if(TIMING_Check_WhenCounting(&appState.displayParamComingOut))
	{
		APP_DisplayParam_Deinit();
                APP_Buzzer_Play_Time(BUZZER_ON_LONG);
		APP_UpdateDisplay();
	}

	if(TIMING_Check_WhenCounting(&appState.displayParamUpdate))
	{
		if(APP_DisplayParam_Read())
		{
			APP_UpdateDisplay();
		}
	}

	if(TIMING_Check_WhenCounting(&appState.timingUpdateDisplay))
	{
		APP_UpdateDisplay();
	}
        
        if(TIMING_Check_WhenCounting(&appState.testComingOut))
	{
		APP_Buzzer_Play_Time(BUZZER_ON_LONG);
                APP_Update_PanelState(PANEL_STAT_OFF);
		APP_UpdateDisplay();
	}

	if(TIMING_Check_WhenCounting(&appState.timer.timingSet))
	{
		APP_Timer_Start();
		APP_UpdateDisplay();
	}

	if(TIMING_Check_WhenCounting(&appState.timer.timingTimer))
	{
		APP_Timer_Decrease();
		APP_UpdateDisplay();
	}

	if(TIMING_Check_WhenCounting(&appState.drvState->resetRetryNum))
	{
		Drv_Reset_RetryNum();
	}

	if(TIMING_Check_WhenCounting(&appState.drvState->timeoutOff))
	{
		APP_Set_Power_Relay(DRV_PWR_OFF);
	}

	if(TIMING_Check_WhenCounting(&appState.display->blinkOff))
	{
		if(appState.settings->state == SETTINGS_STAT_VALUE || appState.settings->state == SETTINGS_STAT_LEARN || appState.timer.state == TIMER_IN_SETTING)
		{
			DISP_ShowBlink();
			TIMING_Start(&appState.display->blinkOn);
		}
	}
	else if(TIMING_Check_WhenCounting(&appState.display->blinkOn))
	{
		DISP_ShowFinal();
		if(appState.settings->state == SETTINGS_STAT_VALUE || appState.settings->state == SETTINGS_STAT_LEARN || appState.timer.state == TIMER_IN_SETTING)
		{
			TIMING_Start(&appState.display->blinkOff);
		}
	}

	if(TIMING_Check_WhenCounting(&appState.settings->timingBack))
	{
		SETTINGS_Update_State(STEP_BACK);
		APP_UpdateDisplay();
	}

	if(TIMING_Check_WhenCounting(&appState.settings->timingComeOut))
	{
		APP_Perform_KeySettings_Power();
		APP_UpdateDisplay();
	}

	if(TIMING_Check_WhenCounting(&appState.remote->askStruct->resetPressedKey))
	{
		VAR_Set_Reg(STAT_REMOTE, RF_KEY_NO);
	}

	if(TIMING_Check_WhenCounting(&appState.compOff.elapsed))
	{
                TEMPCOMP_Calculate_Offset(&appState.compOff);
		appState.compOff.isReached = 1;
	}

	if(TIMING_Check_WhenCounting(&appState.compOn.elapsed))
	{
                TEMPCOMP_Calculate_Offset(&appState.compOn);
		appState.compOn.isReached = 1;
	}
        if(TIMING_Check_WhenCounting(&appState.timingSpeedEncrease))
        {
                TIMING_Start(&appState.timingSpeedEncrease);
                APP_Buzzer_Play_Time(BUZZER_ON_LONG);
                if(appState.drvState->pwrStat == DRV_PWR_OFF)
                  APP_Perform_KeyOff_Power();
                else
                {
                  if(reachFlag == 0)
                  {
                    if(APP_Check_Update_Value(&appState.drvSetting->setPointPercentX2, DRV_PERCENT_SETPOINT_MAX, 40, CHANGE_INCREASE))
                    {
                            VAR_Set_Reg(CMD_SETPOINT_PERCENT, appState.drvSetting->setPointPercentX2);
                            APP_Set_Setpoint();
                    }
                    if(appState.drvSetting->setPointPercentX2 >= 200)
                      reachFlag = 1;
                  }
                  else
                  {
                    if(APP_Check_Update_Value(&appState.drvSetting->setPointPercentX2, DRV_PERCENT_SETPOINT_MIN, 40, CHANGE_DECREASE))
                    {
                            VAR_Set_Reg(CMD_SETPOINT_PERCENT, appState.drvSetting->setPointPercentX2);
                            APP_Set_Setpoint();
                    }
                    if(appState.drvSetting->setPointPercentX2 <= 0)
                    {
                      APP_Set_Power(DRV_PWR_OFF, DRV_RUN_STOP);
                      APP_Deinit();
                      TIMING_Clear(&appState.timingSpeedEncrease);
                    }
                  }
                }
                
                
                APP_UpdateDisplay();
        }
        Drv_Check_BusRelease();
	Drv_Handle_Timeout();
}

static void APP_Timer_Start(void)
{
	if(appState.timer.value > 0)
	{
		appState.timer.state = TIMER_ON;
		TIMING_Start_With_Retry(&appState.timer.timingTimer, appState.timer.value);
	}
	else
	{
		appState.timer.state = TIMER_OFF;
	}
	TIMING_Clear(&appState.timer.timingSet);
}

static void APP_Timer_Clear(void)
{
	appState.timer.state = TIMER_OFF;
	appState.timer.value = 0;
	TIMING_Clear(&appState.timer.timingSet);
	TIMING_Clear(&appState.timer.timingTimer);
}

// if timer value reach 0, turn off driver
static void APP_Timer_Decrease(void)
{
	appState.timer.value = appState.timer.timingTimer.retryNum;
	if(appState.timer.value == 0)
	{
		APP_Timer_Clear();
                appState.pressedKey = KEY_POWER;
                appState.pressType = PRESS_TYPE_SHORT;
		APP_Handle_Key();
	}
}

void APP_Timer_Update(ChangeTypeDef change)
{
	if(change == CHANGE_DECREASE)
	{
		if(appState.timer.value > 0)
		{
			appState.timer.value--;
		}
	}
	else if(change == CHANGE_INCREASE)
	{
		if(appState.timer.value < 9)
		{
			appState.timer.value++;
		}
	}
	TIMING_Start(&appState.timer.timingSet);
}

unsigned char APP_IsPressShort(void)
{
	if(appState.pressType == PRESS_TYPE_SHORT || appState.pressType == PRESS_TYPE_LONG_CONT)
	{
		appState.buzzerState.onTime = BUZZER_ON_SHORT;
		return 1;
	}

	return 0;
}

unsigned char APP_IsPressLong(void)
{
	if(appState.pressType == PRESS_TYPE_LONG)
	{
		appState.buzzerState.onTime = BUZZER_ON_LONG;
		return 1;
	}

	return 0;
}

unsigned char APP_Check_Update_Value(unsigned char* parameter, unsigned char minMax, unsigned char step, ChangeTypeDef change)
{
	unsigned char needUpdate = 0;
	short diff;
	if(change == CHANGE_DECREASE)
	{
		diff = *parameter - minMax;
		if(diff != 0)
		{
			needUpdate = 1;
			if(diff >= step)
			{
				*parameter -= step;
			}
			else
			{
				*parameter = minMax;
			}
		}
	}
	else if(change == CHANGE_INCREASE)
	{
		diff = minMax - *parameter;
		if(diff != 0)
		{
			needUpdate = 1;
			if(diff >= step)
			{
				*parameter += step;
			}
			else
			{
				*parameter = minMax;
			}
		}
	}
	return needUpdate;
}

void APP_Perform_KeyOff_Power(void)
{
	CLEAR_BIT(appState.appError, APP_ERROR_RCCB);
	APP_Aggregate_Error();
	if(appState.errorTot == 0)
	{
		APP_Update_PanelState(PANEL_STAT_NORMAL);
		Drv_Init_Setting();
		Drv_Init_State();
		APP_Set_Power(DRV_PWR_ON, DRV_RUN_START);
	}
	else
	{
		APP_Calculate_Error_Number();
		APP_Update_PanelState(PANEL_STAT_ERROR);
	}
}

void APP_Perform_KeyOff(void)
{
	switch(appState.pressedKey)
	{
	case KEY_POWER:
		if(APP_IsPressShort())
		{
			APP_Perform_KeyOff_Power();
		}
		break;
	case KEY_SETTINGS:
		if(APP_IsPressShort())
		{
			SETTINGS_Init();
			APP_Update_PanelState(PANEL_STAT_SETTINGS);
		}
		break;
        case KEY_TEST:
		if(APP_IsPressLong())
		{
			APP_Update_PanelState(PANEL_STAT_TEST);
                        TIMING_Start(&appState.testComingOut);
		}
		break;
	default:
		break;
	}
}

void APP_Perform_KeyNormal(void)
{
	switch(appState.pressedKey)
	{
	case KEY_POWER:
		if(APP_IsPressShort())
		{
			APP_Set_Power(DRV_PWR_OFF, DRV_RUN_STOP);
			APP_Deinit();
		}
		break;
	case KEY_PUMP:
		if(APP_IsPressShort())
		{
			if(appState.drvState->valveStat == DRV_PWR_ON)
			{
				return;
			}
			if(appState.autoMode == AUTO_MODE_AUTO && appState.pumpMode == AUTO_MODE_AUTO)
			{
				APP_Buzzer_Reset();
				return;
			}
			Drv_Set_Pump(DRV_PWR_TOGGLE);
		}
		else if(APP_IsPressLong())
		{
			if(appState.drvState->valveStat == DRV_PWR_OFF)
			{
				TIMING_Start(&appState.timingValve);
			}
			else
			{
				TIMING_Clear(&appState.timingValve);
			}
			Drv_Set_Valve(DRV_PWR_TOGGLE);
		}
		break;
	case KEY_AUTO:
		if(APP_IsPressShort())
		{
			if(appState.autoMode == AUTO_MODE_MANUAL)
			{
				appState.autoMode = AUTO_MODE_AUTO;
				APP_Handle_Auto();
			}
			else if(appState.autoMode == AUTO_MODE_AUTO)
			{
				appState.autoMode = AUTO_MODE_MANUAL;
				APP_Temp_To_Percent();
				VAR_Set_Reg(CMD_SETPOINT_PERCENT, appState.drvSetting->setPointPercentX2);
				APP_Set_Setpoint();
			}
			VAR_Update_Reg_Bits(CMD_BITS, appState.autoMode, BITS_AUTO, 1);
		}
//		else if(APP_IsPressLong())	// Change Cooling/Heating Mode
//		{}
		break;
	case KEY_TIMER:
		if(APP_IsPressShort())
		{
			if(appState.timer.state == TIMER_OFF || appState.timer.state == TIMER_ON)
			{
				appState.timer.state = TIMER_IN_SETTING;
				TIMING_Start(&appState.timer.timingSet);
			}
			else if(appState.timer.state == TIMER_IN_SETTING)
			{
				APP_Timer_Start();
			}
		}
		else if(APP_IsPressLong())
		{
			APP_Timer_Clear();
		}
		break;
	case KEY_SETTINGS:
		if(APP_IsPressLong())
		{
			if(appState.displayParam == DISPLAY_PARAM_NO)
			{
				APP_DisplayParam_Init();
			}
			else
			{
				APP_DisplayParam_Deinit();
			}
		}
		break;
	case KEY_UP:
		if(APP_IsPressShort())
		{
			if(appState.timer.state == TIMER_IN_SETTING)
			{
				APP_Timer_Update(CHANGE_INCREASE);
			}
			else if(appState.displayParam != DISPLAY_PARAM_NO)
			{
				if(appState.displayParam < DISPLAY_PARAM_NUM)
				{
					appState.displayParam ++;
					APP_DisplayParam_Read();
				}
				TIMING_Start(&appState.displayParamComingOut);
			}
			else if(appState.autoMode == AUTO_MODE_MANUAL)
			{
				if(APP_Check_Update_Value(&appState.drvSetting->setPointPercentX2, DRV_PERCENT_SETPOINT_MAX, TOUCH_PERCENT_STEP, CHANGE_INCREASE))
				{
					VAR_Set_Reg(CMD_SETPOINT_PERCENT, appState.drvSetting->setPointPercentX2);
					APP_Set_Setpoint();
				}
			}
			else if(appState.autoMode == AUTO_MODE_AUTO)
			{
				if(APP_Check_Update_Value(&appState.setPointTempX2, TEMP_SETPOINT_MAX_X2, TOUCH_TEMP_STEP, CHANGE_INCREASE))
				{
					VAR_Set_Reg(CMD_SETPOINT_TEMP, appState.setPointTempX2);
					APP_Handle_Auto();
				}
			}
		}
		break;
	case KEY_DOWN:
		if(APP_IsPressShort())
		{
			if(appState.timer.state == TIMER_IN_SETTING)
			{
				APP_Timer_Update(CHANGE_DECREASE);
			}
			else if(appState.displayParam != DISPLAY_PARAM_NO)
			{
				if(appState.displayParam > 1)
				{
					appState.displayParam --;
					APP_DisplayParam_Read();
				}
				TIMING_Start(&appState.displayParamComingOut);
			}
			else if(appState.autoMode == AUTO_MODE_MANUAL)
			{
				if(APP_Check_Update_Value(&appState.drvSetting->setPointPercentX2, DRV_PERCENT_SETPOINT_MIN, TOUCH_PERCENT_STEP, CHANGE_DECREASE))
				{
					VAR_Set_Reg(CMD_SETPOINT_PERCENT, appState.drvSetting->setPointPercentX2);
					APP_Set_Setpoint();
				}
			}
			else if(appState.autoMode == AUTO_MODE_AUTO)
			{
				if(APP_Check_Update_Value(&appState.setPointTempX2, TEMP_SETPOINT_MIN_X2, TOUCH_TEMP_STEP, CHANGE_DECREASE))
				{
					VAR_Set_Reg(CMD_SETPOINT_TEMP, appState.setPointTempX2);
					APP_Handle_Auto();
				}
			}
		}
		break;
	case KEY_LOCK_LEARN:
		if(APP_IsPressLong())
		{
			appState.lock = toggledState[appState.lock];
		}
		break;
	default:
		break;
	}
}

void APP_Perform_KeySettings_Power(void)
{
	SETTINGS_Comming_Out();
	APP_Load_Parameters();
	APP_Update_PanelState(PANEL_STAT_OFF);
}

void APP_Perform_KeySettings(void)
{
	switch(appState.pressedKey)
	{
	case KEY_POWER:
		if(APP_IsPressShort())
		{
			APP_Perform_KeySettings_Power();
		}
		break;
	case KEY_AUTO:
		if(APP_IsPressShort())
		{
			SETTINGS_Update_State(STEP_BACK);
		}
		break;
	case KEY_SETTINGS:
		if(APP_IsPressShort())
		{
			SETTINGS_Update_State(STEP_OK);
		}
		else if(APP_IsPressLong())
		{
			SETTINGS_Toggle_Advance();
		}
		break;
	case KEY_UP:
		if(APP_IsPressShort())
		{
			SETTINGS_Update_ParamVal(CHANGE_INCREASE);
		}
		break;
	case KEY_DOWN:
		if(APP_IsPressShort())
		{
			SETTINGS_Update_ParamVal(CHANGE_DECREASE);
		}
		break;
	case KEY_LOCK_LEARN:
		if(APP_IsPressLong())
		{
			SETTINGS_Learn_Init();
		}
		break;
	default:
		break;
	}
}

void APP_Perform_KeyError(void)
{
	switch(appState.pressedKey)
	{
	case KEY_POWER:
		if(APP_IsPressShort())
		{
			APP_Set_Power_Relay(DRV_PWR_OFF);
                        Drv_Deinit_Setting();
			APP_Deinit();
		}
		break;
	case KEY_SETTINGS:
		if(APP_IsPressShort())
		{
			Drv_Clear_Fault();
		}
		break;
	default:
		break;
	}
}

void APP_Perform_KeyTest(void)
{
        if(APP_IsPressShort())
	{
                TIMING_Start(&appState.testComingOut);
                APP_UpdateDisplay_Lock();  
        }
        else if(APP_IsPressLong())
        {
                if(appState.pressedKey == KEY_POWER)
                {
                        TIMING_Clear(&appState.testComingOut);
                        APP_Update_PanelState(PANEL_STAT_OFF);
                }
                else
                {
                        TIMING_Start(&appState.testComingOut);
                }
        }
}

void APP_Perform_Key(void)
{
	if(appState.panelState == PANEL_STAT_OFF)
	{
		APP_Perform_KeyOff();
	}
	else if(appState.panelState == PANEL_STAT_NORMAL)
	{
		APP_Perform_KeyNormal();
	}
	else if(appState.panelState == PANEL_STAT_SETTINGS)
	{
		APP_Perform_KeySettings();
	}
	else if(appState.panelState == PANEL_STAT_ERROR)
	{
		APP_Perform_KeyError();
	}
        else if(appState.panelState == PANEL_STAT_TEST)
	{
		APP_Perform_KeyTest();
	}
}

void APP_Handle_Key(void)
{
        if(appState.pressedKey != KEY_NO && appState.pressType != PRESS_TYPE_UNKNOWN)
	{
		if(READ_BIT(reg[CMD_IO_CONTROL], IO_BIT_MANUAL))
		{
			APP_Clear_PressedKey();
			return;
		}

		TIMING_Start(&appState.timingStandby);
		if(appState.standby == STATE_ON)
		{
			// ToDo: Go out of standby state
			appState.standby = STATE_OFF;
			Init_Display_Brightness(appState.LcdNormalContrastLevel);
			APP_UpdateDisplay();
                        APP_Buzzer_Play_Time(BUZZER_ON_SHORT);
			APP_Clear_PressedKey();
			return;
		}

		if(appState.lock == STATE_ON && appState.panelState == PANEL_STAT_NORMAL)
		{
			if(appState.pressedKey != KEY_LOCK_LEARN)
			{
				// ToDo: blink + buzzer play
				APP_Clear_PressedKey();
				APP_UpdateDisplay_Lock();
				APP_Buzzer_Play_Time(BUZZER_ON_SHORT);
				return;
			}
		}

		APP_Perform_Key();
		APP_Clear_PressedKey();
		APP_Buzzer_Play();
		APP_UpdateDisplay();
	}
}

void APP_Remote_To_Touch_Key(void)
{
	appState.pressType = PRESS_TYPE_SHORT;
	switch(appState.remotePressedKey)
	{
	case RF_KEY_NO:
		appState.pressedKey = KEY_NO;
		break;
	case RF_KEY_POWER:
		appState.pressedKey = KEY_POWER;
		break;
	case RF_KEY_UP:
		appState.pressedKey = KEY_UP;
		break;
	case RF_KEY_DOWN:
		appState.pressedKey = KEY_DOWN;
		break;
	case RF_KEY_PUMP_ON:
	{
		if(appState.drvState->pumpStat == DRV_PWR_OFF)
			appState.pressedKey = KEY_PUMP;
		else
			appState.pressType = PRESS_TYPE_UNKNOWN;
		break;
	}
	case RF_KEY_PUMP_OFF:
	{
		if(appState.drvState->pumpStat == DRV_PWR_ON)
			appState.pressedKey = KEY_PUMP;
		else
			appState.pressType = PRESS_TYPE_UNKNOWN;
		break;
	}
	case RF_KEY_PUMP_TOGGLE:
		appState.pressedKey = KEY_PUMP;
		break;
	case RF_KEY_AUTO_ON:
	{
		if(appState.autoMode == AUTO_MODE_MANUAL)
			appState.pressedKey = KEY_AUTO;
		else
			appState.pressType = PRESS_TYPE_UNKNOWN;
		break;
	}
	case RF_KEY_AUTO_OFF:
	{
		if(appState.autoMode == AUTO_MODE_AUTO)
			appState.pressedKey = KEY_AUTO;
		else
			appState.pressType = PRESS_TYPE_UNKNOWN;
		break;
	}
	case RF_KEY_AUTO_TOGGLE:
		appState.pressedKey = KEY_AUTO;
		break;
	}
}

void APP_Handle_Remote(void)
{
	if(appState.remotePressedKey != RF_KEY_NO)
	{
		if(appState.pressedKey == KEY_NO && appState.pressType == PRESS_TYPE_UNKNOWN)
		{
			APP_Remote_To_Touch_Key();
			APP_Perform_Key();
			APP_Clear_PressedKey();
			APP_UpdateDisplay();
		}
		APP_Buzzer_Play_Time(BUZZER_ON_SHORT);
		appState.remotePressedKey = RF_KEY_NO;
	}
}

unsigned char APP_Temp_To_Percent(void)
{
	unsigned char needUpdate = 0;
	float tempDiffX2, newSetPointTempX2 = (float)appState.setPointTempX2;
	unsigned short newPercentX2 = 0;
//	if(appState.drvState->runStat == DRV_RUN_STOP)
//	{
//		newSetPointTempX2 += HYSTERESIS_OFFSET*2;
//	}
//	else
//	{
//		newSetPointTempX2 -= HYSTERESIS_OFFSET*2;
//	}
	if((appState.tempComp100 * 2) > newSetPointTempX2)
	{
		tempDiffX2 = appState.tempComp100 * 2 - newSetPointTempX2;
		if(appState.autoSensitivity == 0)
		{
			return 0;
		}
		newPercentX2 = (unsigned short)(tempDiffX2 * 100/appState.autoSensitivity + 5);
		newPercentX2 = (newPercentX2 / 10) * 10;
		if(newPercentX2 > 200)
		{
			newPercentX2 = 200;
		}
		else if(newPercentX2 < 10)
		{
			newPercentX2 = 0;
		}
	}
	else if((appState.tempComp100 * 2) < newSetPointTempX2)
	{
		newPercentX2 = 0;
	}

	if(appState.drvSetting->setPointPercentX2 != newPercentX2)
	{
		appState.drvSetting->setPointPercentX2 = newPercentX2;
		needUpdate = 1;
	}
	return needUpdate;
}

unsigned char APP_Handle_Auto(void)
{
	unsigned char needUpdate = 0;
	if(appState.panelState == PANEL_STAT_NORMAL)
	{
		if(appState.autoMode == AUTO_MODE_AUTO)
		{
			if(APP_Temp_To_Percent())
			{
				needUpdate = 1;
				APP_Set_Setpoint();
			}
                        if(appState.pumpMode == AUTO_MODE_AUTO)
                        {
                                if(appState.drvSetting->pumpCmd != (Drv_PowerTypedef)appState.drvSetting->runCmd)
                                {
                                        Drv_Set_Pump(DRV_PWR_TOGGLE);
                                }
                        }
		}
	}
	return needUpdate;
}

void APP_UpdateDisplay_ModeOff(void)
{
	DISP_Update_KeysBorder(DISP_KEY_PANEL_OFF);
	DISP_Update_Upper(DISP_ICON_OFF, SEVENSEG_OFF);
	DISP_Update_Middle(0, DISP_BIG_OFF, DISP_NUM_ICON_OFF);
	DISP_Update_Lower(0, -1, DISP_SMALL_OFF, 0, DISP_NUM_ICON_OFF);
}

void APP_UpdateDisplay_ModeSettings(void)
{
	DISP_Update_KeysBorder(DISP_KEY_PANEL_SETTINGS);
        if(appState.settings->advancedMode == ON)
        {
                DISP_Update_Upper(DISP_ICON_OFF, SEVENSEG_A);
        }
        else
        {
                DISP_Update_Upper(DISP_ICON_OFF, SEVENSEG_OFF);
        }

	if(appState.settings->state == SETTINGS_STAT_PARAM)
	{
		DISP_Update_Middle(appState.settings->index, DISP_BIG_PARAM, DISP_NUM_ICON_OFF);
		DISP_Update_Lower(appState.settings->value[appState.settings->index], -1, DISP_SMALL_NUM_3, paramHasFraction[appState.settings->index], paramNumIcon[appState.settings->index]);
	}
	else if(appState.settings->state == SETTINGS_STAT_VALUE)
	{
		DISP_Update_Middle(appState.settings->index, DISP_BIG_PARAM, DISP_NUM_ICON_OFF);
		DISP_Update_Lower(appState.settings->valueOngoing, -1, DISP_SMALL_NUM_3, paramHasFraction[appState.settings->index], paramNumIcon[appState.settings->index]);
		DISP_Update_Blink(BLINK_MODE_LOWER);
	}
	else if(appState.settings->state == SETTINGS_STAT_LEARN)
	{
		if(appState.settings->learnStat == LEARN_DONE)
		{
			DISP_Update_Middle(-1, DISP_BIG_LEARN_DONE, DISP_NUM_ICON_OFF);
		}
		else
		{
			DISP_Update_Middle(-1, DISP_BIG_LEARN_PENDING, DISP_NUM_ICON_OFF);
		}

		DISP_Update_Lower(0, -1, DISP_SMALL_OFF, 0, DISP_NUM_ICON_OFF);
		DISP_Update_Blink(BLINK_MODE_MIDDLE);
	}
}

void APP_Calculate_Upper(void)
{
	appState.display->icons = DISP_ICON_OFF;
	appState.display->segTimer = SEVENSEG_OFF;

	if(appState.drvState->pumpStat == DRV_PWR_ON)
	{
		appState.display->icons |= DISP_ICON_PUMP;
	}
	if(appState.errorNum >= 0 || appState.warningNum > 0)
	{
		appState.display->icons |= DISP_ICON_ERROR;
	}
	if(appState.autoMode == AUTO_MODE_AUTO)
	{
		appState.display->icons |= DISP_ICON_AUTO;
	}
	if(appState.timer.state != TIMER_OFF)
	{
		appState.display->icons |= DISP_ICON_TIMER;
	}

	// Fill segTimer according to priority
	// 1: Timer in settings
	// 2: warningNum -> 2.1: WLS, 2.2: PFC, 2.3: OverTemp, 2.4: driver error
	// 3: Valve ON
	// 4: Timer ON
	if(appState.timer.state == TIMER_IN_SETTING)
	{
		appState.display->segTimer = (SEVENSEG_SymbolTypeDef) appState.timer.value;
	}
	else if(appState.warningNum > 0)
	{
		if(appState.warningNum == APP_WARNING_WLS)
		{
			appState.display->segTimer = SEVENSEG_L;
		}
		else if(appState.warningNum == APP_WARNING_DRV_PFC)
		{
			appState.display->segTimer = SEVENSEG_P;
		}
		else if(appState.warningNum == APP_WARNING_DRV_OVERTEMP)
		{
			appState.display->segTimer = SEVENSEG_t;
		}
		else if(appState.warningNum == APP_WARNING_DRV_ERR)
		{
			appState.display->segTimer = SEVENSEG_c;
		}
	}
	else if(appState.drvState->valveStat == DRV_PWR_ON)
	{
		appState.display->segTimer = SEVENSEG_d;
	}
	else if(appState.timer.state == TIMER_ON)
	{
		appState.display->segTimer = (SEVENSEG_SymbolTypeDef) appState.timer.value;
	}
}

void APP_UpdateDisplay_ModeNormal(void)
{
	if(appState.standby == STATE_ON)
	{
		DISP_Update_KeysBorder(DISP_KEY_PANEL_STANDBY);
	}
	else if(appState.lock == STATE_ON)
	{
		DISP_Update_KeysBorder(DISP_KEY_PANEL_LOCK);
	}
	else
	{
		DISPALY_KeyTypeDef keys = DISP_KEY_PANEL_NORMAL;
		if(appState.autoMode == AUTO_MODE_AUTO && appState.pumpMode == AUTO_MODE_AUTO)
		{
			keys &= ~ DISP_KEY_PUMP;
		}
		DISP_Update_KeysBorder(keys);
	}
	APP_Calculate_Upper();
	DISP_Update_Upper(appState.display->icons, appState.display->segTimer);
	if(appState.displayParam == DISPLAY_PARAM_NO)
	{
		DISP_Update_Middle(appState.adcReading->tempFiltered, DISP_BIG_NUM_2, DISP_NUM_ICON_POINT | DISP_NUM_ICON_DEGREE);
		if(appState.autoMode == AUTO_MODE_MANUAL)
		{
			DISP_Update_Lower(appState.drvSetting->setPointPercentX2/2, appState.drvSetting->setPointPercentX2/2, DISP_SMALL_NUM_3, 0, DISP_NUM_ICON_PERCENT);
		}
		else if(appState.autoMode == AUTO_MODE_AUTO)
		{
			DISP_Update_Lower((float)appState.setPointTempX2/2, appState.drvSetting->setPointPercentX2/2, DISP_SMALL_NUM_2, 1, DISP_NUM_ICON_DEGREE);
		}
	}
	else
	{
		appState.display->bigNumIcon = DISP_NUM_ICON_OFF;
		appState.display->bigMode = DISP_BIG_NUM_3;

		switch (appState.displayParam)
		{
		case DISPLAY_PARAM_DRV_TEMP:
		{
			appState.display->bigValue = appState.drvState->drvTempFiltered;
			appState.display->bigMode = DISP_BIG_NUM_2;
			appState.display->bigNumIcon = DISP_NUM_ICON_POINT | DISP_NUM_ICON_DEGREE;
			break;
		}
		case DISPLAY_PARAM_VAC_INPUT:
			appState.display->bigValue = appState.adcReading->vAC;
			break;
		case DISPLAY_PARAM_DC_BUS_VOL:
			appState.display->bigValue = appState.drvState->drvDcBusVoltage;
			break;
		case DISPLAY_PARAM_DROP_RATE_LAST:
			appState.display->bigValue = appState.drvState->droprateLastX10/10;
			break;
		case DISPLAY_PARAM_DROP_RATE_TOTAL:
			appState.display->bigValue = appState.drvState->droprateTotX10/10;
			break;
		case DISPLAY_PARAM_CODE_VERSION:
			appState.display->bigValue = CODE_VERSION;
			break;
		default:
			appState.display->bigValue = 0;
			break;
		}
		DISP_Update_Middle(appState.display->bigValue, appState.display->bigMode, appState.display->bigNumIcon);
		DISP_Update_Lower(appState.displayParam, -1, DISP_SMALL_PARAM, 0, DISP_NUM_ICON_OFF);
	}
	if(appState.timer.state == TIMER_IN_SETTING)
	{
		DISP_Update_Blink(BLINK_MODE_TIMER);
	}
}

void APP_UpdateDisplay_ModeError(void)
{
	DISP_Update_KeysBorder(DISP_KEY_PANEL_ERROR);
	APP_Calculate_Upper();
	DISP_Update_Upper(appState.display->icons, appState.display->segTimer);
	DISP_Update_Middle(appState.errorNum, DISP_BIG_ERROR, DISP_NUM_ICON_OFF);
	DISP_Update_Lower(0, -1, DISP_SMALL_OFF, 0, DISP_NUM_ICON_OFF);
}

void APP_UpdateDisplay_ModeTest(void)
{
        LCD_Glass_Play_All();
}

void APP_UpdateDisplay_Lock(void)
{
	DISP_CopyFinal();
	DISP_Update_Blink(BLINK_MODE_ALL);
	DISP_ShowBlink();
}

void APP_UpdateDisplay(void)
{
	if(READ_BIT(reg[CMD_IO_CONTROL], IO_BIT_MANUAL))
	{
		return;
	}
	if(appState.panelState == PANEL_STAT_OFF)
	{
		APP_UpdateDisplay_ModeOff();
	}
	else if(appState.panelState == PANEL_STAT_NORMAL)
	{
		APP_UpdateDisplay_ModeNormal();
	}
	else if(appState.panelState == PANEL_STAT_SETTINGS)
	{
		APP_UpdateDisplay_ModeSettings();
	}
	else if(appState.panelState == PANEL_STAT_ERROR)
	{
		APP_UpdateDisplay_ModeError();
	}
        else if(appState.panelState == PANEL_STAT_TEST)
	{
		APP_UpdateDisplay_ModeTest();
	}
	DISP_ChangeIndex();
}

void APP_UpdateDisplay_Temp(void)
{
	if(appState.panelState == PANEL_STAT_NORMAL)
	{
		if((appState.timer.state != TIMER_IN_SETTING) && (appState.display->blinkOff.isCounting == 0) && (appState.display->blinkOn.isCounting == 0))
		{
			if(appState.displayParam == DISPLAY_PARAM_NO)
			{
				DISP_CopyFinal();
				DISP_Update_Middle(appState.adcReading->tempFiltered, DISP_BIG_NUM_2, DISP_NUM_ICON_POINT | DISP_NUM_ICON_DEGREE);
				DISP_ChangeIndex();
			}
		}
	}
}

unsigned char APP_UpdateDisplay_Is_Needed(void)
{
	if((appState.drvStruct->rspReceived == DRV_REG_PUMP) || ((appState.drvStruct->rspReceived == DRV_REG_DC_BUS_VOLTAGE || appState.drvStruct->rspReceived == DRV_REG_VTH) && (appState.displayParam != DISPLAY_PARAM_NO)))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

/**
 * @brief	bit 0: app error bit 0 (RCCB)
 * 			bit 1-3: adc error bits 0-2
 * 			bit 8-27: drv fault bits 0-19
 * @param	none
 * @retval	none
 **/
void APP_Aggregate_Error(void)
{
	uint32_t errTot = ((uint32_t)appState.appError & 1);
	errTot |= (((uint32_t)appState.adcReading->error & 7) << 1);
	errTot |= ((uint32_t)(appState.drvState->errorValidated & 0xFFFFF) << 8);
	appState.errorTot = errTot & ERROR_MASK;
	APP_Calculate_Error_Number();
	VAR_Set_Reg(STAT_ERROR, (unsigned short)(appState.errorTot & 0xFFFF));
	VAR_Set_Reg(STAT_ERROR + 1, (unsigned short)(appState.errorTot >> 16));
}

void APP_Calculate_Error_Number(void)
{
	unsigned char i;
	signed char num = -1;
	uint32_t err;
	if(appState.errorTot != 0)
	{
		for(i = 0; i < 32; i++)
		{
			err = appState.errorTot & ((uint32_t)1 << i);
			if(err != 0)
			{
				num = errorCodeTable[i];
				break;
			}
		}
	}
	appState.errorNum = num;
}

void APP_Aggregate_Warning(void)
{
	appState.warningTot = appState.drvState->drvLimitFlag;
	if(appState.drvState->error && !appState.drvState->errorValidated)
	{
		SET_BIT(appState.warningTot, 1 << APP_WARNING_DRV_ERR);
	}
	else
	{
		CLEAR_BIT(appState.warningTot, 1 << APP_WARNING_DRV_ERR);
	}
	APP_Calculate_Warning_Number();
	VAR_Set_Reg(STAT_WARNING, appState.warningTot);

	if(appState.warningNum != appState.warningNumLast)
	{
		APP_UpdateDisplay();
	}
}

void APP_Calculate_Warning_Number(void)
{
	appState.warningNumLast = appState.warningNum;
	appState.warningNum = -1;
	if(appState.warningTot != 0)
	{
		if(FUNC_GET_BIT(appState.warningTot, APP_WARNING_WLS))
		{
			appState.warningNum = APP_WARNING_WLS;
		}
		else if(FUNC_GET_BIT(appState.warningTot, APP_WARNING_DRV_PFC))
		{
			appState.warningNum = APP_WARNING_DRV_PFC;
		}
		else if(FUNC_GET_BIT(appState.warningTot, APP_WARNING_DRV_OVERTEMP))
		{
			appState.warningNum = APP_WARNING_DRV_OVERTEMP;
		}
		else if(FUNC_GET_BIT(appState.warningTot, APP_WARNING_DRV_ERR))
		{
			appState.warningNum = APP_WARNING_DRV_ERR;
		}
	}
}

unsigned char APP_Check_Error(void)
{
	unsigned char updateDisp = 0;
	if(appState.panelState == PANEL_STAT_NORMAL)
	{
		if((appState.errorTot & 0xF7) != 0)
		{
			APP_Set_Power_Relay(DRV_PWR_OFF);
			APP_Update_PanelState(PANEL_STAT_ERROR);
			updateDisp = 1;
		}
		else if((appState.errorTot & 0xFFFFFF08) != 0)
		{
			APP_Update_PanelState(PANEL_STAT_ERROR);
			updateDisp = 1;
		}
	}
	else if(appState.panelState == PANEL_STAT_ERROR)
	{
		if(appState.errorTot == 0)
		{
			APP_Update_PanelState(PANEL_STAT_NORMAL);
			updateDisp = 1;
			APP_Set_Power(DRV_PWR_ON, appState.drvSetting->runCmd);
		}
	}
	return updateDisp;
}

/**
 * @brief  if current mismatch is detected and RCCB is activated, this function turn off output power
 * @param  none
 * @retval none
 **/
unsigned char APP_Handle_RCCB(void)
{
	unsigned char updateDisp = 0;
	if(appState.rccbEnable == STATE_ON)
	{
		delay_ms(1);
		unsigned char CLD = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3);
		if(!CLD)
		{
			APP_Set_Power_Relay(DRV_PWR_OFF);
                        Drv_Deinit_Setting();
			SET_BIT(appState.appError, APP_ERROR_RCCB);
			APP_Aggregate_Error();
			APP_Update_PanelState(PANEL_STAT_ERROR);
			updateDisp = 1;
		}
	}
	return updateDisp;
}

void APP_Calculate_Compensated_Temp(void)
{
	TEMPCOMP_Calculate_Offset(&appState.compOff);
	TEMPCOMP_Calculate_Offset(&appState.compOn);
	appState.tempComp100 = appState.adcReading->tempFiltered + appState.tempCalib - appState.compOff.offset - appState.compOn.offset;
        appState.tempComp75 = appState.adcReading->tempFiltered + appState.tempCalib - appState.compOff.offset - appState.compOn.offset*0.75;
        appState.tempComp50 = appState.adcReading->tempFiltered + appState.tempCalib - appState.compOff.offset - appState.compOn.offset*0.5;
        appState.tempComp25 = appState.adcReading->tempFiltered + appState.tempCalib - appState.compOff.offset - appState.compOn.offset*0.25;
        appState.tempComp0 = appState.adcReading->tempFiltered + appState.tempCalib - appState.compOff.offset;
	VAR_Set_Reg(STAT_TEMP_COMP, (unsigned short)(appState.tempComp100 * 10));
}

void APP_Buzzer_Play(void)
{
	if(appState.buzzerState.onTime == BUZZER_ON_OFF)
	{
		TIMING_Clear(&appState.buzzerState.timingBuzzer);
		Buzzer_PWR(OFF);
	}
	else if(((reg[PARAM_BUZZER_MODE] != 0) && (READ_BIT(reg[CMD_IO_CONTROL], IO_BIT_MANUAL) == 0)) ||
                 ((READ_BIT(reg[CMD_IO_CONTROL], IO_BIT_MANUAL) != 0) && (appState.buzzerState.onTime == BUZZER_ON_CONT)))
	{
		TIMING_Set_Limit(&appState.buzzerState.timingBuzzer, appState.buzzerState.onTime);
		TIMING_Start(&appState.buzzerState.timingBuzzer);
		Buzzer_PWR(ON);
	}
}

void APP_Buzzer_Play_Time(Buzzer_OnTimeTypeDef onTime)
{
	appState.buzzerState.onTime = onTime;
	APP_Buzzer_Play();
}

void APP_Buzzer_Reset(void)
{
	Buzzer_PWR(OFF);
	appState.buzzerState.onTime = BUZZER_ON_OFF;
	TIMING_Clear(&appState.buzzerState.timingBuzzer);
}

void APP_Handle_Buzzer(void)
{
	if(appState.buzzerState.onTime == BUZZER_ON_CONT)
	{
		if(appState.buzzerState.timingBuzzer.limit == BUZZER_ON_CONT)
		{
			Buzzer_PWR(OFF);
			TIMING_Set_Limit(&appState.buzzerState.timingBuzzer, 1000 - appState.buzzerState.onTime);
		}
		else
		{
			Buzzer_PWR(ON);
			TIMING_Set_Limit(&appState.buzzerState.timingBuzzer, appState.buzzerState.onTime);
		}
		TIMING_Start(&appState.buzzerState.timingBuzzer);
	}
	else
	{
		Buzzer_PWR(OFF);
		appState.buzzerState.onTime = BUZZER_ON_OFF;
	}
}

void APP_Clear_PressedKey(void)
{
	appState.pressedKey = KEY_NO;
	appState.pressType = PRESS_TYPE_UNKNOWN;
}

void APP_DisplayParam_Deinit(void)
{
	appState.displayParam = DISPLAY_PARAM_NO;
	TIMING_Clear(&appState.displayParamUpdate);
	TIMING_Clear(&appState.displayParamComingOut);
}

void APP_DisplayParam_Init(void)
{
	appState.displayParam = (DISPLAY_ParamTypeDef)1;
	APP_DisplayParam_Read();
	TIMING_Start(&appState.displayParamComingOut);
}

unsigned char APP_DisplayParam_Read(void)
{
	unsigned char needUpdate = 0;
	if(appState.displayParam != DISPLAY_PARAM_NO)
	{
		switch (appState.displayParam)
		{
		case DISPLAY_PARAM_DROP_RATE_LAST:
		{
			Drv_Cal_DropRate(DRV_DROPRATE_LAST);
			needUpdate = 1;
		}
		break;

		case DISPLAY_PARAM_DROP_RATE_TOTAL:
		{
			Drv_Cal_DropRate(DRV_DROPRATE_TOTAL);
			needUpdate = 1;
		}
		break;

		case DISPLAY_PARAM_VAC_INPUT:
			needUpdate = 1;
			break;

		case DISPLAY_PARAM_DC_BUS_VOL:
			Drv_Read_Register(DRV_REG_DC_BUS_VOLTAGE);
			break;

		case DISPLAY_PARAM_DRV_TEMP:
			Drv_Read_Register(DRV_REG_VTH);
			break;

		default:
			break;
		}

		TIMING_Start(&appState.displayParamUpdate);
	}
	return needUpdate;
}

void APP_Update_PanelState(PANEL_StateTypeDef newState)
{
	appState.panelState = newState;
	if(newState == PANEL_STAT_ERROR)
	{
		if(appState.timer.state == TIMER_IN_SETTING)
		{
			appState.timer.state = TIMER_OFF;
			TIMING_Clear(&appState.timer.timingSet);
		}
	}
	TIMING_Clear(&appState.display->blinkOff);
	TIMING_Clear(&appState.display->blinkOn);
        if(appState.panelState != PANEL_STAT_TEST)
        {
                VAR_Update_Reg_Bits(CMD_BITS, appState.panelState, BITS_PANEL_MODE, 2);
        }
}

void APP_Start_AutoPowerOn(void)
{
	if(appState.autoPowerOnMode == AUTO_MODE_AUTO)
	{
		if(appState.drvState->pwrStat != appState.drvSetting->pwrCmd)
		{
			TIMING_Start(&appState.timingAutoPowerOn);
		}
	}
}

void APP_Load_Parameters(void)
{
	appState.LcdNormalContrastLevel = reg[PARAM_BRIGTHNESS];
	Init_Display_Brightness(appState.LcdNormalContrastLevel);
	appState.LcdStandByContrastLevel = reg[PARAM_STANDBY_BRIGHTNESS];
	appState.timingStandby.limit = 1000 * reg[PARAM_STANDBY_ACTIVATION_TIME];
	appState.pumpMode = (AUTO_ModeTypeDef)reg[PARAM_PUMP_MODE];
	appState.tempCalib = (float)(reg[PARAM_TEMP_CALIBRATION] - 50.0) / 10.0;
	appState.autoSensitivity = reg[PARAM_AUTO_SENSITIVITY];
        appState.compOff.sensitivity = 100;
        appState.compOn.sensitivity = 100;
	appState.autoPowerOnMode = (AUTO_ModeTypeDef)reg[PARAM_AUTO_POWER_ON];
	appState.rccbEnable = (PowerState)reg[PARAM_RCCB_ENABLE];
	appState.timingValve.limit = 60000 * reg[PARAM_VALVE_ON_TIME];
        appState.maxMotorPower = 10*reg[PARAM_MAX_MOTOR_POWER];
}

void APP_TempComp_Init(void)
{
	appState.compOff.breakPointTempRatio = TEMPCOMP_OFF_BREAKPOINT_RATIO;
	appState.compOff.breakPointTime = TEMPCOMP_OFF_BREAKPOINT_TIME;
	appState.compOff.totalTime = TEMPCOMP_OFF_TOTAL_TIME;
	appState.compOff.elapsed.limit = (uint32_t)TEMPCOMP_OFF_TOTAL_TIME * 1000;
	appState.compOff.offset = 0;

	appState.compOn.breakPointTempRatio = TEMPCOMP_ON_BREAKPOINT_RATIO;
	appState.compOn.breakPointTime = TEMPCOMP_ON_BREAKPOINT_TIME;
	appState.compOn.totalTime = TEMPCOMP_ON_TOTAL_TIME;
	appState.compOn.elapsed.limit = (uint32_t)TEMPCOMP_ON_TOTAL_TIME * 1000;
	appState.compOn.offset = 0;

	TEMPCOMP_Off_Start(&appState.compOff);
}

signed short APP_Calculate_Watt(void)
{
	signed short watt;
	if(appState.drvSetting->pwrCmd == DRV_PWR_OFF)
	{
		watt = -1;
	}
	else
	{
		watt = (signed short)((float)Drv_Percent_To_Value(appState.drvSetting->setPointPercentX2) * appState.maxMotorPower / 4095);
	}
	return watt;
}

void APP_Set_Power_Relay(Drv_PowerTypedef state)
{
	Drv_Set_Power_Relay(state);
	TEMPCOMP_Start(&appState.compOn, APP_Calculate_Watt());
}

void APP_Set_Power(Drv_PowerTypedef pwrCmd, Drv_RunTypeDef runCmd)
{
        if(appState.autoMode == AUTO_MODE_AUTO)
        {
                  if(runCmd == DRV_RUN_START)
                  {
                          APP_Temp_To_Percent();
                  }
                  if(appState.pumpMode == AUTO_MODE_AUTO)
                  {
                          appState.drvSetting->pumpCmd = DRV_PWR_OFF;   // this variable is saved in the Drv_Set_Power
                  }
        }
	Drv_Set_Power(pwrCmd, runCmd);
	TEMPCOMP_Start(&appState.compOn, APP_Calculate_Watt());
}

void APP_Set_Setpoint(void)
{
	Drv_Set_Setpoint();
	TEMPCOMP_Start(&appState.compOn, APP_Calculate_Watt());
}

void APP_Send_Temperatures(void)
{
	char buffer[48];
	uint16_t setPointPercentValue = Drv_Percent_To_Value(appState.drvSetting->setPointPercentX2);
        appState.cntSec++;
        if(appState.cntSec >= 60)
        {
          appState.cntSec = 0;
          appState.cntMin++;
          if(appState.cntMin >= 60)
          {
            appState.cntMin = 0;
            appState.cntHour++;
          }
        }
        
	buffer[0] = 0;
        
        concatenateInt(buffer, appState.cntHour, "-");
        concatenateInt(buffer, appState.cntMin, "-");
        concatenateInt(buffer, appState.cntSec, ",");
	concatenateFloat(buffer, appState.adcReading->tempFiltered, 1, ",");
        concatenateFloat(buffer, appState.tempComp100, 1, ",");
        concatenateFloat(buffer, appState.tempComp75, 1, ",");
        concatenateFloat(buffer, appState.tempComp50, 1, ",");
        concatenateFloat(buffer, appState.tempComp25, 1, ",");
        concatenateFloat(buffer, appState.tempComp0, 1, ",");
	concatenateFloat(buffer, appState.adcReading->tempFiltered2, 1, ",");
	concatenateInt(buffer, setPointPercentValue, ",");
        concatenateInt(buffer, appState.drvState->pwrStat, ",");
        concatenateInt(buffer, appState.drvState->drvLimitFlag, "");

	UART_Send(2, buffer, String_Length(buffer));
}
