/*
 * variables.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Masoud Shahrabi
 */

#ifndef VARIABLES_H_
#define VARIABLES_H_
   

#define varLen			100
#define writableVarLen	        68

extern unsigned short reg[varLen];


// Readable/Writable variables
#define CLEAR_FAULT                     1       // it auto clears
#define KEY_LOCKED                      2
//#define YEAR			        3
//#define MONTH				4
//#define DAY				5
//#define HOUR				6
//#define MINUTE		        7
//#define SECOND			8
#define TIME                            9       // 2 registers
#define DAY_W_DATE                      11      // 2 registers
#define TIME_W_ON                       13      // 2 registers
#define TIME_W_OFF                      15      // 2 registers
#define TIME_D_ON                       17      // 2 registers
#define TIME_D_OFF                      19      // 2 registers
#define FIRST_BOOT_FLAG_AFTER_POWERON   21

// Readable/Writable/Savable variables
#define ID				22       // 2 registers
#define IDMODEL                         24       // 2 registers
#define POWER                           26
#define PUMP                            27
#define PFC                             28
#define AUTO_MODE                       29
#define THERMAL_OR_COOLER_MODE          30
#define SPEED_SETPOINT                  31
#define TEMPERATURE_SETPOINT            32
#define FIRST_BOOT_IS_PASSED            33

// Readable/Writable/Savable variables - setting parameters value
#define buzzer_status                   36       // SETTING_PARAMETER_1_VALUE
#define lcd_brightness_level            37       // SETTING_PARAMETER_2_VALUE
#define lcd_standby_brightness_level    38       // SETTING_PARAMETER_3_VALUE
#define lcd_standBy_time                39       // SETTING_PARAMETER_4_VALUE
#define temp_calibration_setpoint       40       // SETTING_PARAMETER_5_VALUE     in terms of 0.1 degree
#define AUTO_MODE_SENSITIVITY           41       // SETTING_PARAMETER_6_VALUE     VAR: 1 to 5 ( 0% to 100% of the speed will be spreaded within [VAR] degree)
#define SPEED_MIN_PERCENT_REG           42       // SETTING_PARAMETER_7_VALUE
#define SPEED_MAX_PERCENT_REG           43       // SETTING_PARAMETER_8_VALUE
#define TRQ_MIN_PERCENT                 44       // SETTING_PARAMETER_9_VALUE
#define TRQ_MAX_PERCENT                 45       // SETTING_PARAMETER_10_VALUE
#define MOTOR_CONTROL_MODE              46       // SETTING_PARAMETER_11_VALUE     1:speedControl and 2:torqueControl and 3:powerControl
#define MOTOR_SPIN_DIRECTION            47       // SETTING_PARAMETER_12_VALUE     0:forward and 1:Reverse
#define REMOTE_CLEAR                    48       // SETTING_PARAMETER_13_VALUE     (if this parameter is 1 learning remote is available by pressing remote key )
#define AUTO_POWER_ON                   49       // SETTING_PARAMETER_14_VALUE     : auto power on after the power is connected if motor was unexpectedly turned off
#define AUTO_POWER_IF_AC_IN_RANGE       50       // SETTING_PARAMETER_15_VALUE     1: if the ac voltage goes out of range and comes back to the range again , the driver relay will be turned on automatically
#define AUTO_PUMP_IN_AUTO_MODE          51       // SETTING_PARAMETER_16_VALUE     1:  in the auto mode the pump will be automatically turned on and off depending whether the motor is on or off
#define ENV_OR_DRIVER_TEMP_SHOW         52       // SETTING_PARAMETER_17_VALUE     0 : environment Ntc Temperature    1: driver NTC temperature    2: water level sensor and other statuses    3:DC bus voltage
#define DRIVER_SCRIPT_EN                53       // SETTING_PARAMETER_18_VALUE     0 : driver Scripting Disable       1: driver Scripting Enabled
#define IMC_CODE_VERSION                54       // SETTING_PARAMETER_19_VALUE     IMC code firmWare version: 0: old     1: New
#define DRIVER_CONFIG_NUM               55       // SETTING_PARAMETER_20_VALUE     we are able to choose betwen 14 different driver configs(these configs are written in driver micro and we tell driver to work with the one we choose)
#define VALVE_CLOSURE_TIMEOUT           56       // SETTING_PARAMETER_21_VALUE     in the scale of minute (1 to 5)
#define LIFE_GUARD_ENABLE               57       // SETTING_PARAMETER_22_VALUE     if 1, then the lifeguard is enabled
#define WIFI_AUTO_CONNECT               58       // SETTING_PARAMETER_23_VALUE     if 1 : auto connect is enabled , if 0 : auto connect is disabled
#define ACCURACY_OF_GBL_PCKT_RECEIVE    59       // SETTING_PARAMETER_24_VALUE     (will work all the time)the number of correct received packets to the number of total expected
#define ACCURACY_OF_LOC_PCKT_RECEIVE    60       // SETTING_PARAMETER_25_VALUE     (will be calculated while the pannel is ON , and it'll be reset by turning the pannel off )the number of correct received packets to the number of total expected
#define RESET_FACTORY                   61       // SETTING_PARAMETER_26_VALUE     resets the parameters to their default values
#define FIRMWARE_VERSION                62       // SETTING_PARAMETER_27_VALUE     shows the code firmWare version

#define START_OF_PARAMS                 buzzer_status
#define END_OF_PARAMS                   FIRMWARE_VERSION

// IO control register
#define IO_CONTROL_REG                  END_OF_PARAMS + 2      // reg number 64

// Readable variables
#define SPEED                           END_OF_PARAMS + 6
#define TORQUE                          END_OF_PARAMS + 7
#define TEMPERATURE                     END_OF_PARAMS + 8
#define DRIVERTEMPERATURE               END_OF_PARAMS + 9
#define FAULTS                          END_OF_PARAMS + 10      // 2 registers
#define SW_VERSION                      END_OF_PARAMS + 12
#define HW_VERSION                      END_OF_PARAMS + 13
#define TOUCH                           END_OF_PARAMS + 14
#define RF_KEY                          END_OF_PARAMS + 15
#define INPUT_AC_VOLTAGE                END_OF_PARAMS + 16
#define ONE_WIRE_VOLTAGE                END_OF_PARAMS + 17
#define STATUS                          END_OF_PARAMS + 18

#define START_OF_READABLE               SPEED
#define END_OF_READABLE                 STATUS

// remote FLASH Addresses
#define START_OF_REMOTE_ADDRESS         END_OF_READABLE + 2
#define END_OF_REMOTE_ADDRESS           START_OF_REMOTE_ADDRESS + NUMBER_OF_REMOTES - 1

// status register bits definations
#define OW_CONNECT                      1
#define AC_VLT_HIGH                     2
#define AC_VLT_LOW                      4
#define RCCB                            8

// IO-control register bits defination
#define IO_BACKLIGHT                       1
#define IO_RF_KEY                          2
#define IO_SIG_RELAY                       4
#define IO_USART_DIR                       8
#define IO_POW_RELAY                       16
#define IO_CMD_CLK                         32
#define IO_BUZZER_ON                       64
#define IO_RF_CLEAR                        128
#define IO_ALL_LCD_FIGS_ON                 256
#define IO_ALL_LCD_FIGS_OFF                512
#define IO_Manual_Bit                      32768


// defined values
#define DEFUALT_MIN_CURR_PERCENT        185     // in tenth of percent, is less than 1.5 ampere
#define DEFUALT_MAX_CURR_PERCENT        625     // in tenth of percent, is equal to 5 ampere
#define DEFUALT_TEMP_CALIB_SETPOINT     50      // it means 0 if setpoint is 51 then value(51-50)/10 is added to calculated temp
#define DEFUALT_AUTO_SENSITIVITY        2
#define MAX_KEY_LOCK_TIMEOUT            4+1     // in seconds ( 4 seconds is for key timeout (1 is added to timeout right after pressing the lock buttoms "1 isnt counted as 1 second")
#define MAX_POWER_OFF_TRY_COUNT         1       // maximum number of tries for turning off motor if timed-out error exist
#define DRIVER_SPEED_CTRL_MODE          1
#define DRIVER_CURRENT_CTRL_MODE        2
#define DRIVER_POWER_CTRL_MODE          3
#define MAX_LEARN_TIME                  5
#define MAX_LEARNED_KEYS_RESET_TIME     10
#define NUMBER_OF_REMOTES               5

// pertinent temperature offset defined variables 
#define TEMP_OFFSET_POWER_OFF_TIMEOUT   72*60   // 1.09h , the maximum timeout for the temp-offset in which once the pannel power is connected
#define TEMP_OFFSET_FROM_POWER_ONTOOFF_TIMEOUT 3600 // 1h , the maximum timeout for the temp-offset from the powerOn state to powerOff state
#define TEMP_OFFSET_ONCE_SPEED_CHANGES_TIMEOUT 3000 // 50 min , the maximum timeout for the temp-offset once the spd(or power) percent is changed

#endif /* VARIABLES_H_ */