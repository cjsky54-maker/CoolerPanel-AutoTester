/*
 * adc_reading.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_ADC_READING_H_
#define OTHER_LIB_INC_ADC_READING_H_
#include "variables.h"

   
#define ADC_CH_NUM      3 
#define ADC_CH_BUF_LEN  70
//#ifdef RELEASE
  #define OW_MIN_VOLTAGE  2.2
  #define OW_MAX_VOLTAGE  3.3
//#elif defined(DEBUG)
//  #define OW_MIN_VOLTAGE  1
//  #define OW_MAX_VOLTAGE  2
//#endif

#define AC_MIN_VOLTAGE_INSIDE  210
#define AC_MAX_VOLTAGE_INSIDE  230

#define AC_MIN_VOLTAGE_OUTSIDE  200
#define AC_MAX_VOLTAGE_OUTSIDE  240

#define MAX_AC_VOLTAGE_IN_RANGE_TIMER_COUNTER  40
typedef struct
{
  float temp;		                // the temprature in degree
  float owVol;                          // the open wire voltage in V
  float acVol;                          // the AC voltage in V
  float adcAvg[ADC_CH_NUM]; 	        // average of ADC raw data
  unsigned long adcSum[ADC_CH_NUM];     // sum of ADC raw data
  unsigned char owLineConnected;        // if the line physically connected this value becomes 1
  unsigned char acVoltageInRange;       // if the ac voltage is in range this value becomes 1 ,if higher than the range 2 and if lower than the range 0
  unsigned char acVoltageInRangeTimerCounter; // this counter counts while the ac-voltage is in the range till it reaches the value of MAX_AC_VOLTAGE_IN_RANGE_TIMER_COUNTER
} ADC_READING;

typedef enum
{
  AC_VOLTAGE = 0,
  OW_VOLTAGE = 1,
  TEMP = 2
} ADC_CHANNEL;
   
int findIndex(float target_resistance); 
float interpolateTemp(float target);
void adc1AveragingBuffer(unsigned short* ADCConvertedValue, ADC_READING* adcReading, ADC_CHANNEL i);
void calculateAdcValues(ADC_READING* adcReading,ADC_CHANNEL channelName); //should be called second in a loop

//setter & getter funcitons
void setAcVoltageInRangeTimerCounter(unsigned char value);
#endif /* OTHER_LIB_INC_ADC_READING_H_ */
