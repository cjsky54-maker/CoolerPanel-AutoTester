#include "ask_decoder.h"
#include "functions.h"

#define TIMx_GetOnTime()                TIM1_GetCapture1()
#define TIMx_GetPeriod()                TIM1_GetCapture2()
#define TIMx_ITConfig_CCx(NewState)     TIM1_ITConfig(TIM1_IT_CC2, NewState)

#define PERIOD_MIN      1050    // Minimum accepted period (in us)
#define PERIOD_MAX      1650    // Maximum accepted period (in us)
#define DUTY_0_MIN      0.2     // Minimum accepted
#define DUTY_0_MAX      0.3     // Minimum accepted
#define DUTY_1_MIN      0.7     // Minimum accepted
#define DUTY_1_MAX      0.8     // Minimum accepted



/**
  * @brief  Clears ASK_PACKET variables & enables CCx interrupt to start Reception
  * @note   Should be called inside update IRQ Handler
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_StartReception(ASK_PACKET* askPacket)
{
  if(askPacket->askPeriod == 0)
  {
    askPacket->rcvFlag = 0;
    askPacket->index = 0;
    askPacket->sigTot = 0;
    askPacket->sigAddr = 0;
    askPacket->sigData = 0;
    TIMx_ITConfig_CCx(ENABLE);
  }
  askPacket->askPeriod ++;
    
  if(askPacket->askPeriod == NUMBER_OF_DATA_IGNORE)
    askPacket->askPeriod = 0;
}


/**
  * @brief  Check every recieved pulse to decode the signal
  * @note   Should be called inside CCx IRQ Handler
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_HandleReception(ASK_PACKET* askPacket)
{
  askPacket->onTime = TIMx_GetOnTime();
  askPacket->period = TIMx_GetPeriod(); // Reading period clear CCx peinding interrupt bit
  if(askPacket->index > 1)
  {
    if (askPacket->period > PERIOD_MIN && askPacket->period < PERIOD_MAX)
    {
      askPacket->duty = (float)askPacket->onTime/(float)askPacket->period;
      if(askPacket->duty > DUTY_0_MIN && askPacket->duty < DUTY_0_MAX)
      {
        askPacket->sigTot <<= 1;
      }
      else if(askPacket->duty > DUTY_1_MIN && askPacket->duty < DUTY_1_MAX)
      {
        askPacket->sigTot <<= 1;
        askPacket->sigTot |= 1;
      }
      else
      {
        TIMx_ITConfig_CCx(DISABLE);
        return;
      }
    }
    else
    {
      TIMx_ITConfig_CCx(DISABLE);
      askPacket->pressingKey = 0;
      reg[RF_KEY] = 0x00;
      return;
    } 
  }
    
  askPacket->index++;
  if(askPacket->index== 26)
  {
    askPacket->sigData = askPacket->sigTot & 0xF;
    reg[RF_KEY] = askPacket->sigData;
    askPacket->sigAddr = askPacket->sigTot >> 8;
    TIMx_ITConfig_CCx(DISABLE);
    
    if(!getAppSettingsLearnKeyTimeout() && ASK_IsRemoteSaved(askPacket))
    {
      if(!askPacket->pressingKey)
        askPacket->pressingKey = 1;
      askPacket->rcvFlag = 1;
    }
    else if(getAppSettingsLearnKeyTimeout() && !ASK_IsRemoteSaved(askPacket))
    {
       ASK_SaveRemote(askPacket);
    }
  }
}


/**
  * @brief  Saves the remote control code to the EEPROM if valid data is received.
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
uint8_t ASK_SaveRemote(ASK_PACKET* askPacket)
{
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    if((reg[START_OF_REMOTE_ADDRESS + cnt] == 0x00) || (cnt == NUMBER_OF_REMOTES - 1))
    {
      reg[START_OF_REMOTE_ADDRESS + cnt] = askPacket->sigAddr;
      return eepromWriteData(START_OF_REMOTE_ADDRESS + cnt,(uint8_t*)&askPacket->sigAddr,2);
    }
  }
  return 0;
}


/**
  * @brief  checks if the remote which its data received is saved to EEPROM .
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
uint8_t ASK_IsRemoteSaved(ASK_PACKET* askPacket)
{
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    if(reg[START_OF_REMOTE_ADDRESS + cnt] == askPacket->sigAddr)
      return 1;
    else if(reg[START_OF_REMOTE_ADDRESS + cnt] == 0)
      return 0;
  }
  return 0;
}

/**
  * @brief  reads NUMBER_OF_REMOTES words from EEPROM to remoteAddresses[] .
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_ReadRemoteAddressesFromEepromToReg(void)
{
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    eepromReadData(START_OF_REMOTE_ADDRESS + cnt,(uint8_t*)&reg[START_OF_REMOTE_ADDRESS + cnt],2);
  }
}


/**
  * @brief  clear saved remotes from the reg and EEPROM .
  * @param  None
  * @retval None
  */
void ASK_ClearRemoteAddresses(void)
{
  eepromClear(START_OF_REMOTE_ADDRESS, NUMBER_OF_REMOTES);
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    reg[START_OF_REMOTE_ADDRESS + cnt] = 0;
  }
  ushortResetBit(&reg[IO_CONTROL_REG],IO_RF_CLEAR);
//  reg[IO_CONTROL_REG] &= ~(uint16_t)IO_RF_CLEAR;
//  reg[IO_CONTROL_REG] &= 0xFFFF - IO_RF_CLEAR;
}

/**
  * @brief  This function is called in corresponding interrupt handler once the signal is received.
  * @param  None
  * @retval None
  */
void ASK_Perform_Remote_Operations(ASK_PACKET* askPacket)
{
  if((askPacket->pressingKey == 1 && ((askPacket->sigData == REMOTE_POWER_CODE) || (askPacket->sigData == REMOTE_PUMPON_CODE) || (askPacket->sigData == REMOTE_PUMPOFF_CODE) || (askPacket->sigData == REMOTE_AUTOON_CODE) || (askPacket->sigData == REMOTE_AUTOOFF_CODE))) || ((askPacket->sigData == REMOTE_UP_CODE) || (askPacket->sigData == REMOTE_DOWN_CODE)))
  {
    Buzzer_Operation(Remote);
    Perform_Remote_Operations(askPacket->sigData);
    LCD_Glass_Update_By_State();
    
    setLcdIsInStandby(0);
    setLcdStandByTimer(0);
    LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast());
  }
  askPacket->pressingKey ++;
}