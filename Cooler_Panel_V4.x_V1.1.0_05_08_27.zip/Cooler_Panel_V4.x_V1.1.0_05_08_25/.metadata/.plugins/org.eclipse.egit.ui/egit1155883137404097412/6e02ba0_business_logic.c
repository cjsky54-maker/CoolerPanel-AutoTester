#include "business_logic.h"
#include "ask_decoder.h"
#include "bs818a_2.h"
#include "variables.h"
#include "functions.h"
#include "stm8l15x.h"


uint16_t cnt4=0;
unsigned char BuzzerFlag=0, BipBipDir = 0;;
const KEY_TYPE keyTocuhCor[7] = {KEY_DOWN, KEY_UP, KEY_CLOCK, KEY_POWER, KEY_WATER, KEY_AUTO, KEY_SETTINGS};
Buzzer_Type BuzzerType = None;
DRV_PACKET packet1;

//Null,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 ,16 ,17 ,18 ,19 ,20 -> parameter number : Null, buzzer, brightness lvl, sleep brightness lvl, sleeptime, tempSetpoint, autoModeSensitivity,  minSpeedPercent, maxSpeedPercentm, minTorquePercent, maxTorquePercent, motor control mode, motor spin direction, learn new remote(0:nothing,1:learn,2:resetLearnedKeys), auto power on after the power is unexpectedly turned off, select between speedpercent and driver ntc temperature for display on lcd(1:ntc temp , 0:speedpercent), IMC102 code firmware version, factoryReset, firmVersion
const uint16_t paramMinValue[NUMBER_OF_SETTING_PARAMETERS] = {0, 0, 1, 1, 15, 0, 1, 0, MINIMUM_MAX_RPM_PERCENT, 0, MAXIMUM_MIN_RPM_PERCENT, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1};
const uint16_t paramMaxValue[NUMBER_OF_SETTING_PARAMETERS] = {0, 2, 3, 3, 120, 100, 5, MAXIMUM_MIN_RPM_PERCENT, 1000, MINIMUM_MAX_RPM_PERCENT, 1000, 3 , 1, 1, 1, 1, 1, 3, 1, 1, 14, 5, 1, 1, 1, 1, 1, 1};
const uint8_t  paramStepValue[NUMBER_OF_SETTING_PARAMETERS]= {0, 1, 1, 1, 15, 1, 1, 5, 5, 5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0};

const uint8_t  paramScaleTable[NUMBER_OF_SETTING_PARAMETERS] = {0, 1, 1, 1, 1, 1, 1, 10, 10, 10, 10, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 10, 10, 1, 1};

const uint8_t degreeFigureTable[NUMBER_OF_SETTING_PARAMETERS] = {0, DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,
                                                           DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE};
const uint8_t percentFigureTable[NUMBER_OF_SETTING_PARAMETERS] = {0, DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,ENABLE ,ENABLE ,ENABLE ,ENABLE ,
                                                           DISABLE , DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,DISABLE ,ENABLE ,ENABLE ,DISABLE ,DISABLE};

const uint8_t finalTempTable[22] = {44,60,64,67,71,74,78,80,81,83,85,87,88,90,91,92,93,94,95,97,98,99}; //

RTC_InitTypeDef   RTC_InitStr;
RTC_TimeTypeDef   RTC_TimeStr;
RTC_DateTypeDef   RTC_DateStr;
//RTC_AlarmTypeDef  RTC_AlarmStr;

App_State appState;
App_Settings appSettings;


/**
  * @brief  this function Deinitialize the appstate parameters to their default values
  * @param  none
  * @retval none
  */
void Deinit_Appstate()
{
  appState.continuesUpPressTimeout = 0;
  appState.continuesDownPressTimeout = 0;
  appState.autoMode = 0;
  appState.thermalOrCoolerMode = Cooler;
  appState.speedSetPoint = 50;   // 25%
  appState.tempSetPoint = 50;    // 25 degrees
  appState.currentSetPoint = 0;
  appState.bleConnected = 0;
  appState.wifiConnected = 0;
  appState.pumpOn = 0;
  appState.valveOn = 0;
  appState.powerOn = 0;
  appState.powerRelayOn= 0;
  appState.pfcOn = 0;
  appState.fault = No_Fault;
  appState.actualSpeed = 50;    // 25%
  appState.actualTorque = 50;   // 25%
  appState.actualTemp = 0;      // 0 degrees
  appState.showableTemp = 0;    // 0 degrees
  appState.tempOffsetTimerOn = 0;
  appState.tempOffsetTimerOff = 0;
  appState.tempOffsetTimeOut = 0;
  appState.driverReceiveFlag = 0;
  appState.tempOffsetOn = 0;
  appState.tempOffset = 0;
  appState.tempOffsetOnStep1 = 0;
  appState.tempOffsetOnStep2 = 0;
  appState.tempOffsetOff = 0;
  appState.timerChangingTimeout = 0;
  appState.currentControlMode = 0;
  appState.speedMinPercent = DEFUALT_MIN_CURR_PERCENT;
  appState.speedMaxPercent = DEFUALT_MAX_CURR_PERCENT;
  appState.currentMinPercent = DEFUALT_MIN_CURR_PERCENT;
  appState.currentMaxPercent = DEFUALT_MAX_CURR_PERCENT;
  appState.weekActiveDays = 0;
  appState.weekTimeOn = -1;
  appState.weekTimeOff = -1;
  appState.dayTimeOn = -1;
  appState.dayTimeOff = -1;
  
  appState.nowTime = 1577836800;       // 2020-01-01:00:00:00
  appState.dayRefTime = 1577836800;
  appState.clockClrTimeOut = 0;        //by pressing and holding clock figure for specefic time(2.5 sec) the timer is cleared
  
  appState.pendingOff = 0;
  appState.pendingOn = 0;
  
  appState.speedMinChangingTimeout = 0;
  appState.speedMaxChangingTimeout = 0;
  
  appState.keyLock = 0;
  appState.keyLockTimeOut = 0;
  appState.startLearnTimeOut = 0;
  appState.keyLockBlink = 0; //when keys are locked and user touches any key the lcd blinks
  appState.keyBlinkTimeOut = 0; // 2 SECEONDS for blinking when touch is locked and user touches the screen
  appState.autoModeCtr = 0;
  appState.readFaultCtr = 0;
  appState.readStatusCtr = 0;
  appState.settingsTouched = 0;
  appState.pumpTouched = 0;
  appState.autoTouched = 0;
  appState.valveTimeout = 0;
  appState.lcdIsInStandby = 0;
  appState.lcdStandByTimer = 0;
  appState.drvStartTimeOut = 0;
  appState.drvStartTry = 0;
  appState.globalSucceedPackets = 0;
  appState.globalFailPackets = 0;
  appState.localSucceedPackets = 0;
  appState.localFailPackets = 0;
  appState.autoFlag = 0;
  appState.pumpFlag = 0;
  appState.powerFlag = 0;
  appState.speedSetpointFlag = 0;
  appState.tempSetpointFlag = 0;
  appState.oneWirePhysicallyConnected = 0;
  appState.acVoltageInRange = 0;
}


/**
  * @brief  this function Deinitialize the Appsetting parameters to their default values
  * @param  none
  * @retval none
  */
void Deinit_Appsettings()
{
  appSettings.keyPowerPressFlag = 0;
  appSettings.settingModeEnable = 0;
  appSettings.settingChangingTimeout = 0;
  appSettings.settingModeTimeout = 0;
  appSettings.learnKeyTimeout = 0;
  appSettings.currentParameter = 1;
  appSettings.parameterSelecting = 0;
  appSettings.parameterValueSetting = 0;
  appSettings.waitingForDrvResponse = 0;
  
  for(char cnt = MOTOR_SPIN_DIRECTION ; cnt <= END_OF_PARAMS - 1 ; cnt++)
  {
    if(cnt == AUTO_PUMP_IN_AUTO_MODE || cnt == IMC_CODE_VERSION || cnt == DRIVER_SCRIPT_EN || cnt == VALVE_CLOSURE_TIMEOUT || cnt == LIFE_GUARD_ENABLE || cnt == WIFI_AUTO_CONNECT)
      appSettings.parameterValue[cnt - START_OF_PARAMS + 1] = 1;
    else
      appSettings.parameterValue[cnt - START_OF_PARAMS + 1] = 0;
  }
  
  appSettings.parameterValue[1] = 0;
  appSettings.parameterValue[2] = 3;
  appSettings.parameterValue[3] = 1;
  appSettings.parameterValue[4] = 30;
  appSettings.parameterValue[5] = 50;
  appSettings.parameterValue[6] = 2;
  appSettings.parameterValue[7] = DEFUALT_MIN_CURR_PERCENT;
  appSettings.parameterValue[8] = DEFUALT_MAX_CURR_PERCENT;
  appSettings.parameterValue[9] = DEFUALT_MIN_CURR_PERCENT;
  appSettings.parameterValue[10] = DEFUALT_MAX_CURR_PERCENT;
  appSettings.parameterValue[11] = 3;
  appSettings.parameterValue[26] = CODE_VERSION;
  for(char cnt = 1 ; cnt <= END_OF_PARAMS - START_OF_PARAMS + 1 ; cnt++)
  {
    appSettings.parameterConfirmedValue[cnt] = appSettings.parameterValue[cnt];
  }
}


/**
  * @brief  this function perform touch keys functionality
  * @param  touches: 8-byte array which shows if each key is pressed    press: shows the number of pressed touch-keys at the sametime
  * @retval none
  */
void Perform_Touch_Operations(uint8_t* touches, uint8_t press)
{
  if (press)
  {
    if (!appState.powerOn && !touches[KEY_POWER])
        return;

    //if any key is touched reset the standby timer
    setLcdStandByTimer(0);
    
/////////////// checking the stand by mode and getting out of it if desirable situations are considered
    if (getLcdIsInStandby())
    {
      setLcdIsInStandby(0);
      LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast());
      LCD_Glass_Update_By_State();
      return ;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
    if(appState.keyLock == ON)
    {
      appState.keyBlinkTimeOut = 0;
      appState.keyLockBlink = 1;
      LCD_Glass_Update_By_State();
    }
    else
      Buzzer_Operation(Touch);
       
    for(uint8_t i=0;i<7;i++)
    {
      if(touches[i] == PRESSED)
      {
        switch(keyTocuhCor[i])
        {
          case KEY_DOWN:
          {
           if(appState.keyLock == OFF)
           {
            Perform_Key_Up_Down(KEY_DOWN);
            appState.continuesDownPressTimeout = 1;
           }
           else // if keys are locked
            Buzzer_Operation(Lock);
           break;
          }
          case KEY_UP:
          {
           if(appState.keyLock == OFF)
           {
            Perform_Key_Up_Down(KEY_UP);
            appState.continuesUpPressTimeout = 1;
           }
           else // if keys are locked
            Buzzer_Operation(Lock);
           break;
          }
          case KEY_CLOCK:
          {
            if(!appSettings.settingModeEnable && appState.fault == No_Fault)
            {
             if(appState.keyLock == OFF)
               Perform_Key_Clock();
             else // if keys are locked
               Buzzer_Operation(Lock);
            }
            break;
          }
          case KEY_POWER:
          {
           if(appState.keyLock == OFF)
            Perform_Key_Power();
           else // if keys are locked
             Buzzer_Operation(Lock);
           break;
          }
          case KEY_WATER:
          {
           if(appState.thermalOrCoolerMode == Cooler && appState.keyLock == OFF && touches[KEY_AUTO] == RELEASED && (!appState.autoMode || !reg[AUTO_PUMP_IN_AUTO_MODE]))
             appState.pumpTouched = 1;
//            Perform_Key_Pump();
           else if(appState.keyLock == ON)// if keys are locked
             Buzzer_Operation(Lock);
           break;
          }
          case KEY_AUTO:
          {
            if(appState.keyLock == OFF && touches[KEY_WATER] == PRESSED)
            {
              appState.autoTouched = 0;
              appState.pumpTouched = 0;
              Buzzer_PWR(OFF);
              appState.startLearnTimeOut = 1;
            }
            else if(appState.keyLock == OFF && touches[KEY_SETTINGS] == RELEASED)
              appState.autoTouched = 1;
//              Perform_Key_Auto();
            if(appState.keyLock == ON && touches[KEY_SETTINGS] == RELEASED)// if keys are locked
             Buzzer_Operation(Lock);
            break;
          }
          case KEY_SETTINGS:
          {
            //if(appState.keyLock == OFF)
            //  appState.settingsTouched = 1;
            if(touches[KEY_AUTO] == PRESSED)
            {
              appState.autoTouched = 0;
              appState.settingsTouched = 0;
              appState.keyLockTimeOut = 1;
              Buzzer_Operation(Lock);
            }
            else if(appState.keyLock == OFF)
              Perform_Key_Setting();
            else// if keys are locked
             Buzzer_Operation(Lock);
          }
        }
      }
    }
  }
  else // while releasing the touch keys
  {
    appState.continuesUpPressTimeout = 0;
    appState.continuesDownPressTimeout = 0;
    appState.startLearnTimeOut = 0;
    appState.keyLockTimeOut = 0;
    if(BuzzerFlag && reg[buzzer_status] == 2)
    {
      Buzzer_PWR(OFF);
      BuzzerFlag = 0;
      BuzzerType = None;
    }
    
    if (appState.settingsTouched)
    {
      appState.settingsTouched = 0;
      if (appState.fault != No_Fault && appState.fault != Driver_Current_Mismatch && !appSettings.settingModeEnable)
        Drv_Power(ON);
    }
    if (appState.pumpTouched)
    {
      appState.pumpTouched = 0;
      Perform_Key_Pump(0);
    }
    else if(appState.autoTouched)
    {
      appState.autoTouched = 0;
      Perform_Key_Auto();
    }
    if(appState.clockClrTimeOut)
    {
      appState.clockClrTimeOut = 0;
      appState.timerChangingTimeout = TIMER_CHANGING_TIMEOUT_MAX;
    }
  }
}


void Perform_Continues_Key_Press()
{
  if(appState.continuesUpPressTimeout > 0 && appState.continuesUpPressTimeout < 100)
    appState.continuesUpPressTimeout ++;
  if(appState.continuesUpPressTimeout == 100)
  {
    Perform_Key_Up_Down(KEY_UP);
    appState.continuesUpPressTimeout -= 13;
  }

  if(appState.continuesDownPressTimeout > 0 && appState.continuesDownPressTimeout < 100)
    appState.continuesDownPressTimeout ++;
  if(appState.continuesDownPressTimeout == 100)
  {
    Perform_Key_Up_Down(KEY_DOWN);
    appState.continuesDownPressTimeout -= 13;
  }
}


/**
  * @brief  While pressing KeyDown or KeyUp this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Up_Down(KEY_TYPE key_type)
{
  //////////////////////////// selecting current-parameter ////////////////////////////
  if(appSettings.settingModeEnable && appSettings.parameterSelecting)
  {
    appSettings.settingModeTimeout = SETTING_MODE_TIMEOUT;

    if(key_type == KEY_DOWN && appSettings.currentParameter > 1)
      appSettings.currentParameter --;
    else if(key_type == KEY_UP && appSettings.currentParameter < NUMBER_OF_SETTING_PARAMETERS - 1)
      appSettings.currentParameter ++;
    //update parameterNumber on lcd
    LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(appSettings);
    //update parameter value on lcd
    LCD_GLASS_UPDATE_PARAMETER_VALUE(appSettings);

    return;
  }
  //////////////////////////// setting parameter-value ////////////////////////////
  if(appSettings.settingModeEnable && appSettings.parameterValueSetting)
  {
    appSettings.settingChangingTimeout = SETTING_CHANGING_TIMEOUT;
    if(key_type == KEY_DOWN)
    {
      if(appSettings.parameterValue[appSettings.currentParameter] - paramMinValue[appSettings.currentParameter] >= paramStepValue[appSettings.currentParameter])
        appSettings.parameterValue[appSettings.currentParameter] -= paramStepValue[appSettings.currentParameter];
      else if (appSettings.parameterValue[appSettings.currentParameter] == paramMinValue[appSettings.currentParameter])
        appSettings.parameterValue[appSettings.currentParameter] = paramMaxValue[appSettings.currentParameter];
      else 
        appSettings.parameterValue[appSettings.currentParameter] = paramMinValue[appSettings.currentParameter];
    }
    else if(key_type == KEY_UP)
    {
      if(paramMaxValue[appSettings.currentParameter] - appSettings.parameterValue[appSettings.currentParameter] >= paramStepValue[appSettings.currentParameter])
        appSettings.parameterValue[appSettings.currentParameter] += paramStepValue[appSettings.currentParameter];
      else if(appSettings.parameterValue[appSettings.currentParameter] == paramMaxValue[appSettings.currentParameter])
        appSettings.parameterValue[appSettings.currentParameter] = paramMinValue[appSettings.currentParameter];
      else
        appSettings.parameterValue[appSettings.currentParameter] = paramMaxValue[appSettings.currentParameter];
    }
    LCD_GLASS_UPDATE_PARAMETER_VALUE(appSettings);
    return;
  }
  //////////////////////////// setting Timer for Power Off ////////////////////////////
  if (appState.timerChangingTimeout)
  {
    appState.timerChangingTimeout = TIMER_CHANGING_TIMEOUT_MAX;
    
    if (appState.dayTimeOff != -1)
    {
      if(key_type == KEY_DOWN)
      {
        if (appState.dayTimeOff - appState.nowTime > 3600)
        {
          uint8_t differenceTime = (appState.dayTimeOff - appState.nowTime - 1)/3600;
          appState.dayTimeOff = differenceTime*3600 + appState.nowTime;
          LCD_GLASS_Update_SevenSeg_Struct(0, differenceTime);
        }
        else
        {
          appState.timerChangingTimeout = 0;
          appState.dayTimeOff = -1;
          LCD_GLASS_Update_SevenSeg_Struct(0, 10);
          LCD_GLASS_Update_Fig_Struct(FIG_CLOCK, DISABLE);
        }
      }
      else if(key_type == KEY_UP)
      {
        if (appState.dayTimeOff - appState.nowTime < 8*3600)
        {
          uint8_t differenceTime = (appState.dayTimeOff - appState.nowTime - 1)/3600 + 2;
          appState.dayTimeOff = differenceTime*3600 + appState.nowTime;
          LCD_GLASS_Update_SevenSeg_Struct(0, differenceTime);
        }
        else if(appState.dayTimeOff - appState.nowTime < 9*3600)
        {
          appState.dayTimeOff = 9*3600 + appState.nowTime;
          LCD_GLASS_Update_SevenSeg_Struct(0, 9);
        }
      }
    }
  }
  //////////////////////////// setting the tempsetpoint or speedpercend according to the mode(speed or auto) ////////////////////////////
  else
  {
    if (appState.autoMode)
    {
      if(key_type == KEY_DOWN && appState.tempSetPoint > TEMP_SP_MIN*2)
      {
        appState.tempSetPoint--;
        eepromWriteData(TEMPERATURE_SETPOINT,(uint8_t*)&reg[TEMPERATURE_SETPOINT],2);
      }
      else if(key_type == KEY_UP && appState.tempSetPoint < TEMP_SP_MAX*2)
      {
        appState.tempSetPoint++;
        eepromWriteData(TEMPERATURE_SETPOINT,(uint8_t*)&reg[TEMPERATURE_SETPOINT],2);
      }
      reg[TEMPERATURE_SETPOINT] = appState.tempSetPoint;
      LCD_Glass_Update_By_State();
      appState.tempSetpointFlag = 1;
    }
    else
    {
      if (appState.speedSetPoint > 0 && key_type == KEY_DOWN)
        Drv_Set_Speed(appState.speedSetPoint - 10);
      else if(appState.speedSetPoint < 200 && key_type == KEY_UP)
        Drv_Set_Speed(appState.speedSetPoint + 10);
    }
  }
}


/**
  * @brief  While pressing Key_Clock this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Clock()
{
  if (appState.dayTimeOff != -1 && appState.timerChangingTimeout)
    appState.timerChangingTimeout = 1;
  else if(appState.dayTimeOff == -1)
  {
    appState.timerChangingTimeout = TIMER_CHANGING_TIMEOUT_MAX;
    appState.dayTimeOff = appState.nowTime + 3600;
    LCD_GLASS_Update_SevenSeg_Struct(0, 1);
    LCD_GLASS_Update_Fig_Struct(FIG_CLOCK, ENABLE);
  }
  else
    appState.clockClrTimeOut = 1;
}


/**
  * @brief  While pressing Key_Power this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Power()
{
  if (appState.powerOn)
  {
    // set power off
    Drv_Power(OFF);
    appState.pendingOff = 1;
    appSettings.keyPowerPressFlag = 1;
  }
  else
  {
    // set power on
    Drv_Power(ON);
    appState.powerOn = 1;
    reg[POWER] = 1;
    if(appState.powerRelayOn)
      appState.pendingOn = 1;
  }
  appState.powerFlag = 1;
}

/**
  * @brief  While pressing Key_Water this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Pump(uint8_t immidiate)
{
  if(!appState.valveOn && ((!appState.autoMode || !reg[AUTO_PUMP_IN_AUTO_MODE]) || immidiate) && appState.thermalOrCoolerMode == Cooler)
  {
    if (appState.pumpOn)
    {
      // set pump off
      Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_WRITE, DRV_REG_PUMP, OFF);
    }
    else
    {
      // set pump on
      Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_WRITE, DRV_REG_PUMP, ON);
    }
  }
  else
    appState.pumpFlag = 1;
}

/**
  * @brief  While pressing Key_Water for 4sec this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Valve()
{
  if (appState.valveOn)
  {
    // close valve
    Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_WRITE, DRV_REG_VALVE, OFF);
  }
  else
  {
    // open vavle
    Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_WRITE, DRV_REG_VALVE, ON);
  }
}


/**
  * @brief  While pressing Key_Auto this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Auto()
{
  if(appSettings.settingModeEnable && appSettings.parameterValueSetting)
  {
    appSettings.parameterValueSetting = 0;
    appSettings.parameterSelecting = 1;
    appSettings.settingChangingTimeout = 0;
    appSettings.settingModeTimeout = SETTING_MODE_TIMEOUT;
    appSettings.parameterValue[appSettings.currentParameter] = appSettings.parameterConfirmedValue[appSettings.currentParameter];
    LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(appSettings);
    LCD_GLASS_UPDATE_PARAMETER_VALUE(appSettings);
  }
  else if(appSettings.settingModeEnable && appSettings.parameterSelecting)
  {
    appSettings.parameterSelecting = 0;
    appSettings.settingChangingTimeout = 0;
    appSettings.settingModeEnable = 0;
    appSettings.currentParameter = 1;
    LCD_Glass_Update_By_State();
  }
  else
  {
    if (appState.autoMode)
    {
      appState.speedSetPoint = Drv_Calculate_Percent(); // autoSpeedSetPoint is poured in speedSetPoint
      // set auto mode off
      appState.autoMode = 0;
      reg[AUTO_MODE] = 0;
      eepromWriteData(AUTO_MODE, (uint8_t*)&reg[AUTO_MODE], 2);
      if((appState.actualSpeed && reg[MOTOR_CONTROL_MODE] == 1)||(appState.actualTorque && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)))
        Drv_Set_Speed(appState.speedSetPoint);
    }
    else
    {
      // set auto mode on
      appState.autoMode = 1;
      reg[AUTO_MODE] = 1;
      eepromWriteData(AUTO_MODE, (uint8_t*)&reg[AUTO_MODE], 2);
      Set_Auto_Speed(1);
    }
    appState.autoFlag = 1;
    LCD_Glass_Update_By_State();
  }
}


/**
  * @brief  While pressing Key_Setting this fucntion is called
  * @param  none
  * @retval none
  */
void Perform_Key_Setting()
{
  appState.settingsTouched = 1;
  if(appSettings.settingModeEnable && appSettings.parameterSelecting && (appSettings.currentParameter != (FIRMWARE_VERSION - START_OF_PARAMS + 1)) && (appSettings.currentParameter != (ACCURACY_OF_GBL_PCKT_RECEIVE - START_OF_PARAMS + 1)) && (appSettings.currentParameter != (ACCURACY_OF_LOC_PCKT_RECEIVE - START_OF_PARAMS + 1)))
  {
    appSettings.parameterSelecting = 0;
    appSettings.parameterValueSetting = 1;
    appSettings.settingChangingTimeout = SETTING_CHANGING_TIMEOUT;
    LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(appSettings);
  }
  else if(appSettings.settingModeEnable && appSettings.parameterValueSetting )//&& appSettings.currentParameter != (FIRMWARE_VERSION - START_OF_PARAMS + 1))
  {
    appSettings.settingChangingTimeout = 1;
    LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(appSettings);
  }
}

/**
  * @brief  this function counts for enabling the vavle(while holding the pump key)
  * @param  none
  * @retval none
  */
void Valve_OR_TermalMode_TurningOn_TimeOut()
{
  if(appState.pumpTouched > 0 && appState.pumpTouched < SETTING_ACTIVATION_TIME)
  {
    appState.pumpTouched++;
    if(appState.pumpTouched == SETTING_ACTIVATION_TIME)
    {
     Perform_Key_Valve();
     Buzzer_Operation(Valve);
     appState.pumpTouched = 0;
    }
    if(appState.pumpTouched == 50)
      Buzzer_PWR(OFF);
  }
  else if(appState.autoTouched > 0 && appState.autoTouched < SETTING_ACTIVATION_TIME)
  {
    appState.autoTouched++;
    if(appState.autoTouched == SETTING_ACTIVATION_TIME)
    {
     if(appState.thermalOrCoolerMode == Cooler)
     {
       if(appState.pumpOn)
         Perform_Key_Pump(1); // turn the pump off before entering the thermal mode and the pump wont work till the mode is thermal
       if(appState.valveOn)
         Perform_Key_Valve(); // turn the valve off before entering the thermal mode and the valve wont work till the mode is thermal
       appState.thermalOrCoolerMode = Thermal;
     }
     else
       appState.thermalOrCoolerMode = Cooler;
     reg[THERMAL_OR_COOLER_MODE] = appState.thermalOrCoolerMode;
     eepromWriteData(THERMAL_OR_COOLER_MODE, (uint8_t*)&reg[THERMAL_OR_COOLER_MODE], 2);
     eepromWriteDataFinishTimeOut();
     appState.autoTouched = 0;
     Buzzer_Operation(Valve);
    }
    if(appState.autoTouched == 50)
      Buzzer_PWR(OFF);
  }
}

/**
  * @brief  this function counts up to reach the max time out valve operation and then it will close the valve
  * @param  none
  * @retval none
  */
void Valve_Operation_TimeOut()
{
  if(appState.valveOn)
  {
    if(appState.valveTimeout < (appSettings.parameterConfirmedValue[VALVE_CLOSURE_TIMEOUT - START_OF_PARAMS + 1]*60))
      appState.valveTimeout += 1;
    else
    {
      appState.valveTimeout = 0;
      appState.pumpTouched = MAX_VALVE_STARTUP_TIMEOUT-1;
    }
  }    
}


/**
  * @brief  this function counts up to reach the max time out valve operation and then it will close the valve
  * @param  none
  * @retval none
  */
void Receive_Packet_Accuracy_Calculation()
{
  uint16_t globalAccuracy =  (1000*appState.globalSucceedPackets / (appState.globalSucceedPackets + appState.globalFailPackets));
  uint16_t localAccuracy = (1000*appState.localSucceedPackets / (appState.localSucceedPackets + appState.localFailPackets));
  if(!appState.powerOn)
  {
    appState.localSucceedPackets = 0;
    appState.localFailPackets = 0;
  }
  appSettings.parameterValue[ACCURACY_OF_GBL_PCKT_RECEIVE - START_OF_PARAMS + 1] = globalAccuracy;
  appSettings.parameterValue[ACCURACY_OF_LOC_PCKT_RECEIVE - START_OF_PARAMS + 1] = localAccuracy;
}


/**
  * @brief  this functions turns on buzzer according to the reg[buzzer_status]: [0] OFF , [1] a Bip , [2] turns buzzer on until releasing button(for touch mode) and will beep buzzer(for lock mode)
  * @param  none
  * @retval none
  */
void Buzzer_Operation(Buzzer_Type buzzerType)
{

  BuzzerType = buzzerType;
  
  if(BuzzerType == BipBip)
  {
    BuzzerFlag = 90;
    Buzzer_PWR(ON);
    return;
  }
  
  //turn of buzzer
  else if(BuzzerType == None)
  {
    Buzzer_PWR(OFF);
    BipBipDir = 0;
    BuzzerFlag = 0;
  }
  
  else if(reg[buzzer_status] != 0)
  {
    if(BuzzerType == Touch)
      BuzzerFlag = 5;           //5*10ms = 50ms
    else if(BuzzerType == Lock)
      BuzzerFlag = 5;           //5*10ms = 50ms
    else if(BuzzerType == Valve)
      BuzzerFlag = 50;          //50*10ms = 0.5sec
    else if (BuzzerType == Remote)
      BuzzerFlag = 2;           //2*10ms = 0.2sec
    else
      return;
    
    Buzzer_PWR(ON);
  }
  
}


/**
  * @brief  it is called in 25ms timer and after specific time like 2~3 * 25 ms (for touch mode) or 1~2 * 25ms (for lock mode) the buzzer is turned off ( if the buzzer mode or reg[buzzer_status] is not 0 this function will turn off buzzer)
  * @param  none
  * @retval none
  */
void Buzzer_TimeOut()
{
  //for performing touch and valve buzzer
  if((reg[buzzer_status] != 2 && BuzzerType == Touch) || BuzzerType == Lock || BuzzerType == Valve || BuzzerType == Remote)
  {
    if(BuzzerFlag > 0)
    {
      BuzzerFlag -= 1;
    }
    else
    {
      Buzzer_PWR(OFF);
      BuzzerFlag = 0;
      BuzzerType = None;
    }
  }
  if(BuzzerType == BipBip)
  {
    if(BipBipDir == 0)
      BuzzerFlag -= 9;
    else
      BuzzerFlag += 1;
    
    if(BuzzerFlag <= 0)
    {
      Buzzer_PWR(OFF);
      BipBipDir = 1;
    }
    else if(BuzzerFlag >= 90)
    {
      Buzzer_PWR(ON);
      BipBipDir = 0;
    }
  }
}


/**
  * @brief  this functions takes 4-bit data from rf module and perform some functionalities according to the taken value
  * @param  rfout : 4-bit data given from rf-module to micro according to the pressed key on remote
  * @retval none
  */
void Perform_Remote_Operations(uint8_t rfOut)
{
  if(reg[IO_CONTROL_REG] & IO_Manual_Bit)
    return;
  switch(rfOut)
  {
    case REMOTE_POWER_CODE:
    {
      Perform_Key_Power();
      break;
    }
    case REMOTE_UP_CODE:
    {
      if(appState.powerOn)
        Perform_Key_Up_Down(KEY_UP);
      break;
    }
    case REMOTE_DOWN_CODE:
    {
      if(appState.powerOn)
        Perform_Key_Up_Down(KEY_DOWN);
      break;
    }
#if REMOTE_TYPE == (WHITE || BW)
    case REMOTE_PUMPON_CODE:
    {
      if (appState.pumpOn == 0 && appState.powerOn)
        Perform_Key_Pump(0);
      break;
    }
    case REMOTE_PUMPOFF_CODE:
    {
      if (appState.pumpOn && appState.powerOn)
        Perform_Key_Pump(0);
      break;
    }
    case REMOTE_AUTOON_CODE:
    {
      if(appState.powerOn && appState.autoMode == 0)
        Perform_Key_Auto();
      break;
    }
    case REMOTE_AUTOOFF_CODE:
    {
      if(appState.powerOn && appState.autoMode)
        Perform_Key_Auto();
      break;
    }
#elif REMOTE_TYPE == BLACK
    case REMOTE_PUMP_CODE:
      {
        Perform_Key_Pump(0);
        break;
      }
    case REMOTE_AUTO_CODE:
      {
        if(appState.powerOn)
          Perform_Key_Auto();
        break;
      }
#endif
  }
}


/**
  * @brief  this function send driver the speed command to sets the motor speed according to the temperature
  * @param  immediately : if this input is 1 then the speedsetting command is immediately sent to driver
  * @retval none
  */
void Set_Auto_Speed(uint8_t immediately)
{
  if (appState.autoMode && appState.powerOn && !appState.pendingOff)
  {
    if (!immediately)
      if (appState.autoModeCtr++ < AUTO_MODE_COUNT_MAX)
        return;
    appState.autoModeCtr = 0;

    uint16_t desiredSpeed = Drv_Calculate_Percent();
    if (((appState.actualSpeed != desiredSpeed) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque != desiredSpeed) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)))
    {
      if(reg[AUTO_PUMP_IN_AUTO_MODE] && (!desiredSpeed && appState.pumpOn) || (desiredSpeed && !appState.pumpOn))
        Perform_Key_Pump(1);
      Drv_Set_Speed(desiredSpeed);
    }
  }
}


/**
  * @brief  this function generates the percent of the speed or torque
  * @param  none
  * @retval the percent value of speed or torque is returned
  */
uint16_t Drv_Calculate_Percent(void)
{
  uint16_t percent = appState.speedSetPoint;
  if(!percent)
    percent = 10 ;
  if (appState.autoMode && appState.thermalOrCoolerMode == Cooler)
  {
    if((appState.showableTemp*2 - appState.tempSetPoint) > 0)
    {
      float i = (float)(appState.showableTemp*2 - appState.tempSetPoint);
      i *= 100/appSettings.parameterConfirmedValue[AUTO_MODE_SENSITIVITY - START_OF_PARAMS + 1];
      if(i > 200)
       i=200;
      else if(i<10)
       i = 0;
      else
       i+=0.5;
      percent = (uint16_t)i;
    }
    else
      percent = 0;
  }
  else if (appState.autoMode && appState.thermalOrCoolerMode == Thermal)
  {
    if((appState.tempSetPoint - appState.showableTemp*2) > 0)
    {
      float i = (float)(appState.tempSetPoint - appState.showableTemp*2);
      i *= 100/appSettings.parameterConfirmedValue[AUTO_MODE_SENSITIVITY - START_OF_PARAMS + 1];
      if(i > 200)
       i=200;
      else if(i<10)
       i = 0;
      else
       i+=0.5;
      percent = (uint16_t)i;
    }
    else
      percent = 0;
  }
  return percent;
}

/**
  * @brief  this function generates the percent of the speed or torque considering the min and max percent set in the parameters-set
  * @param  none
  * @retval the percent value of speed or torque in real form
  */
uint8_t Drv_Calculate_Real_Percent(void)
{
  uint8_t percent;
  if(reg[MOTOR_CONTROL_MODE] == 1)
    percent = (uint8_t)(((((float)appState.actualSpeed/200 ) * ((float)(reg[SPEED_MAX_PERCENT_REG]-reg[SPEED_MIN_PERCENT_REG])/1000)) + ((float)reg[SPEED_MIN_PERCENT_REG]/1000))*100);
  else
    percent = (uint8_t)(((((float)appState.actualTorque/200 ) * ((float)(reg[TRQ_MAX_PERCENT]-reg[TRQ_MIN_PERCENT])/1000)) + ((float)reg[TRQ_MIN_PERCENT]/1000))*100);
  percent = (percent + 2) / 5 * 5;
  return percent/5;
}

/**
  * @brief  this function is called every seconds in order to update the setting timer , pending off or on to retry powering driver off or on (if former commands are unsuccessful) and timer time out(for powering driver off or on in regular date and time)
  * @param  none
  * @retval none
  */
void Check_Timer()
{
  if (appState.timerChangingTimeout)
  {
    appState.timerChangingTimeout--;
    if (appState.timerChangingTimeout == 0)
    {
      Buzzer_Operation(Valve);
    }
    return;
  }
  
  if (appState.powerOn)
  {
    if (appState.pendingOff)
    {
      if (appState.pendingOff++ <= 100)
      {
        if (appState.pendingOff % 10 == 0)
          Drv_Power(OFF);
      }
      else
        appState.pendingOff = 0;
      
      return;
    }
    
    else if (appState.pendingOn)
    {
      if (appState.pendingOn++ <= 100)
      {
        if (appState.pendingOn % 10 == 0)
          Drv_Power(ON);
      }
      else
        appState.pendingOn = 0;
      
      return;
    }
    
    if ((appState.dayTimeOff != -1) && (appState.dayTimeOff - appState.nowTime <= 0) && (appState.nowTime - appState.dayTimeOff < 10))
    {
      appState.pendingOff = 1;
      Drv_Power(OFF);
      Buzzer_Operation(Valve);
    }
    else if (Is_Timer_Active_Today())
    {
      if ((appState.weekTimeOff != -1) && (appState.weekTimeOff - (appState.nowTime - appState.dayRefTime) <= 0) && ((appState.nowTime - appState.dayRefTime) - appState.weekTimeOff < 10))
      {
        appState.weekTimeOff = -1;
        appState.pendingOff = 1;
        Drv_Power(OFF);
        Buzzer_Operation(Valve);
      }
    }
  }
  else
  {
    if ((appState.dayTimeOn != -1) && (appState.dayTimeOn - appState.nowTime <= 0) && (appState.nowTime - appState.dayTimeOn < 10))
    {
      appState.dayTimeOn = -1;
      Drv_Power(ON);
      if(appState.powerRelayOn)
        appState.pendingOn = 1;
      Buzzer_Operation(Valve);
    }
    else if (Is_Timer_Active_Today())
    {
      if ((appState.weekTimeOn != -1) && (appState.weekTimeOn - (appState.nowTime - appState.dayRefTime) <= 0) && ((appState.nowTime - appState.dayRefTime) - appState.weekTimeOn < 10))
      {
        appState.weekTimeOn = -1;
        Drv_Power(ON);
        if(appState.powerRelayOn)
          appState.pendingOn = 1;
        Buzzer_Operation(Valve);
      }
    }
  }
}


/**
  * @brief  every 25ms this function is called in order to Count Up the clockClrTimeOut , in order to clear the dayTimeOff at which the timeout reaches the specified value(like 100 for 2500ms)
  * @param  none
  * @retval none
  */
void Clear_Clock_TimeOut()
{
  if(appState.clockClrTimeOut > 0)
  {
    appState.clockClrTimeOut ++;
    if(appState.clockClrTimeOut >= CLOCK_CLEAR_MAX_TIMEOUT)
    {
      appState.clockClrTimeOut = 0;
      appState.dayTimeOff = -1;
    }
  }
}


/**
  * @brief  every seconds this function is called in order to update setting parameters and setting values and operate their functionality
  * @param  none
  * @retval none
  */
void Check_Settings_Operations()
{
  if (appSettings.learnKeyTimeout > 0)
  {
    appSettings.learnKeyTimeout -- ;
    if(appSettings.learnKeyTimeout == 0)
    {
      LearnKeyOperation(0);
      if(appSettings.settingModeEnable)
        appSettings.settingModeTimeout = SETTING_MODE_TIMEOUT;
      appSettings.parameterValue[REMOTE_CLEAR - START_OF_PARAMS + 1] = appSettings.parameterConfirmedValue[REMOTE_CLEAR - START_OF_PARAMS + 1];
      Buzzer_Operation(Valve);
      ushortResetBit(&reg[IO_CONTROL_REG],IO_RF_CLEAR|IO_RF_KEY);
//      reg[IO_CONTROL_REG] &= ~(uint16_t)(IO_RF_CLEAR|IO_RF_KEY);
//      reg[IO_CONTROL_REG] &= 0xFFFF - (IO_RF_CLEAR|IO_RF_KEY);
    }
  }
    
  // decreasing parameter value setting timer
  if(appSettings.settingChangingTimeout && appSettings.parameterValueSetting)
  {
    appSettings.settingChangingTimeout--;
    if(appSettings.settingChangingTimeout == 0)
    {
      appSettings.settingModeEnable = 1;
      appSettings.parameterSelecting = 1;
      appSettings.parameterValueSetting = 0;
      appSettings.settingModeTimeout = SETTING_MODE_TIMEOUT;
      Parameter_Change_Operation();
      Buzzer_Operation(Valve);
    }
  }
  // decreasing parameter selection timer
  if(appSettings.settingModeTimeout && appSettings.parameterSelecting)
  {
    appSettings.settingModeTimeout --;
    if(appSettings.settingModeTimeout == 0)
    {
      appSettings.settingModeEnable = 0;
      appSettings.parameterSelecting = 0;
      appSettings.parameterValueSetting = 0;
      appSettings.settingChangingTimeout = 0;
      appSettings.currentParameter = 1;
    }
  }
}


/**
  * @brief  this function is used in the Check_Settings_Operations to apply changes corresponding to parameters
  * @param  none
  * @retval none
  */
void Parameter_Change_Operation()
{
  if((appSettings.currentParameter == RESET_FACTORY - START_OF_PARAMS + 1) && (appSettings.parameterValue[RESET_FACTORY - START_OF_PARAMS + 1])) // if current param is reset factory then reset param values 
  {
    Reset_Setting_Parameters_To_Default_Values();
    Drv_Ctrl_Mode_Select(DRIVER_POWER_CTRL_MODE);
    if(reg[DRIVER_CONFIG_NUM] != 0)
    {
      DRV_PACKET packet;
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, reg[DRIVER_CONFIG_NUM]);
    }
  }
  else
  {
    // if current parameter is for setting standby brightness lvl
    if((appSettings.currentParameter == (lcd_standby_brightness_level - START_OF_PARAMS + 1)) && (appSettings.parameterValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] > reg[lcd_brightness_level]))
      {
        appSettings.parameterValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] = reg[lcd_brightness_level];
        appSettings.parameterConfirmedValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] = reg[lcd_brightness_level];
        reg[lcd_standby_brightness_level] = reg[lcd_brightness_level];
        eepromWriteData(lcd_standby_brightness_level, (uint8_t*)&reg[lcd_standby_brightness_level], 2);
      }
    // if current parameter is for setting normal brightness lvl
    else if((appSettings.currentParameter == (lcd_brightness_level - START_OF_PARAMS + 1)) && (reg[lcd_standby_brightness_level] > appSettings.parameterValue[lcd_brightness_level - START_OF_PARAMS + 1]))
      {
        appSettings.parameterConfirmedValue[lcd_brightness_level - START_OF_PARAMS + 1] = appSettings.parameterValue[lcd_brightness_level - START_OF_PARAMS + 1];
        reg[lcd_brightness_level] = appSettings.parameterConfirmedValue[lcd_brightness_level - START_OF_PARAMS + 1];
        eepromWriteData(lcd_brightness_level, (uint8_t*)&reg[lcd_brightness_level], 2);
        
        eepromWriteDataFinishTimeOut();
        
        appSettings.parameterValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] = reg[lcd_brightness_level];
        appSettings.parameterConfirmedValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] = reg[lcd_brightness_level];
        reg[lcd_standby_brightness_level] = appSettings.parameterConfirmedValue[lcd_standby_brightness_level - START_OF_PARAMS + 1];
        eepromWriteData(lcd_standby_brightness_level, (uint8_t*)&reg[lcd_standby_brightness_level], 2);
      }
    else if((appSettings.currentParameter != (REMOTE_CLEAR - START_OF_PARAMS + 1)) && (appSettings.currentParameter != (MOTOR_CONTROL_MODE - START_OF_PARAMS + 1)) && (appSettings.currentParameter != (DRIVER_CONFIG_NUM - START_OF_PARAMS + 1) || appSettings.parameterValue[appSettings.currentParameter] == 0) && (appSettings.currentParameter != (WIFI_AUTO_CONNECT - START_OF_PARAMS + 1)))
     {
       appSettings.parameterConfirmedValue[appSettings.currentParameter] = appSettings.parameterValue[appSettings.currentParameter];
       reg[appSettings.currentParameter + START_OF_PARAMS - 1] = appSettings.parameterConfirmedValue[appSettings.currentParameter];
       eepromWriteData(appSettings.currentParameter + START_OF_PARAMS - 1, (uint8_t*)&reg[appSettings.currentParameter + START_OF_PARAMS - 1], 2); // write confirmed parameter value in eeprom(START_OF_PARAMS - 1 + parameter number : is the location of eeprom for writing confirmed data on)
     }
    
    if(appSettings.currentParameter == lcd_brightness_level - START_OF_PARAMS + 1) // if current param is brightness lvl
       LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast());
    
    if(appSettings.currentParameter == MOTOR_CONTROL_MODE - START_OF_PARAMS + 1)
    {
      Drv_Ctrl_Mode_Select(appSettings.parameterValue[appSettings.currentParameter]);
//          if(appSettings.parameterValue[appSettings.currentParameter] == 0 || appSettings.parameterValue[appSettings.currentParameter] == 2)
//            Drv_Ctrl_Mode_Select(DRIVER_SPEED_CTRL_MODE);
//          else if(appSettings.parameterValue[appSettings.currentParameter] == 1)
//            Drv_Ctrl_Mode_Select(DRIVER_CURRENT_CTRL_MODE);
//          appSettings.waitingForDrvResponse = 1;
    }
    
    if((appSettings.currentParameter == MOTOR_SPIN_DIRECTION - START_OF_PARAMS + 1))
    {
      appSettings.parameterConfirmedValue[appSettings.currentParameter] = appSettings.parameterValue[appSettings.currentParameter];
      reg[appSettings.currentParameter + START_OF_PARAMS - 1] = appSettings.parameterConfirmedValue[appSettings.currentParameter];
      eepromWriteData(appSettings.currentParameter + START_OF_PARAMS - 1, (uint8_t*)&reg[appSettings.currentParameter + START_OF_PARAMS - 1], 2);
      Drv_Set_direction();
    }
    if(appSettings.currentParameter == REMOTE_CLEAR - START_OF_PARAMS + 1)
    {
      delay_ms(1);
      if(appSettings.parameterValue[appSettings.currentParameter] == 1) // reset the learned remotes
      {
#if RF_MDL_TYPE == CY41
        ASK_ClearRemoteAddresses();
        appSettings.parameterValue[REMOTE_CLEAR - START_OF_PARAMS + 1] = appSettings.parameterConfirmedValue[REMOTE_CLEAR - START_OF_PARAMS + 1];        
#elif RF_MDL_TYPE == RXC6
        LearnKeyOperation(2);
#endif
      }
    }
    
    if(appSettings.currentParameter == DRIVER_SCRIPT_EN -START_OF_PARAMS + 1)
    {
      if(!Drv_Get_Queue_Command_Cnt())
      {
        Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_WRITE, DRV_REG_SCRIPT, appSettings.parameterValue[appSettings.currentParameter]);
      }
    }
    if(appSettings.currentParameter == DRIVER_CONFIG_NUM - START_OF_PARAMS + 1)
    {
      Drv_Parameter_command(appSettings.parameterValue[appSettings.currentParameter]);
      if(appSettings.parameterValue[appSettings.currentParameter] != 0)
        appSettings.waitingForDrvResponse = 1;
    }
//    if(appSettings.currentParameter == WIFI_AUTO_CONNECT - START_OF_PARAMS + 1)
//    {
//      
//    }
  }
}


/**
  * @brief  every 5 seconds the readfault command is sent to driver via this function
  * @param  none
  * @retval none
  */
void Check_Fault()
{
  if (++appState.readFaultCtr >= READ_FAULT_PERIOD)
  {
    appState.readFaultCtr = 0;
    Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_READ_STATUS, DRV_REG_FAULT, 0x0000);
  }
}

/**
  * @brief  every 5 seconds the Checkstatus command is sent to driver via this function
  * @param  none
  * @retval none
  */
void Check_Drv_Status()
{
  if(++appState.readStatusCtr >= READ_FAULT_PERIOD)
  {
    appState.readStatusCtr = 0;
    Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_READ, DRV_REG_LIMIT_FLAG, 0x0000);
  }
}

/**
  * @brief  every second the driver temp read command is sent to driver via this function
  * @param  none
  * @retval none
  */
void Check_Drv_Temp()
{
  if(++appState.readStatusCtr >= READ_TEMP_PERIOD)
  {
    appState.readStatusCtr = 0;
    Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_READ, DRV_REG_VTH, 0x0000);
  }
}

/**
  * @brief  every second the driver dc bus voltage read command is sent to driver via this function
  * @param  none
  * @retval none
  */
void Check_Drv_Dc_Bus_Voltage()
{
  if(++appState.readStatusCtr >= READ_TEMP_PERIOD)
  {
    appState.readStatusCtr = 0;
    Drv_Fill_Generate_Send_Packet(&packet1, DRV_CMD_READ, DRV_REG_DC_BUS_VOLTAGE, 0x0000);
  }
}



/**
  * @brief  while setting and auto key are pressed at the same time this function is called 4 times for 4 to 3 seconds to lock the lcd screen
  * @param  none
  * @retval none
  */
void LockingLcdTimeoutCounter()
{
  if(appState.keyLockTimeOut > 0)
  {
    appState.keyLockTimeOut++;
    if(appState.keyLockTimeOut == MAX_KEY_LOCK_TIMEOUT)
    {
      if(appState.keyLock == ON)
        appState.keyLock = OFF;
      else if(appState.keyLock == OFF)
        appState.keyLock = ON;
      reg[KEY_LOCKED] = appState.keyLock;
      appState.keyLockTimeOut = 0;
      Buzzer_Operation(Valve);
    }
  }
}

void startLearnTimeoutCounter()
{
  if(appState.startLearnTimeOut > 0)
  {
    appState.startLearnTimeOut++;
    if(appState.startLearnTimeOut == MAX_KEY_LOCK_TIMEOUT)
    {
      appState.startLearnTimeOut = 0;
#if RF_MDL_TYPE == RXC6
      LearnKeyOperation(1);
#elif RF_MDL_TYPE == CY41
      appSettings.learnKeyTimeout = MAX_LEARN_TIME;
#endif
      Buzzer_Operation(Valve);
    }
  }
}

/**
  * @brief  while pressing and holding the setting key for 4 seconds this function is called to enable setting mode
  * @param  none
  * @retval none
  */
void SettingStartUpTimeoutCounter()
{
  if(appState.settingsTouched && cnt4 < SETTING_ACTIVATION_TIME)
  {
   cnt4++;
   if(cnt4 == 50)
     Buzzer_PWR(OFF);
   if(cnt4 == SETTING_ACTIVATION_TIME) // 4 seconds of pressing setting key , setting mode is enabled
   {
     appSettings.settingModeEnable = ENABLE ;
     appSettings.parameterSelecting = 1;
     appSettings.parameterValueSetting = 0;
     appSettings.settingModeTimeout = SETTING_MODE_TIMEOUT;
     appSettings.settingChangingTimeout = SETTING_CHANGING_TIMEOUT;
     LCD_Glass_Update_By_State();
     //UART_Send(3,"setting enabled/r/n",15);
   }
  }
  else if (!appState.settingsTouched)
    cnt4=0;
}


/**
  * @brief  according to value of setting parameter 12 the learn pin is activated or disactivated
  * @param  0:learn-off   1:learn-on   2:reseting-learn-remotes
  * @retval none
  */
void LearnKeyOperation(uint8_t task) 
{
  switch (task)
  {
   #ifdef OLD_PCB
    case 0:
        GPIO_SetBits(GPIOC, GPIO_Pin_4);
        break;
    case 1:
        GPIO_ResetBits(GPIOC, GPIO_Pin_4);
        appSettings.learnKeyTimeout = MAX_LEARN_TIME;
        break;
    case 2:
        GPIO_ResetBits(GPIOC, GPIO_Pin_4);
        appSettings.learnKeyTimeout = MAX_LEARNED_KEYS_RESET_TIME;
        break;
   #endif
        
   #ifdef NEW_PCB
    case 0:
        GPIO_SetBits(GPIOC, GPIO_Pin_1);
        break;
    case 1:
        GPIO_ResetBits(GPIOC, GPIO_Pin_1);
        appSettings.learnKeyTimeout = MAX_LEARN_TIME;
        break;
    case 2:
        GPIO_ResetBits(GPIOC, GPIO_Pin_1);
        appSettings.learnKeyTimeout = MAX_LEARNED_KEYS_RESET_TIME;
        break;
   #endif
  }
}


/**
  * @brief  Calendar Configuration.
  * @param  None
  * @retval None
  */
void Calendar_Init(void)
{
  RTC_InitStr.RTC_HourFormat = RTC_HourFormat_24;
  RTC_InitStr.RTC_AsynchPrediv = 0x7F;
  RTC_InitStr.RTC_SynchPrediv = 0x00FF;
  RTC_Init(&RTC_InitStr);

  RTC_DateStructInit(&RTC_DateStr);
  RTC_DateStr.RTC_WeekDay = RTC_Weekday_Friday;
  RTC_DateStr.RTC_Date = 13;
  RTC_DateStr.RTC_Month = RTC_Month_May;
  RTC_DateStr.RTC_Year = 11;
  RTC_SetDate(RTC_Format_BIN, &RTC_DateStr);

  RTC_TimeStructInit(&RTC_TimeStr);
  RTC_TimeStr.RTC_Hours   = 01;
  RTC_TimeStr.RTC_Minutes = 00;
  RTC_TimeStr.RTC_Seconds = 00;
  RTC_SetTime(RTC_Format_BIN, &RTC_TimeStr);


//  RTC_AlarmStructInit(&RTC_AlarmStr);
//  RTC_AlarmStr.RTC_AlarmTime.RTC_Hours   = 01;
//  RTC_AlarmStr.RTC_AlarmTime.RTC_Minutes = 00;
//  RTC_AlarmStr.RTC_AlarmTime.RTC_Seconds = 10;
//  RTC_AlarmStr.RTC_AlarmMask = RTC_AlarmMask_DateWeekDay;
//  RTC_SetAlarm(RTC_Format_BIN, &RTC_AlarmStr);
//
//  RTC_ITConfig(RTC_IT_ALRA, ENABLE);
//  RTC_AlarmCmd(ENABLE);
}


uint8_t Is_Timer_Active_Today()
{
  return (1 << RTC_DateStr.RTC_WeekDay) & appState.weekActiveDays;
}

/**
  * @brief  this function makes the current time and day in the t structure
  * @param  None
  * @retval None
  */
void Making_Date_And_Time()
{
  RTC_GetTime(RTC_Format_BIN, &RTC_TimeStr);
  RTC_GetDate(RTC_Format_BIN, &RTC_DateStr);
//      uint8_t bf[50];
//      sprintf(bf, "%u: %u: %u", (uint16_t)RTC_TimeStr.RTC_Hours, (uint16_t)RTC_TimeStr.RTC_Minutes, (uint16_t)RTC_TimeStr.RTC_Seconds);
//      UART_Send(2, bf, String_Length(bf));
  
//      if (reg[HOUR] == 23 && RTC_TimeStr.RTC_Hours == 0)
//      {
//        appState.tomorrowOn = 0;
//        appState.tomorrowOff = 0;
//      }
  
  tm t = { 0 };
  t.tm_year = (int)RTC_DateStr.RTC_Year + 100;
  t.tm_mon = (int)RTC_DateStr.RTC_Month - 1;
  t.tm_mday = (int)RTC_DateStr.RTC_Date;
  t.tm_hour = (int)RTC_TimeStr.RTC_Hours;
  t.tm_min = (int)RTC_TimeStr.RTC_Minutes;
  t.tm_sec = (int)RTC_TimeStr.RTC_Seconds;
  appState.nowTime = mktime(&t);
  if (appState.nowTime - appState.dayRefTime > 86400)
  {
    appState.dayRefTime = (appState.nowTime / 86400) * 86400;
  }
  
//      reg[YEAR] = RTC_DateStr.RTC_Year;
//      reg[MONTH] = RTC_DateStr.RTC_Month;
//      reg[DAY] = RTC_DateStr.RTC_Date;
//      reg[HOUR] = RTC_TimeStr.RTC_Hours;
//      reg[MINUTE] = RTC_TimeStr.RTC_Minutes;
//      reg[SECOND] = RTC_TimeStr.RTC_Seconds;
  reg[TIME] = highHalfWord(appState.nowTime);
  reg[TIME+1] = lowHalfWord(appState.nowTime);
}


/**
  * @brief  this function updates the value of current parameter according to the number of parameter and its scale and ect
  * @param  LCD_GLASS and App_Settings are used in internal functions
  * @retval none
  */
void LCD_GLASS_UPDATE_PARAMETER_VALUE(App_Settings appSettings)
{
  LCD_GLASS_7SEGMENTS_5AND6_VALUE_CALCULATOR(appSettings.parameterValue[appSettings.currentParameter], percentFigureTable[appSettings.currentParameter], degreeFigureTable[appSettings.currentParameter], paramScaleTable[appSettings.currentParameter]);
}

/**
  * @brief  this function is used to control the figure's values and demonstrations such as percent , degree and 7segments
  * @param  percentStatus: on or off (inorder to show or hide the figure on lcd)        degreeStatus:on or off        scale:it can be 1 or 10 or 100 or ect     value:7segments number 5 and 6 values 
  * @retval none
  */
void LCD_GLASS_7SEGMENTS_5AND6_VALUE_CALCULATOR(uint16_t value, uint8_t percentStatus, uint8_t degreeStatus, uint16_t scale)
{
   /////////////// percent and degree status ///////////////
    LCD_GLASS_Update_Fig_Struct(FIG_PERCENT, percentStatus);
    LCD_GLASS_Update_Fig_Struct(FIG_DEGREE_SMALL, degreeStatus);
   /////////////////////////////////////////////////////////
   
   ///////////////fig number 1 status(one hundreds)///////////////
    LCD_GLASS_Update_Fig_Struct(FIG_ONE, Get_Hundreds(value/scale) == 1);
   ////////////////////////////////////////////////
    
   /////////////////checking tens/////////////////
    if(Get_Tens(value/scale) != 0 || Get_Hundreds(value/scale) != 0)
      LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens(value/scale));
    else
      LCD_GLASS_Update_SevenSeg_Struct(4, SEG_OFF);
   ///////////////////////////////////////////////
    
   /////////////////checking ones/////////////////
    LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones(value/scale));
   ///////////////////////////////////////////////
   
   /////////////////checking fractions/////////////////
    LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, Get_Ones(((value*10)/scale)) >= 5);
   ////////////////////////////////////////////////////
}

/**
  * @brief  this function is used to update the setting page every seconds if the setting is enabled
  * @param  none
  * @retval none
  */
void LCD_GLASS_UPDATE_SETTING_PAGE(void)
{
  if(appSettings.parameterSelecting && appSettings.settingModeEnable && appState.powerOn)
  {
    LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(appSettings);
    if(appSettings.currentParameter == (ACCURACY_OF_LOC_PCKT_RECEIVE - START_OF_PARAMS + 1) || appSettings.currentParameter == (ACCURACY_OF_GBL_PCKT_RECEIVE - START_OF_PARAMS + 1))
      LCD_GLASS_UPDATE_PARAMETER_VALUE(appSettings);
  }
  else if(appSettings.parameterValueSetting && appSettings.settingModeEnable && appState.powerOn)
  {
    LCD_GLASS_UPDATE_PARAMETER_VALUE(appSettings);
  }
}


/**
  * @brief  this function is used to update parameter number on the lcd when the setting mode is enabled ( for example : P1 P2 P3 P4 and ect)
  * @param  appSettings and lcdGlass : used for internal codes
  * @retval none
  */
void LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(App_Settings appSettings)
{
    LCD_GLASS_Update_SevenSeg_Struct(3, LETTER_P);
    LCD_GLASS_Update_SevenSeg_Struct(1, Get_Tens(appSettings.currentParameter));
    LCD_GLASS_Update_SevenSeg_Struct(2, Get_Ones(appSettings.currentParameter));
}

/**
  * @brief  this function is called every seconds and count the stand-by timer to finally enable the stand-by mode
  * @param  none
  * @retval none
  */
void LCD_GLASS_UPDATE_STANDBY()
{
  if(appState.powerOn)
  {
    if(appState.lcdStandByTimer < appSettings.parameterValue[lcd_standBy_time - START_OF_PARAMS + 1]) // lcd_standBy_time is standBy time value wich had been set in setting
    {
      appState.lcdStandByTimer++;
      if(appState.lcdStandByTimer == appSettings.parameterValue[lcd_standBy_time - START_OF_PARAMS + 1])
      {
        appState.lcdIsInStandby = 1;
        LCD_DeadTimeConfig(LCD_GLASS_Standby_Contrast());
      }
    }
  }
  else
  {
    appState.lcdIsInStandby = 0;
    appState.lcdStandByTimer = 0;
    LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast());
  }
}


/**
  * @brief  Turn On figures one by One and then shows 0~9 on seven segments  
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None 
  */
void LCD_Glass_Play_Demo()
{
  unsigned char i, j;
  for(i=0;i<FIG_NUM;i++)
  {
    LCD_GLASS_Update_Fig_Struct(i, ENABLE);
    delay_ms(500);
    LCD_GLASS_Update_Fig_Struct(i, DISABLE);
  }
  
  for(j=0;j<11;j++)  
  {
     for(i=0;i<6;i++)
    {
      LCD_GLASS_Update_SevenSeg_Struct(i, j);
    }
    delay_ms(500);
  }
      
  LCD_GLASS_Struct_Init();
  LCD_GLASS_Update_Struct();
}


/**
  * @brief  this funciton turns all the figures and segments ON
  * @param  None
  * @retval None 
  */
void LCD_Glass_Play_All()
{
  for(unsigned char i=0;i<FIG_NUM;i++)
  {
    LCD_GLASS_Update_Fig_Struct(i, ENABLE);
  }
   for(unsigned char i=0;i<6;i++)
  {
    LCD_GLASS_Update_SevenSeg_Struct(i, 8);
  }
  // updating the io-control register
//  reg[IO_CONTROL_REG] |= (uint16_t)IO_ALL_LCD_FIGS_ON;
  ushortSetBit(&reg[IO_CONTROL_REG],IO_ALL_LCD_FIGS_ON);
//  reg[IO_CONTROL_REG] |= IO_ALL_LCD_FIGS_ON;
}


/**
  * @brief  this funciton turns all the figures and segments OFF
  * @param  None
  * @retval None 
  */
void LCD_Glass_Off_All()
{
  for(unsigned char i=0;i<FIG_NUM;i++)
  {
    LCD_GLASS_Update_Fig_Struct(i, DISABLE);
  }
   for(unsigned char i=0;i<6;i++)
  {
    LCD_GLASS_Update_SevenSeg_Struct(i, 10);
  }
  // updating the io-control register
//  reg[IO_CONTROL_REG] |= (uint16_t)IO_ALL_LCD_FIGS_OFF;
  ushortSetBit(&reg[IO_CONTROL_REG],IO_ALL_LCD_FIGS_OFF);
//  reg[IO_CONTROL_REG] |= IO_ALL_LCD_FIGS_OFF;
}


/**
  * @brief  Refresh figures and seven segments by app state 
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None 
  */
void LCD_Glass_Update_By_State()
{
  if(!((reg[IO_CONTROL_REG] & IO_Manual_Bit) && (reg[IO_CONTROL_REG] & (IO_ALL_LCD_FIGS_ON | IO_ALL_LCD_FIGS_OFF))))
  {
    unsigned char i;
    
    LCD_GLASS_Struct_Deinit();

  //  // disable non-key figs
  //  for(i=7;i<27;i++)
  //  {
  //    LCD_GLASS_Update_Fig_Struct(i, DISABLE);
  //  }
  //  // disable seven segments
  //  for(i=0;i<6;i++)
  //  {
  //    LCD_GLASS_Update_SevenSeg_Struct(i, 10);
  //  }
    
    if (appState.powerOn && !reg[FIRST_BOOT_FLAG_AFTER_POWERON] && appState.keyLockBlink == OFF)
    {
      // enable keys
      if(!getLcdIsInStandby()) // if standBy mode is off
      {
        if(appState.keyLock)
        {
          for(i=5;i<7;i++)
            LCD_GLASS_Update_Fig_Struct(i, ENABLE); //if keyLock is enabled then just turn on setting and auto keys
        }
        else
        {
          for(i=0;i<7;i++)
          {
            if(appState.thermalOrCoolerMode == Thermal && i==4)
              i++;
            LCD_GLASS_Update_Fig_Struct(i, ENABLE);//if keyLock is disabled then turn on all keys
          }
        }
      }
      else
      {
        LCD_GLASS_Update_Fig_Struct(KEY_POWER, ENABLE);
      }

      // enable borders
      if(!getLcdIsInStandby())
      {
        LCD_GLASS_Update_Fig_Struct(LINE_TOP, ENABLE);
        LCD_GLASS_Update_Fig_Struct(LINE_BOTTOM, ENABLE);
      }
      
      if(appSettings.learnKeyTimeout && !appSettings.settingModeEnable)
      {
        LCD_GLASS_Update_SevenSeg_Struct(1, 12);
        LCD_GLASS_Update_SevenSeg_Struct(2, 11);
        return;
      }
      // check fault
      else if (appState.fault != No_Fault /*&& appState.fault != Timeout_Fault */&& appState.fault != CRC_Fault && !appSettings.settingModeEnable)
      {
        LCD_GLASS_Update_Fig_Struct(FIG_ERROR, ENABLE);
        
        if (Get_Tens(appState.fault) > 0)
          LCD_GLASS_Update_SevenSeg_Struct(1, Get_Tens(appState.fault));
        else
          LCD_GLASS_Update_SevenSeg_Struct(1, 10);
        LCD_GLASS_Update_SevenSeg_Struct(2, Get_Ones(appState.fault));
        LCD_GLASS_Update_SevenSeg_Struct(3, 11);
        
        if((appState.fault == Ac_Voltage_Range_High) || (appState.fault == Ac_Voltage_Range_Low))
        {
          LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens((unsigned short)(Drv_Get_AC_Voltage()/10))); // scale 10
          LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones((unsigned short)(Drv_Get_AC_Voltage()/10))); // scale 10
        }
        return;
      }
      // if setting mode is enabled then just update the setting's parameter number and it's value inside the central border
      if(appSettings.settingModeEnable)
      {
        if(appSettings.parameterValueSetting)
        {
          LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(appSettings);
        }
        else if(appSettings.parameterSelecting)
        {
          LCD_GLASS_UPDATE_PARAMETER_VALUE(appSettings);
        }
      }
      else
      {
        //////////// update actual temp ////////////
        if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 0 || reg[ENV_OR_DRIVER_TEMP_SHOW] == 1)
        {
          LCD_GLASS_Update_Fig_Struct(FIG_POINT_BIG, ENABLE);
          LCD_GLASS_Update_Fig_Struct(FIG_DEGREE_BIG, ENABLE);
        }
        // env temp
        if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 0)
        {
          if (Get_Tens((unsigned short)appState.showableTemp) > 0) //the temp colibration value is added 
            LCD_GLASS_Update_SevenSeg_Struct(1, Get_Tens((unsigned short)(appState.showableTemp)));//the temp colibration value is added 
          else
            LCD_GLASS_Update_SevenSeg_Struct(1, 10);
          LCD_GLASS_Update_SevenSeg_Struct(2, Get_Ones((unsigned short)(appState.showableTemp)));//the temp colibration value is added 
          LCD_GLASS_Update_SevenSeg_Struct(3, Get_Fraction(appState.showableTemp));//the temp colibration value is added 
        }
        // driver temp
        else if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 1)
        {
          if (Get_Tens((unsigned short)(Drv_Get_Actual_Temp() + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0))) > 0) //the temp colibration value is added 
            LCD_GLASS_Update_SevenSeg_Struct(1, Get_Tens((unsigned short)(Drv_Get_Actual_Temp() + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0))));//the temp colibration value is added 
          else
            LCD_GLASS_Update_SevenSeg_Struct(1, 10);
          LCD_GLASS_Update_SevenSeg_Struct(2, Get_Ones((unsigned short)(Drv_Get_Actual_Temp() + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0))));//the temp colibration value is added 
          LCD_GLASS_Update_SevenSeg_Struct(3, Get_Fraction(Drv_Get_Actual_Temp() + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0)));//the temp colibration value is added 
        }
        // limit flag
        else if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 2)
        {
          uint8_t limitFlagLow = 0; 
          limitFlagLow = (appState.limitFlag & 0x0F);
          uint8_t limitFlagHigh;
          limitFlagHigh = (appState.limitFlag >> 4) & 0x0F;
          if(limitFlagLow > 9)
            limitFlagLow +=4;
          if(limitFlagHigh > 9)
            limitFlagHigh +=4;
          
          LCD_GLASS_Update_SevenSeg_Struct(1, limitFlagHigh);
          LCD_GLASS_Update_SevenSeg_Struct(2, limitFlagLow);
        }
        // bus voltage
        else if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 3)
        {
          uint8_t oneHundredth = appState.driverDcBusVoltage/100;
          uint8_t oneTenth = appState.driverDcBusVoltage/10 - 10*oneHundredth;
          uint8_t oneth = appState.driverDcBusVoltage - 10*(appState.driverDcBusVoltage/10);
          LCD_GLASS_Update_SevenSeg_Struct(1, oneHundredth);
          LCD_GLASS_Update_SevenSeg_Struct(2, oneTenth);
          LCD_GLASS_Update_SevenSeg_Struct(3, oneth);
          if(appState.driverDcBusVoltage < DC_BUS_VOLTAGE_LOWER_HAZARD || appState.driverDcBusVoltage > DC_BUS_VOLTAGE_UPPER_HAZARD)
            LCD_GLASS_Update_Fig_Struct(FIG_ERROR, ENABLE);
        }
        /////////////////////////////////////////////
        
        if (appState.autoMode)
        {
          if(!getLcdIsInStandby())
            LCD_GLASS_Update_Fig_Struct(FIG_AUTO, ENABLE);
          LCD_GLASS_Update_Fig_Struct(FIG_DEGREE_SMALL, ENABLE);
          if (Get_Tens(appState.tempSetPoint/2) > 0)
            LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens(appState.tempSetPoint/2));
          else
            LCD_GLASS_Update_SevenSeg_Struct(4, 10);
          LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones(appState.tempSetPoint/2));
          if ((appState.tempSetPoint%2) == 1)
            LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, ENABLE);
        }
        else
        {
      //    LCD_GLASS_Update_Fig_Struct(FIG_AUTO, DISABLE);
      //    LCD_GLASS_Update_Fig_Struct(FIG_DEGREE_SMALL, DISABLE);
          LCD_GLASS_Update_Fig_Struct(FIG_PERCENT, ENABLE);
          
          if ((reg[MOTOR_CONTROL_MODE] == 1) && (Get_Tens(appState.actualSpeed/2) > 0))
            LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens(appState.actualSpeed/2));
          else if ((reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3) && (Get_Tens(appState.actualTorque/2) > 0))
            LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens(appState.actualTorque/2));
          else
            LCD_GLASS_Update_SevenSeg_Struct(4, 10);
          if(reg[MOTOR_CONTROL_MODE] == 1)
            LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones(appState.actualSpeed/2));
          else if(reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)
            LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones(appState.actualTorque/2));
          if (((reg[MOTOR_CONTROL_MODE] == 1) && ((appState.actualSpeed%2) == 1)) || ((reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3) && ((appState.actualTorque%2) == 1)))
            LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, ENABLE);
      //    else
      //      LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, DISABLE);
          if (((reg[MOTOR_CONTROL_MODE] == 1) && (appState.actualSpeed >= 200)) || ((reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3) && (appState.actualTorque >= 200)))
          {
            LCD_GLASS_Update_Fig_Struct(FIG_ONE, ENABLE);
            LCD_GLASS_Update_SevenSeg_Struct(4, 0);
            LCD_GLASS_Update_SevenSeg_Struct(5, 0);
            LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, DISABLE);
          }
          
        }
        
        /*if (appState.speedMinChangingTimeout)
        {
          LCD_GLASS_Update_Fig_Struct(FIG_PERCENT, ENABLE);
          LCD_GLASS_Update_Fig_Struct(FIG_DEGREE_SMALL, DISABLE);
          if (Get_Tens(appState.speedMinPercent/10) > 0)
            LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens(appState.speedMinPercent/10));
          else
            LCD_GLASS_Update_SevenSeg_Struct(4, 10);
          LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones(appState.speedMinPercent/10));
          if (appState.speedMinPercent % 10 == 5)
          {
            LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, ENABLE);
          }
        }
        else if (appState.speedMaxChangingTimeout)
        {
          LCD_GLASS_Update_Fig_Struct(FIG_PERCENT, ENABLE);
          LCD_GLASS_Update_Fig_Struct(FIG_DEGREE_SMALL, DISABLE);
          
          if (appState.speedMaxPercent >= 1000)
          {
            LCD_GLASS_Update_Fig_Struct(FIG_ONE, ENABLE);
            LCD_GLASS_Update_SevenSeg_Struct(4, 0);
            LCD_GLASS_Update_SevenSeg_Struct(5, 0);
            LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, DISABLE);
          }
          else
          {
            if (Get_Tens(appState.speedMaxPercent/10) > 0)
              LCD_GLASS_Update_SevenSeg_Struct(4, Get_Tens(appState.speedMaxPercent/10));
            else
              LCD_GLASS_Update_SevenSeg_Struct(4, 10);
            LCD_GLASS_Update_SevenSeg_Struct(5, Get_Ones(appState.speedMaxPercent/10));
            if (appState.speedMaxPercent % 10 == 5)
            {
              LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, ENABLE);
            }
          }
        }
        */
        LCD_GLASS_Update_Fig_Struct(FIG_FAN, ENABLE);
        if(reg[MOTOR_CONTROL_MODE] == 1)
        {
          if (appState.actualSpeed > 00)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P1, ENABLE);
          if (appState.actualSpeed > 40)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P2, ENABLE);
          if (appState.actualSpeed > 80)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P3, ENABLE);
          if (appState.actualSpeed > 120)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P4, ENABLE);
          if (appState.actualSpeed > 160)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P5, ENABLE);
        }
        else if(reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)
        {
          if (appState.actualTorque > 00)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P1, ENABLE);
          if (appState.actualTorque > 40)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P2, ENABLE);
          if (appState.actualTorque > 80)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P3, ENABLE);
          if (appState.actualTorque > 120)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P4, ENABLE);
          if (appState.actualTorque > 160)
            LCD_GLASS_Update_Fig_Struct(FIG_FAN_P5, ENABLE);
        }
      }

      if (appState.dayTimeOff != -1)
        LCD_GLASS_Update_Fig_Struct(FIG_CLOCK, ENABLE);
      int32_t diff = appState.dayTimeOff - appState.nowTime;
      
      //update valve
      if (appState.valveOn && !Get_Timer_Changing_TimeOut())
        LCD_GLASS_Update_SevenSeg_Struct(0, 14);
      
      //update status
      else if(appState.limitFlag && !Get_Timer_Changing_TimeOut())
      {
        if(appState.limitFlag & 0x01)
          LCD_GLASS_Update_SevenSeg_Struct(0, 12);
        else
          LCD_GLASS_Update_SevenSeg_Struct(0, 15);
      }
      
      // update status of Thermal or Cooler mode
      else if(appState.thermalOrCoolerMode == Thermal && !Get_Timer_Changing_TimeOut())
      {
        LCD_GLASS_Update_SevenSeg_Struct(0, 16);
      }
      
      // update timer
      else if (diff > 0)
      {
        if (diff < (9*3600))
        {
          uint8_t timerVal = (diff + 3599) / 3600;
          LCD_GLASS_Update_SevenSeg_Struct(0, timerVal);
        }
      }
      
      // update pump
      if (appState.pumpOn)
        LCD_GLASS_Update_Fig_Struct(FIG_WATER, ENABLE);
      
      // update ble
      if (appState.bleConnected)
        LCD_GLASS_Update_Fig_Struct(FIG_BT, ENABLE);
      
      // update wifi
  //    if (wfStatus.wificonnectionstatus)
  //      LCD_GLASS_Update_Fig_Struct(FIG_WIFI, ENABLE);
      
      
      
    }
    else if(appState.keyLockBlink == OFF)
    {
      LCD_GLASS_Update_Fig_Struct(KEY_POWER, ENABLE);
    }
    else
    {
      LCD_GLASS_Update_Fig_Struct(KEY_POWER, DISABLE);
    }
    
    /*
    for(i=0;i<27;i++)
      lcdGlass->figs[i] = ON;
    for(i=0;i<6;i++)
      lcdGlass->sevenSeg[i] = 8;
    LCD_GLASS_Update_Struct();
    */
  }
}

LCD_DeadTime_TypeDef LCD_GLASS_Normal_Contrast()
{
  return (LCD_DeadTime_TypeDef)(0x03-(uint8_t)reg[lcd_brightness_level]);
}

LCD_DeadTime_TypeDef LCD_GLASS_Standby_Contrast()
{
  return (LCD_DeadTime_TypeDef)(0x03-(uint8_t)reg[lcd_standby_brightness_level]);
}

void KeyBlinkTimeOut()
{
  if(appState.keyLockBlink && appState.keyBlinkTimeOut < 10)
    appState.keyBlinkTimeOut ++;
  else if(appState.keyBlinkTimeOut == 10)
  {
    appState.keyLockBlink = 0;
    appState.keyBlinkTimeOut = 0;
    LCD_Glass_Update_By_State();
  }
}


/**
  * @brief  this function is called once at the first time of panel booting in order to deinitialize the registers(this function would never be called again if the first boot is passed)
  * @param  none
  * @retval none
  */
void Reset_Registers_And_Eeprom_To_Factory_Values()
{
    reg[ID] = 0x10;
    reg[ID+1] = 0x00;
    reg[IDMODEL] = 0x00;
    reg[IDMODEL+1] = 0x00;
    reg[POWER] = appState.powerOn ;
    reg[PFC] = appState.pfcOn ;
    reg[PUMP] = appState.pumpOn ;
    reg[AUTO_MODE] = appState.autoMode ;
    reg[THERMAL_OR_COOLER_MODE] = appState.thermalOrCoolerMode ;
    reg[SPEED_SETPOINT] = appState.speedSetPoint ;
    reg[TEMPERATURE_SETPOINT] = appState.tempSetPoint ;
    reg[KEY_LOCKED] = appState.keyLock;
    
    reg[buzzer_status] = 1;
    appSettings.parameterConfirmedValue[buzzer_status - START_OF_PARAMS + 1] = 1;
    
    reg[lcd_brightness_level] = 3;
    appSettings.parameterConfirmedValue[lcd_brightness_level - START_OF_PARAMS + 1] = 3;
    LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast()/*LCD_DeadTime_0*/);
    
    reg[lcd_standby_brightness_level] = 1;
    appSettings.parameterConfirmedValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] = 1;
    
    reg[lcd_standBy_time] = 30;
    appSettings.parameterConfirmedValue[lcd_standBy_time - START_OF_PARAMS + 1] = 30;
    setLcdIsInStandby(0);
    setLcdStandByTimer(0);
    
    reg[temp_calibration_setpoint] = DEFUALT_TEMP_CALIB_SETPOINT;
    appSettings.parameterConfirmedValue[temp_calibration_setpoint - START_OF_PARAMS + 1] = DEFUALT_TEMP_CALIB_SETPOINT;
    
    reg[AUTO_MODE_SENSITIVITY] = DEFUALT_AUTO_SENSITIVITY;
    appSettings.parameterConfirmedValue[AUTO_MODE_SENSITIVITY - START_OF_PARAMS + 1] = DEFUALT_AUTO_SENSITIVITY;
    
    reg[SPEED_MIN_PERCENT_REG] = DEFUALT_MIN_CURR_PERCENT;
    appSettings.parameterConfirmedValue[SPEED_MIN_PERCENT_REG - START_OF_PARAMS + 1] = DEFUALT_MIN_CURR_PERCENT;
    
    reg[SPEED_MAX_PERCENT_REG] = DEFUALT_MAX_CURR_PERCENT;
    appSettings.parameterConfirmedValue[SPEED_MAX_PERCENT_REG - START_OF_PARAMS + 1] = DEFUALT_MAX_CURR_PERCENT;
    
    reg[TRQ_MIN_PERCENT] = DEFUALT_MIN_CURR_PERCENT;
    appSettings.parameterConfirmedValue[TRQ_MIN_PERCENT - START_OF_PARAMS + 1] = DEFUALT_MIN_CURR_PERCENT;
    
    reg[TRQ_MAX_PERCENT] = DEFUALT_MAX_CURR_PERCENT;
    appSettings.parameterConfirmedValue[TRQ_MAX_PERCENT - START_OF_PARAMS + 1] = DEFUALT_MAX_CURR_PERCENT;
    
    reg[MOTOR_CONTROL_MODE] = DRIVER_POWER_CTRL_MODE;
    appSettings.parameterConfirmedValue[MOTOR_CONTROL_MODE - START_OF_PARAMS + 1] = DRIVER_POWER_CTRL_MODE;
    
    reg[MOTOR_SPIN_DIRECTION] = 0;
    appSettings.parameterConfirmedValue[MOTOR_SPIN_DIRECTION - START_OF_PARAMS + 1] = 0;
    
    reg[REMOTE_CLEAR] = 0;
    appSettings.parameterConfirmedValue[REMOTE_CLEAR - START_OF_PARAMS + 1] = 0;
    
    reg[AUTO_POWER_ON] = 0;
    appSettings.parameterConfirmedValue[AUTO_POWER_ON - START_OF_PARAMS + 1] = 0;
    
    reg[AUTO_POWER_IF_AC_IN_RANGE] = 0;
    appSettings.parameterConfirmedValue[AUTO_POWER_IF_AC_IN_RANGE - START_OF_PARAMS + 1] = 0;
    
    reg[AUTO_PUMP_IN_AUTO_MODE] = 1;
    appSettings.parameterConfirmedValue[AUTO_PUMP_IN_AUTO_MODE - START_OF_PARAMS + 1] = 1;
    
    reg[ENV_OR_DRIVER_TEMP_SHOW] = 0;
    appSettings.parameterConfirmedValue[ENV_OR_DRIVER_TEMP_SHOW - START_OF_PARAMS + 1] = 0;
    
    reg[DRIVER_SCRIPT_EN] = 1;
    appSettings.parameterConfirmedValue[DRIVER_SCRIPT_EN - START_OF_PARAMS + 1] = 1;
    
    reg[IMC_CODE_VERSION] = 1;
    appSettings.parameterConfirmedValue[IMC_CODE_VERSION - START_OF_PARAMS + 1] = 1;
    
    reg[DRIVER_CONFIG_NUM] = 0;
    appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1] = 0;
    
    reg[VALVE_CLOSURE_TIMEOUT] = 1;
    appSettings.parameterConfirmedValue[VALVE_CLOSURE_TIMEOUT - START_OF_PARAMS + 1] = 1;
    
    reg[LIFE_GUARD_ENABLE] = 1;
    appSettings.parameterConfirmedValue[LIFE_GUARD_ENABLE - START_OF_PARAMS + 1] = 1;
    
    reg[WIFI_AUTO_CONNECT] = 1;
    appSettings.parameterConfirmedValue[WIFI_AUTO_CONNECT - START_OF_PARAMS + 1] = 1;
    
    reg[ACCURACY_OF_GBL_PCKT_RECEIVE] = 0;
    appSettings.parameterConfirmedValue[ACCURACY_OF_GBL_PCKT_RECEIVE - START_OF_PARAMS + 1] = 0;
    
    reg[ACCURACY_OF_LOC_PCKT_RECEIVE] = 0;
    appSettings.parameterConfirmedValue[ACCURACY_OF_LOC_PCKT_RECEIVE - START_OF_PARAMS + 1] = 0;
    
    reg[RESET_FACTORY] = 0;
    appSettings.parameterConfirmedValue[RESET_FACTORY - START_OF_PARAMS + 1] = 0;
    
    reg[FIRMWARE_VERSION] = CODE_VERSION;
    appSettings.parameterConfirmedValue[FIRMWARE_VERSION - START_OF_PARAMS + 1] = CODE_VERSION;
    
    for(uint8_t cnt = START_OF_PARAMS ; cnt <= END_OF_PARAMS ; cnt++)
    {
      appSettings.parameterValue[cnt - START_OF_PARAMS + 1] = appSettings.parameterConfirmedValue[cnt - START_OF_PARAMS + 1];
    }
    
    reg[TIME] = highHalfWord(appState.nowTime);
    reg[TIME+1] = lowHalfWord(appState.nowTime);
    
    reg[DAY_W_DATE] = 0;
    reg[TIME_W_ON] = 0;
    reg[TIME_W_ON+1] = 0xFFFF;
    reg[TIME_W_OFF] = 0xFFFF;
    reg[TIME_W_OFF+1] = 0xFFFF;
    reg[TIME_D_ON] = 0xFFFF;
    reg[TIME_D_ON+1] = 0xFFFF;
    reg[TIME_D_OFF] = 0xFFFF;
    reg[TIME_D_OFF+1] = 0xFFFF;
    reg[SW_VERSION] = SOFTWARE_VERSION;
    reg[HW_VERSION] = HARDWARE_VERSION;
//    reg[LCD_STANDBY_CONTRAST_LEVEL] = LCD_DeadTime_2;
//    reg[LCD_NORMAL_CONTRAST_LEVEL] = LCD_DeadTime_0;
    
    //writing registers (22 to 61) into eeprom
    for(uint16_t cnt = ID ; cnt <=  END_OF_PARAMS - 1 ; cnt++)
    {
      if(cnt != FIRST_BOOT_IS_PASSED)
      {
        eepromWriteData(cnt, (uint8_t*)&reg[cnt], 2);
        if((cnt%10) == 0)
          delay_ms(1);
      }
    }

    
    eepromWriteData(SW_VERSION, (uint8_t*)&reg[SW_VERSION], 2);
    eepromWriteData(HW_VERSION, (uint8_t*)&reg[HW_VERSION], 2);
}

/**
  * @brief  it updates the ram registers with eeprom saved values (its called after panel booting).
  * @param  none
  * @retval none
  */
void Update_Ram_Registers_With_Eeprom_Datas()
{
    //reading From eeprom and writing to Registers
    for(char cnt = ID ; cnt <= TEMPERATURE_SETPOINT ; cnt++)
    {
      eepromReadData(cnt, (uint8_t*)&reg[cnt], 2);
    }
    
    //updating appstate by registers
    appState.powerOn = reg[POWER];
    appState.pumpOn = reg[PUMP];
    appState.autoMode = reg[AUTO_MODE];
    appState.thermalOrCoolerMode = (Thermal_Or_Cooler)reg[THERMAL_OR_COOLER_MODE];
    appState.speedSetPoint = reg[SPEED_SETPOINT];
    appState.tempSetPoint = reg[TEMPERATURE_SETPOINT];
    appState.pfcOn = reg[PFC];
    
    appSettings.parameterConfirmedValue[FIRMWARE_VERSION - START_OF_PARAMS + 1] = CODE_VERSION;
    appSettings.parameterValue[FIRMWARE_VERSION - START_OF_PARAMS + 1] = CODE_VERSION;
    
    //reading from eeprom and writing into registers
//    for(char cnt = TIME ; cnt <= LCD_NORMAL_CONTRAST_LEVEL ; cnt++)
//    {
//      eepromReadData(cnt, (uint8_t*)&reg[cnt], 2);
//    }
   
    //reading from eeperom and writing to paramValue and paramConfirmedValue (from 36 to 61)
    for(char cnt = START_OF_PARAMS ; cnt <= END_OF_PARAMS - 1 ; cnt++)
    {
      eepromReadData(cnt, (uint8_t*)&reg[cnt], 2);
      appSettings.parameterValue[cnt - START_OF_PARAMS + 1] = reg[cnt];
      appSettings.parameterConfirmedValue[cnt - START_OF_PARAMS + 1] = reg[cnt];
      if(cnt == 48)
        delay_ms(1);
    }
    
    if(appState.powerOn)
    {
      appState.powerOn = 0;
      reg[POWER] = 0;
      if(reg[AUTO_POWER_ON])
        reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 1;
      else
      {
        reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
        eepromWriteData(POWER, (uint8_t*)&reg[POWER], 2);
        eepromWriteDataFinishTimeOut();
      }
    }
    else
      reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
    
    eepromReadData(SW_VERSION, (uint8_t*)&reg[SW_VERSION], 2);
    eepromReadData(HW_VERSION, (uint8_t*)&reg[HW_VERSION], 2);
    
    ASK_ReadRemoteAddressesFromEepromToReg();
}

void disconnectCounter()
{
  appState.disNum ++;
}

void updateTempOffsetTimeOut()
{
  int8_t test1=0, test2 = 0;
  float test3;
  appState.tempOffsetTimerOn = 0;
  
  test1 = finalTempTable[Drv_Calculate_Real_Percent()+1] - finalTempTable[0] - (uint8_t)(10*appState.tempOffsetOn);
  test2 = finalTempTable[Drv_Calculate_Real_Percent()+1] - finalTempTable[0];
  if(test1 < 0)
    test1 *= -1;
  if(test2 < 0)
    test2 *= -1;
  test3 = (float)test1/(float)test2;
  if(appState.powerOn)
  {
    appState.tempOffsetTimeOut = (uint16_t)(test3 * TEMP_OFFSET_ONCE_SPEED_CHANGES_TIMEOUT); // 3000 sec equal to 50 minutes
    appState.tempOffsetOnStep1 = ( 0.47*((float)(finalTempTable[(Drv_Calculate_Real_Percent())+1] - finalTempTable[0])/10 - appState.tempOffsetOn)/((appState.tempOffsetTimeOut*3)/10) );
    appState.tempOffsetOnStep2 = ( 0.53*((float)(finalTempTable[(Drv_Calculate_Real_Percent())+1] - finalTempTable[0])/10 - appState.tempOffsetOn)/((appState.tempOffsetTimeOut*7)/10) );
  }
  else
  {
    appState.tempOffsetTimeOut = TEMP_OFFSET_FROM_POWER_ONTOOFF_TIMEOUT; // 3600 sec equal to 1 hour
    appState.tempOffsetOnStep1 = (float)(0 - appState.tempOffsetOn)*0.4/((3*appState.tempOffsetTimeOut)/10);
    appState.tempOffsetOnStep2 = (float)(0 - appState.tempOffsetOn)*0.6/((7*appState.tempOffsetTimeOut)/10);
  }
//  appState.driverReceiveFlag = 1;
}

void tempOffsetGenerator()
{
  //off
  if(appState.tempOffsetTimerOff < (((uint32_t)TEMP_OFFSET_POWER_OFF_TIMEOUT*35)/100)) //0.35*69 min = 24 min
  {
    appState.tempOffsetTimerOff ++;
    appState.tempOffsetOff += 0.83*((float)finalTempTable[0]/3.5)/(TEMP_OFFSET_POWER_OFF_TIMEOUT);
  }
  else if(appState.tempOffsetTimerOff < TEMP_OFFSET_POWER_OFF_TIMEOUT) //0.65*69 min = 45 min
  {
    appState.tempOffsetTimerOff ++;
    appState.tempOffsetOff += 0.17*((float)finalTempTable[0]/6.5)/(TEMP_OFFSET_POWER_OFF_TIMEOUT);
  }
  else
    appState.tempOffsetOff = (float)finalTempTable[0]/10;
  //on
//  if(appState.powerOn)
//  {
    if(appState.tempOffsetTimerOn < (appState.tempOffsetTimeOut*3)/10)
    {
      appState.tempOffsetTimerOn ++;
      appState.tempOffsetOn += appState.tempOffsetOnStep1;
    }
    else if(appState.tempOffsetTimerOn < appState.tempOffsetTimeOut)
    {
      appState.tempOffsetTimerOn ++;
      appState.tempOffsetOn += appState.tempOffsetOnStep2;
    }
//  }
//  else
//  {
//    if(appState.tempOffsetTimerOn < appState.tempOffsetTimeOut)
//    {
//      appState.tempOffsetTimerOn ++;
//      appState.tempOffsetOn += appState.tempOffsetOnStep1;
//    }
//  }
    
//  else if(appState.powerOn && appState.driverReceiveFlag)
//  {
//    appState.tempOffsetOn = (float)(finalTempTable[Drv_Calculate_Real_Percent()+1] - finalTempTable[0])/10;
//    appState.driverReceiveFlag = 0;
//  }
  
  appState.tempOffset = appState.tempOffsetOn + appState.tempOffsetOff;
}

//below function is for factory resetting
/**
  * @brief  this function resets the parameters regeters values to their default value
  * @param  none
  * @retval none
  */
void Reset_Setting_Parameters_To_Default_Values()
{
  appSettings.parameterValue[buzzer_status - START_OF_PARAMS + 1] = 1;
  appSettings.parameterValue[lcd_brightness_level - START_OF_PARAMS + 1] = 3;
  appSettings.parameterValue[lcd_standby_brightness_level - START_OF_PARAMS + 1] = 1;
  appSettings.parameterValue[lcd_standBy_time - START_OF_PARAMS + 1] = 30;
  appSettings.parameterValue[temp_calibration_setpoint - START_OF_PARAMS + 1] = 50;
  appSettings.parameterValue[AUTO_MODE_SENSITIVITY - START_OF_PARAMS + 1] = 2;
  appSettings.parameterValue[SPEED_MIN_PERCENT_REG - START_OF_PARAMS + 1] = DEFUALT_MIN_CURR_PERCENT;
  appSettings.parameterValue[SPEED_MAX_PERCENT_REG - START_OF_PARAMS + 1] = DEFUALT_MAX_CURR_PERCENT;
  appSettings.parameterValue[TRQ_MIN_PERCENT - START_OF_PARAMS + 1] = DEFUALT_MIN_CURR_PERCENT;
  appSettings.parameterValue[TRQ_MAX_PERCENT - START_OF_PARAMS + 1] = DEFUALT_MAX_CURR_PERCENT;
  appSettings.parameterValue[MOTOR_CONTROL_MODE - START_OF_PARAMS + 1] = DRIVER_POWER_CTRL_MODE;
  for(char cnt = MOTOR_SPIN_DIRECTION ; cnt <= END_OF_PARAMS - 1 ; cnt++)
  {
//    if(cnt == 48 || cnt == 50 || cnt == 52 || cnt == 53 || cnt == 55 || cnt == 56 || cnt == 57)
    if(cnt == AUTO_PUMP_IN_AUTO_MODE || cnt == IMC_CODE_VERSION || cnt == DRIVER_SCRIPT_EN || cnt == VALVE_CLOSURE_TIMEOUT || cnt == LIFE_GUARD_ENABLE || cnt == WIFI_AUTO_CONNECT || cnt == AUTO_POWER_IF_AC_IN_RANGE)
      appSettings.parameterValue[cnt - START_OF_PARAMS + 1] = 1;
    else
      appSettings.parameterValue[cnt - START_OF_PARAMS + 1] = 0;
  }
  
  for(char cnt = START_OF_PARAMS ; cnt <= END_OF_PARAMS - 1 ; cnt++)
  {
    appSettings.parameterConfirmedValue[cnt - START_OF_PARAMS + 1] = appSettings.parameterValue[cnt - START_OF_PARAMS + 1];
    reg[cnt] = appSettings.parameterValue[cnt - START_OF_PARAMS + 1];
    eepromWriteData(cnt, (uint8_t*)&reg[cnt], 2);
    eepromWriteDataFinishTimeOut();
  }
  
  ASK_ClearRemoteAddresses();
}


//////////// some get and set functions ////////////

void setLcdStandByTimer(unsigned char newVal)
{
  appState.lcdStandByTimer = newVal;
}

unsigned char getLcdStandByTimer()
{
  return appState.lcdStandByTimer;
}

void setLcdIsInStandby(unsigned char newVal)
{
  appState.lcdIsInStandby = newVal;
}

unsigned char getLcdIsInStandby()
{
  return appState.lcdIsInStandby;
}

uint8_t getAppSettingsLearnKeyTimeout()
{
  return appSettings.learnKeyTimeout;
}

App_State* getAppState()
{
  return &appState;
}
void setAppStateBleConnected(uint8_t newVal)
{
  appState.bleConnected = newVal;
}

//int32_t Is_Time_Approached(uint8_t year, uint8_t month, uint8_t day, uint8_t hours, uint8_t minutes, uint8_t seconds)
//{
//  return        (int32_t)year - (int32_t)RTC_DateStr.RTC_Year + 
//                (int32_t)month - (int32_t)RTC_DateStr.RTC_Month + 
//                (int32_t)day - (int32_t)RTC_DateStr.RTC_Date +
//                (int32_t)hours - (int32_t)RTC_TimeStr.RTC_Hours + 
//                (int32_t)minutes - (int32_t)RTC_TimeStr.RTC_Minutes + 
//                (int32_t)seconds - (int32_t)RTC_TimeStr.RTC_Seconds;
//
//}


//// tm_mday = [1, ..., 31]
//// tm_wday = [0, ..., 6]
//// tm_mon = [0, ..., 11]
//// tm_year: 0 -> 1900 (but it must be greater than 70. witch is 1970)
//tm Get_DateTime(int year, int month, int day, int hours, int minutes, int seconds)
//{
//  tm t = { 0 };
//  t.tm_year = year;
//  t.tm_mon = month;
//  t.tm_mday = day;
//  t.tm_hour = hours;
//  t.tm_min = minutes;
//  t.tm_sec = seconds;
//  if (mktime(&t) == -1)
//  {
//    UART_Send(3, "Time Error\r\n", 12);
//  }
//  return t;
//}
//
//tm Get_Off_DateTime()
//{
////  if (appState.yearOff == 100)
////    return -1;
//  return Get_DateTime((int)appState.yearOff + 100, (int)appState.monthOff - 1, (int)appState.dayOff, (int)appState.hourOff, (int)appState.minuteOff, (int)appState.secondOff);
//}
//
//tm Get_On_DateTime()
//{
////  if (appState.yearOn == 100)
////    return -1;
//  return Get_DateTime((int)appState.yearOn + 100, (int)appState.monthOn - 1, (int)appState.dayOn, (int)appState.hourOn, (int)appState.minuteOn, (int)appState.secondOn);
//}
//
//tm Get_Now_DateTime()
//{
//  return Get_DateTime((int)RTC_DateStr.RTC_Year + 100, (int)RTC_DateStr.RTC_Month - 1, (int)RTC_DateStr.RTC_Date, (int)RTC_TimeStr.RTC_Hours, (int)RTC_TimeStr.RTC_Minutes, (int)RTC_TimeStr.RTC_Seconds);
//}


