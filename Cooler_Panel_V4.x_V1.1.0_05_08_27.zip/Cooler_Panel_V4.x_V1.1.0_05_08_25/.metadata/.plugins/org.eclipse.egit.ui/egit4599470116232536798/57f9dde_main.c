#include "stm8l15x_conf.h"
#include "initialization.h"
#include "lcd_seg.h"
#include "adc_reading.h"
#include "bs818a_2.h"
#include "esp8266.h"
#include "string.h"
#include "functions.h"
#include "stdio.h"
#include "stm8l15x_it.h"
#include "business_logic.h"

// Global Variables
extern WIFI_STATUS wfStatus;
extern const unsigned char wifiHeaderHtml[];
extern const unsigned char wifiFooter_1_Html[];
extern const unsigned char wifiFooter_2_Html[];
extern const unsigned char wifiConnectionResponseHeaderHtml[];
extern const unsigned char wifiConnectionResponseFooterHtml[];

int main( void )
{
  Init_Registers();
  Periph_Config();
  while(1)
  {
    if(wfStatus.targetRequestsHtml)
    {
      wfStatus.targetRequestsHtml = 0;
      WIFI_Send_3(&wfStatus, AT_CWLAP_CONFIG,"1,2",2000 ,3);
      if(wfStatus.receptionStatus == RECEPTION_OK)
        WIFI_Send_3(&wfStatus, LIST_AVAILABLE_APS,"",3000, 3);
      if(wfStatus.receptionStatus == RECEPTION_OK)
        WIFI_Send_3(&wfStatus, CHECK_CONNECTED_WIFI,"",3000, 3);
      if(wfStatus.receptionStatus == RECEPTION_OK)
      {
        /////////////////////////////// sending html header ///////////////////////////////
        WIFI_Send_Html_Content(&wfStatus, wifiHeaderHtml);
        delay_ms(100);
        
        /////////////////////////////// sending html SSIDS ///////////////////////////////
        sendSsidOption(&wfStatus);
        
        /////////////////////////////// sending html footer ///////////////////////////////
        //// footer1
        WIFI_Send_Html_Content(&wfStatus, wifiFooter_1_Html);
        delay_ms(500);
        
        //// CONNECTED OR NOT-CONNECTED STATUS
        if(wfStatus.wificonnectionstatus == CONNECTED)
        {
          char message[70] = {0};
          sprintf(message,"      <p>connected to : %s</p><br>\r\n", wfStatus.connectedSsid);
          WIFI_Send_Html_Content(&wfStatus, (const unsigned char*)message);
        }
        else
          WIFI_Send_Html_Content(&wfStatus, "      <p class=\"not-connected\">not connected</p><br>\r\n");
        delay_ms(500);
        
        //// footer2
        WIFI_Send_Html_Content(&wfStatus, wifiFooter_2_Html);
        delay_ms(1000);

        /////////////////////////////// terminate connection ///////////////////////////////
        char connectionID[1] = {0};
        sprintf(connectionID,"%c",wfStatus.targetConnectionId);
        WIFI_Send_3(&wfStatus, STOP_TCP_SERVER,connectionID,5000, 2);
      }
    }
    else if(wfStatus.targetRequestsConfig)
    {
      char data[80] = {0};

      /////////////////////////////// connecting to wifi /////////////////////////////// 
      Decode_Received_Html_Ssid_Password(&wfStatus);
      sprintf(data, "\"%s\",\"%s\"", wfStatus.selectedSsid, wfStatus.receivedPassword);
      WIFI_Send_3(&wfStatus, CONNECT_TO_WIFI,data,12000, 2);
      if(wfStatus.wificonnectionstatus == CONNECTED)
        delay_ms(4000);
      else
        delay_ms(100);
      
      /////////////////////////////// sending html header /////////////////////////////// 
      WIFI_Send_Html_Content(&wfStatus, wifiConnectionResponseHeaderHtml);
      delay_ms(100);
      
      /////////////////////////////// sending html message ///////////////////////////////
      
      if(wfStatus.wificonnectionstatus == CONNECTED)
        WIFI_Send_Html_Content(&wfStatus,"    <p>Connected</p>\r\n");
      else
        WIFI_Send_Html_Content(&wfStatus,"    <p>Connection Fail (check password)</p>\r\n");
          
//        ////////    creating error message    ////////
//        memset(data, 0, 80);
//        sprintf(data, "    <p>Connection Fail (check password)</p>\r\n");
//        ///////////////////////////////////////////////
//        sprintf(buffer,"%c,%d",wfStatus.targetConnectionId, strlen((const char*)data));
//        WIFI_Send_3(&wfStatus, SET_DATA_SEND_CONFIG,buffer,3500, 1);
//        UART_Send(2, data, strlen((const char*)data));
      delay_ms(100);
      
      /////////////////////////////// sending html footer ///////////////////////////////
      WIFI_Send_Html_Content(&wfStatus, wifiConnectionResponseFooterHtml);
      delay_ms(100);
      
      /////////////////////////////// terminate connection ///////////////////////////////
      char connectionID[1] = {0};
      sprintf(connectionID,"%c",wfStatus.targetConnectionId);
      WIFI_Send_3(&wfStatus, STOP_TCP_SERVER,connectionID,2500, 2);
      
      memset(wfStatus.selectedSsid, 0,strlen(wfStatus.selectedSsid));
      memset(wfStatus.receivedPassword, 0,strlen(wfStatus.receivedPassword));
      
      wfStatus.targetRequestsConfig = 0;
    }
    else if(wfStatus.targetRequestsDisconnect)
    {
      /////////////////////////////// disconnecting from wifi ///////////////////////////////
      WIFI_Send_3(&wfStatus, DISCONNECT_FROM_WIFI,"",1500, 3);
      delay_ms(100);
      
      /////////////////////////////// sending html header ///////////////////////////////
      WIFI_Send_Html_Content(&wfStatus, wifiConnectionResponseHeaderHtml);
      delay_ms(100);
      
      /////////////////////////////// sending html message ///////////////////////////////
      if(wfStatus.wificonnectionstatus == DISCONNECTED)
        WIFI_Send_Html_Content(&wfStatus,"    <p>Disconnected</p>\r\n");
      else
        WIFI_Send_Html_Content(&wfStatus,"    <p>Disconnection_FAIL</p>\r\n");
      //        memset(buffer, 0, 8);
//        sprintf(buffer,"%c,25",wfStatus.targetConnectionId);
//        WIFI_Send_3(&wfStatus, SET_DATA_SEND_CONFIG,buffer,3500, 1);
//        UART_Send(2,"    <p>Disconnected</p>\r\n", 25);
      delay_ms(100);
      
      /////////////////////////////// sending html footer ///////////////////////////////
      WIFI_Send_Html_Content(&wfStatus, wifiConnectionResponseFooterHtml);
      delay_ms(100);
      
      /////////////////////////////// terminate connection ///////////////////////////////
      char connectionID[1] = {0};
      sprintf(connectionID,"%c",wfStatus.targetConnectionId);
      WIFI_Send_3(&wfStatus, STOP_TCP_SERVER,connectionID,2500, 2); 
        
//        /////////////////////////////// sending html header /////////////////////////////// 
//        WIFI_Send_Html_Content(&wfStatus, wifiConnectionResponseHeaderHtml);
//        
//        delay_ms(100);
//        
//        ///////////////////////////// sending html dc message /////////////////////////////
//        memset(buffer, 0, 8);
//        sprintf(buffer,"%c,31",wfStatus.targetConnectionId);
//        WIFI_Send_3(&wfStatus, SET_DATA_SEND_CONFIG,buffer,3500, 1);
//        UART_Send(2,"    <p>Disconnection_FAIL</p>\r\n", 31);
//        
//        delay_ms(100);
//        
//        /////////////////////////////// sending html footer ///////////////////////////////
//        WIFI_Send_Html_Content(&wfStatus, wifiConnectionResponseFooterHtml);
//        
//        delay_ms(100);
//        
//        /////////////////////////////// terminate connection ///////////////////////////////
//        char connectionID[1] = {0};
//        sprintf(connectionID,"%c",wfStatus.targetConnectionId);
//        WIFI_Send_3(&wfStatus, STOP_TCP_SERVER,connectionID,2500, 2); 
 
      wfStatus.targetRequestsDisconnect = 0;
    }
//    if(wfStatus.wificonnectionstatus == CONNECTED)
//    {
//      mqtt_connect("BBUS-UKSuNF0Fno0zeAgeisfg9Tzw3BluI4", "pakran", &wfStatus);
//    }
  }
//  GPIO_Init(GPIOE, GPIO_Pin_3, GPIO_Mode_In_FL_No_IT);
//  GPIO_Init(GPIOE, GPIO_Pin_4, GPIO_Mode_In_FL_No_IT);
}
