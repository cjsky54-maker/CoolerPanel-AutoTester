#ifndef __FUNCTIONS
#define __FUNCTIONS

#include "stm8l15x.h"


typedef enum {LSB_FIRST = 0, MSB_FIRST} BYTE_ORDER;


unsigned char convert_int_to_string (int32_t number, char digits[10]);
unsigned char convert_long_to_string (long long number, char digits[20]);
unsigned char convert_float_to_string (float number, unsigned char digit_num, char digits[10]);
unsigned char convert_float_to_string_dotless (float number, unsigned char digit_num, char digits[15]);
unsigned char convert_double_to_string (double number, unsigned char digit_num, char digits[10]);
uint32_t convert_string_to_uint(char* string);
unsigned long long convert_string_to_ulonglong(char* string);
float convert_string_to_float(char* string);
double convert_string_to_double(char* string);
unsigned short String_Length (char* str);
unsigned char String_Compare(char* str_new, char* str_ref);
void Concatenate (char* str_total, char* str_new);
void concatenateInt(char* strTotal, uint32_t number, char* separator);
void concatenateLong(char* strTotal, unsigned long long number, char* separator);
void concatenateFloatDotless(char* strTotal, float number, unsigned char digitNum, char * separator);
void concatenateFloat(char* strTotal, float number, unsigned char digitNum, char * separator);
void concatenateDouble(char* strTotal, double number, unsigned char digitNum, char * separator);
unsigned char string_equal(char* str1, char* str2);
void String_Copy(char* string1 , char* string2);	//Copy String 2 in String 1
void Set_Bits(unsigned short* number, unsigned short bits);
void Reset_Bits(unsigned short* number, unsigned short bits);
uint32_t merge2ShortToInt(unsigned short LSW , unsigned short MSW);
unsigned char uintGetBit(uint32_t number, unsigned char position);
void uintSetBit(uint32_t *number, unsigned char position);
void uintResetBit(uint32_t *number, unsigned char position);
void ushortSetBit(uint16_t *number, unsigned short position);
void ushortResetBit(uint16_t *number, unsigned short position);
int32_t Pow(int32_t a, int32_t b);
float powFloat(float a, int32_t b);
float absF(float number);
uint32_t makecrc4(uint32_t b);
uint32_t getbitint(uint32_t b, int32_t n);
void decToBin(uint32_t number, char* binStr);
unsigned char lowByte(unsigned short num);
unsigned char highByte(unsigned short num);
unsigned short lowHalfWord(uint32_t num);
unsigned short highHalfWord(uint32_t num);
unsigned short halfWord(unsigned char* data, unsigned char start, BYTE_ORDER order);
uint32_t word(unsigned char *byte_array, unsigned char first_index, unsigned char order);
unsigned char Get_Ones(unsigned short  val);
unsigned char Get_Tens(unsigned short val);
unsigned char Get_Hundreds(unsigned short val);
unsigned char Get_Fraction(float val);

#endif
