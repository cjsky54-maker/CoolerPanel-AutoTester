/*
 * display.h
 *
 *  Created on: May 26, 2026
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_DISPLAY_H_
#define OTHER_LIB_INC_DISPLAY_H_

#include "main.h"

#define DISP_ShowBlink()		LCD_GLASS_ShowBlink()
#define DISP_ShowFinal()		LCD_GLASS_ShowFinal()
#define DISP_CopyFinal()		LCD_GLASS_CopyFinal()
#define DISP_ChangeIndex()		LCD_GLASS_ChangeIndex()

typedef enum
{
	DISP_KEY_OFF = 0,
	DISP_KEY_TIMER = 1,
	DISP_KEY_UP = 2,
	DISP_KEY_DOWN = 4,
	DISP_KEY_POWER = 8,
	DISP_KEY_PUMP = 16,
	DISP_KEY_AUTO = 32,
	DISP_KEY_SETTINGS = 64,
	DISP_LINE_TOP = 128,
	DISP_LINE_BOTTOM = 256,
	DISP_KEY_PANEL_STANDBY = DISP_KEY_POWER,
	DISP_KEY_PANEL_LOCK = DISP_KEY_SETTINGS | DISP_KEY_AUTO | DISP_LINE_TOP | DISP_LINE_BOTTOM,
	DISP_KEY_PANEL_OFF = DISP_KEY_POWER | DISP_KEY_SETTINGS,
	DISP_KEY_PANEL_ERROR = DISP_KEY_POWER | DISP_KEY_SETTINGS | DISP_LINE_TOP | DISP_LINE_BOTTOM,
	DISP_KEY_PANEL_SETTINGS = DISP_KEY_UP | DISP_KEY_DOWN | DISP_KEY_POWER | DISP_KEY_AUTO | DISP_KEY_SETTINGS | DISP_LINE_BOTTOM,
	DISP_KEY_PANEL_NORMAL = 511,
}DISPALY_KeyTypeDef;

typedef enum
{
	DISP_ICON_OFF = 0,
	//	DISP_ICON_1 = 1,
	//	DISP_ICON_2 = 2,
	//	DISP_ICON_3 = 4,
	//	DISP_ICON_4 = 8,
	//	DISP_ICON_5 = 16,
	//	DISP_ICON_6 = 32,
	DISP_ICON_BLUETOOTH = 1,
	DISP_ICON_WIFI = 2,
	DISP_ICON_PUMP = 4,
	DISP_ICON_ERROR = 8,
	DISP_ICON_TIMER  = 16,
	DISP_ICON_AUTO = 32,
}DISPLAY_IconTypeDef;

typedef enum
{
	DISP_BIG_OFF = 0,
	DISP_BIG_NUM_2 = 1,
	DISP_BIG_NUM_3 = 2,
	DISP_BIG_PARAM = 3,
	DISP_BIG_ERROR = 4,
	DISP_BIG_LIMIT = 5,
	DISP_BIG_LEARN_PENDING = 6,
	DISP_BIG_LEARN_DONE = 7,
}DISPLAY_BigModeTypeDef;

typedef enum
{
	DISP_SMALL_OFF = 0,
	DISP_SMALL_PARAM = 1,
	DISP_SMALL_NUM_2 = 2,
	DISP_SMALL_NUM_3 = 3,
}DISPLAY_SmallModeTypeDef;

typedef enum
{
	DISP_NUM_ICON_OFF = 0,
	DISP_NUM_ICON_POINT= 1,
	DISP_NUM_ICON_DEGREE = 2,
	DISP_NUM_ICON_PERCENT = 4,
}DISPLAY_NumIconTypeDef;

typedef enum
{
	BLINK_MODE_ALL = 0,
	BLINK_MODE_TIMER = 1,
	BLINK_MODE_LOWER = 2,
	BLINK_MODE_MIDDLE = 3,
}Blink_ModeTypeDef;

typedef struct
{
	DISPALY_KeyTypeDef keys;
	unsigned char icons;
	SEVENSEG_SymbolTypeDef segTimer;
	float bigValue;
	DISPLAY_BigModeTypeDef bigMode;
	unsigned char bigNumIcon;
	float smallValue;
	unsigned char smallNumLen;
	unsigned char smallHasFraction;
	unsigned char smallNumIcon;
	signed char fanPercent;
	Blink_ModeTypeDef blinkMode;
	TIMING_StructTypedef blinkOn;
	TIMING_StructTypedef blinkOff;
}DISPLAY_StructTypeDef;

DISPLAY_StructTypeDef* DISP_Get_Struct(void);
void DISP_Update_KeysBorder(DISPALY_KeyTypeDef keys);
void DISP_Update_Upper(unsigned char icons, SEVENSEG_SymbolTypeDef segVal);
void DISP_Number_To_Digit(float number, unsigned char numLen, unsigned char hasFraction, unsigned char* digits);
void DISP_Update_Middle(float value, DISPLAY_BigModeTypeDef mode, unsigned char numIcon);
void DISP_Update_Lower(float value, signed char fanPercent, DISPLAY_SmallModeTypeDef mode, unsigned char hasfraction, unsigned char numIcon);
void DISP_Update_Blink(Blink_ModeTypeDef mode);

#endif /* OTHER_LIB_INC_DISPLAY_H_ */
