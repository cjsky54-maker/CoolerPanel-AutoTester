#ifndef DRIVER_PROTOCOL_H_
#define DRIVER_PROTOCOL_H_

#include "stm8l15x_conf.h"
#include "timing.h"

#define DRV_RSP_MAX_RETRY_COUNT			        16
#define DRV_RSP_TIMEOUT					35       // in ms
#define DRV_MAX_NUMBER_OF_CMDS			        10
#define DRV_SCRIPT_STAT					DRV_SCRIPT_ENABLE
#define DRV_MOTOR_DIRECTION				0
#define DRV_PERCENT_SETPOINT_MIN		        0
#define DRV_PERCENT_SETPOINT_MAX		        200

typedef enum
{
	Motor_Gatekill					= 1 << 0,       // bit_1
	DC_Bus_Critical_Overvoltage			= 1 << 1,
	DC_Bus_Overvoltage				= 1 << 2,
	DC_Bus_Under_Voltage				= 1 << 3,
	Flux_PLL_Out_Of_Control				= 1 << 4,
	Reserved1					= 1 << 5,
	Over_Temperature				= 1 << 6,
	Rotor_Lock					= 1 << 7,
	Phase_Loss					= 1 << 8,
	Reserved2					= 1 << 9,
	Execution_Fault					= 1 << 10,
	Reserved3					= 1 << 11,
	Parameter_Load_Fault				= 1 << 12,
	UART_Link_Break_Fault				= 1 << 13,
	Hall_Timeout_Fault				= 1 << 14,
	Hall_Invalid_Fault				= 1 << 15,
	Connection_Fault				= 1UL << 16,      // bit_17
} DRV_Fault;

typedef enum
{
	DRV_WARNING_WLS = 0,
	DRV_WARNING_DRV_OVERTEMP = 6,
	DRV_WARNING_DRV_PFC = 7,
	DRV_WARNING_DRV_ERR = 8,
}
DRV_WarningTypeDef;

typedef enum
{
	//send-cmds
	DRV_CMD_READ_STATUS = 0x00,
	DRV_CMD_CLEAR_STATUS = 0x01,
	DRV_CMD_READ = 0x05,
	DRV_CMD_WRITE = 0x06,
	DRV_CMD_LOAD_PARAM = 0x20,
	DRV_CMD_NOPE = 0xFF,
	//receive-cmds
	DRV_RSP_READ_STATUS = 0x80,
	DRV_RSP_CLEAR_STATUS = 0x81,
	DRV_RSP_READ = 0x85,
	DRV_RSP_WRITE = 0x86,
	DRV_RSP_LOAD_PARAM = 0xA0,
}DRV_CMD;

typedef enum
{
	DRV_REG_PFC = 0,
	DRV_REG_PUMP = 1,
	DRV_REG_VALVE = 2,
	DRV_REG_FAULT = 3,
	DRV_REG_VTH = 4,
	DRV_REG_GPIO = 5,
	DRV_REG_CTRL_MODE_SELECT = 6,
	DRV_REG_STOP_START = 7,
	DRV_REG_SPEED = 8,
	DRV_REG_TORQUE = 9,
	DRV_REG_POWER = 10,
	DRV_REG_SCRIPT = 11,
	DRV_REG_LOAD_PARAM = 12,
	DRV_REG_SAVE_PARAM = 13,
	DRV_REG_LIMIT_FLAG = 14,
	DRV_REG_DC_BUS_VOLTAGE = 15,
	DRV_REG_NOPE = 16,
}DRV_REG;

typedef enum
{
	DRV_CTRL_MODE_SPEED = 0,
	DRV_CTRL_MODE_TORQUE = 1,
	DRV_CTRL_MODE_POWER = 2,
}DRV_ControlModeTypeDef;

typedef enum
{
	DRV_STAT_NOT_INITED = 0,
	DRV_STAT_INITED = 1,
}DRV_InitStateTypedef;

typedef enum
{
	DRV_SEND_STAT_IDLE = 0,
	DRV_SEND_STAT_SENDING = 1,
	DRV_SEND_STAT_WAIT_RESP = 2,
	DRV_SEND_STAT_WAIT_RUN = 3,
	DRV_SEND_STAT_ERROR_BUSY = 4,
}DRV_SendStateTypeDef;

typedef enum
{
	DRV_PWR_OFF = 0,
	DRV_PWR_ON = 1,
	DRV_PWR_TOGGLE = 2,
}Drv_PowerTypedef;

typedef enum
{
	DRV_RUN_STOP = 0,
	DRV_RUN_START = 1
}Drv_RunTypeDef;

typedef enum
{
	DRV_SCRIPT_ENABLE = 0x11,
	DRV_SCRIPT_DISABLE = 0x00,
}Drv_ScriptStateTypeDef;

typedef enum
{
	DRV_DROPRATE_LAST = 0,
	DRV_DROPRATE_TOTAL = 1,
}Drv_DropRateTypeDef;

typedef enum
{
	DRV_RCV_PACKET_NO = 0,
	DRV_RCV_PACKET_NEW = 1,
}DRV_ReceivedPacketTypeDef;

typedef enum
{
	DRV_BUS_IDLE = 0,
	DRV_BUS_BUSY = 1,
}Drv_BusStateTypeDef;

typedef struct
{
	DRV_InitStateTypedef drvInitStat;
	Drv_RunTypeDef runStat;
	Drv_PowerTypedef pwrStat;
	Drv_PowerTypedef pumpStat;
	Drv_PowerTypedef valveStat;
	Drv_PowerTypedef pfcStat;
	DRV_ControlModeTypeDef ctrlModeStat;
	Drv_ScriptStateTypeDef scriptStat;
	unsigned char configStat;             //0x00 -> load done  0x01,0x02 -> load failed
	float drvTemp;
	float drvTempFiltered;
	unsigned short warning;
	unsigned short drvDcBusVoltage;
	uint32_t succeedPktLast;
	uint32_t failPktLast;
	unsigned short droprateLastX10;
	uint32_t succeedPktTot;
	uint32_t failPktTot;
	unsigned short droprateTotX10;
	unsigned char actualPercentX2;
	uint32_t error;
	uint32_t errorLast;
	uint32_t errorValidated;
	unsigned char retryNum;
	unsigned char needClear;
	TIMING_StructTypedef timeoutOff;
	TIMING_StructTypedef resetRetryNum;
}DRV_StateTypedef;

typedef struct
{
	Drv_RunTypeDef runCmd;
	Drv_PowerTypedef pwrCmd;
	Drv_PowerTypedef pumpCmd;
	Drv_PowerTypedef valveCmd;
	DRV_ControlModeTypeDef ctrlModeCmd;
	DRV_REG ctrlModeReg;
	Drv_ScriptStateTypeDef scriptCmd;
	unsigned short minPercent;
	unsigned short maxPercent;
        unsigned short warningMask;
	unsigned char configNum;
	unsigned char direction;
	unsigned char setPointPercentX2;
}DRV_SettingTypeDef;

typedef struct
{
	DRV_CMD command;
	DRV_REG regiser;
	uint8_t address;
	uint16_t data;
	uint8_t dataL;
	uint16_t crc;
	uint8_t buffer[8];		// Buffer for reception of packet
	uint8_t table[2];
	DRV_ReceivedPacketTypeDef rcvFlag;
}DRV_PACKET;

typedef struct
{
	DRV_SendStateTypeDef sendStat;
	TIMING_StructTypedef timingTimeout;
	TIMING_StructTypedef timingDelay;
	TIMING_StructTypedef busRelease;
	Drv_BusStateTypeDef busState;
	unsigned char rcvBuf[8];
	DRV_REG rspReceived;	// response received
	DRV_PACKET rcvPkt;
	DRV_PACKET sendPkt;
	unsigned char retryCnt;
	unsigned char queueBuf[DRV_MAX_NUMBER_OF_CMDS][8];
	unsigned short queueBufTimeout[DRV_MAX_NUMBER_OF_CMDS];
	unsigned short queueBufDelay[DRV_MAX_NUMBER_OF_CMDS];
	unsigned char queueInd;
	unsigned char queueCnt;
}DRV_StructTypeDef;


void Drv_Init_State(void);
void Drv_Deinit_Setting(void);
void Drv_Init_Setting(void);
uint16_t Drv_Percent_To_Value(uint16_t percentX2);
void Drv_Set_Power_Relay(Drv_PowerTypedef state);
void Drv_Set_Power(Drv_PowerTypedef pwrCmd, Drv_RunTypeDef runCmd);
void Drv_Set_Ctrl_Mode(uint8_t mode);
void Drv_Set_Setpoint(void);
void Drv_Set_Direction(void); // direction 1: reverse mode and direction 0: straight mode
void Drv_Set_Parameter(uint16_t ParameterSetNumber);
void Drv_Set_Pump(Drv_PowerTypedef state);
void Drv_Set_Valve(Drv_PowerTypedef state);
void Drv_Read_Fault(void);
void Drv_Read_Register(DRV_REG reg);
void Drv_Cal_DropRate(Drv_DropRateTypeDef type);
void Drv_Handle_Reception(unsigned char *pucBuffer);
void Drv_Handle_Timeout(void);
void Drv_Handle_Send(void);
DRV_StateTypedef* Drv_Get_State(void);
DRV_SettingTypeDef* Drv_Get_Setting(void);
DRV_StructTypeDef* Drv_Get_Struct(void);
float Drv_Calculate_Ntc_Temp(uint16_t buffer);
void Drv_Reset_RetryNum(void);
void Drv_Handle_Error(void);
void Drv_Handle_Warning(void);
void Drv_Clear_If_Needed(void);
void Drv_Clear_Fault(void);
void Drv_Handle_Conflict(void);
unsigned char Drv_IsBusIdle(void);
void Drv_Check_BusRelease(void);

#endif /* DRIVER_PROTOCOL_H_ */
