#include "driver_protocol.h"
#include "initialization.h"
#include "functions.h"
#include "business_logic.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "variables.h"
#include "lcd_seg.h"
#include "adc_reading.h"
#include "stm8l15x_it.h"

//IMC parameters
#define NUMBER_OF_IMC_CODE_VERSIONS         2       // we currently have 2 code versions
#define APPID_OR_REGINDEX_SELECT            2       // choosing between app ip and register index
#define APP_ID                              0
#define REGISTER_INDEX                      1

#define NUMBER_OF_DRIVER_COMMAND_TYPE       16


//static uint8_t receivedByteCount = 0;
//uint8_t receivedBuffer[256];
uint8_t isPending = 0;
uint16_t pendingTime = 0;
uint8_t lastCommandBuffer[8];
uint8_t timeoutCtr = 0;
uint8_t powerOffTryCnt = 0;
uint8_t queueBuffer[MAX_NUMBER_OF_CMDS][8];
uint16_t queueBufferTimeOut[MAX_NUMBER_OF_CMDS] = {0};     // values must be multiple of 50ms
uint8_t queueBufferDelay[MAX_NUMBER_OF_CMDS] = {0};        // values must be multiple of 100ms
uint16_t currentBufferSpentTime = 0;
uint8_t queueCommandIdx = 0;
uint8_t queueCommandCnt = 0;
uint8_t skipPowerOff = 0;
uint8_t skipPowerOn = 0;



DRV_PACKET packet;


// This Lookup Table is made for IMC registers indexes according to the IMC code version
const uint8_t addressTable[NUMBER_OF_IMC_CODE_VERSIONS][NUMBER_OF_DRIVER_COMMAND_TYPE][APPID_OR_REGINDEX_SELECT] = 
{
//    PFC          valve        PUMP        FAULT          VTH        GPIO       CTRL_MODE  STOP_START_CMD TARGET_SPEED TARGET_TRQ TARGET_power SCRIPT_CMD  LOAD_PARAM_CMD  SAVE_PARAM_CMD  DRV_REG_LIMIT_FLAG  DCBUS_VLT
  {{0x03,0x52}, {0x34,0x41}, {0x04,0x70}, {0x00,0x00}, {0x01,0x90}, {0x34,0x40}, {0x01,0x04}, {0x01,0x78}, {0x01,0x79}, {0x01,0x81}, {0xF1,0x00}, {0x04,0x01}, {0x22,0x00}, {0x21,0x00}, {0xF1,0x04}, {0x1B,0x45}},  // version 1  {app id, regindex}
  {{0x03,0x42}, {0x34,0x41}, {0x34,0x41}, {0x00,0x00}, {0x01,0x4C}, {0x34,0x40}, {0xF1,0x02}, {0x01,0x40}, {0xF1,0x00}, {0xF1,0x00}, {0xF1,0x00}, {0x04,0x40}, {0x22,0x00}, {0x21,0x00}, {0xF1,0x04}, {0x1B,0x45}}   // version 2  {app id, regindex}
};

// This Lookup Table is made for IMC Commands Delay (these delay prevents the micro from sending next command of the queue to the imc for specified time) 
const uint8_t drvDelayTable[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 8, 1, 1, 8};
const DRV_REG controlMode[3] = {DRV_REG_SPEED, DRV_REG_TORQUE, DRV_REG_POWER};


extern App_State appState;
extern App_Settings appSettings;

//Private functions Prototype
void Send_Command(unsigned char *pucBuffer);

/**
  * @brief  this function fills the command buffer to be sent to the driver
  * @param  packet
  * @retval none
  */
void Drv_Generate_Packet(DRV_PACKET* packet)
{
  packet->buffer[0] = 0x01;
  packet->buffer[1] = packet->command;
  packet->buffer[2] = addressTable[reg[IMC_CODE_VERSION]][packet->regiser][APP_ID];
  packet->buffer[3] = addressTable[reg[IMC_CODE_VERSION]][packet->regiser][REGISTER_INDEX];
  packet->buffer[4] = lowByte(packet->data);
  packet->buffer[5] = highByte(packet->data);
  packet->crc = Drv_Get_CRC(packet->buffer);
  packet->buffer[6] = highByte(packet->crc);
  packet->buffer[7] = lowByte(packet->crc);
}

/**
  * @brief  this function fills the driver packet
  * @param  packet, cmd: driver command like reading or writing or fault clearing or ..., reg: the address of register , data: data to be written in specific driver register
  * @retval none
  */
void Drv_Fill_Generate_Send_Packet(DRV_PACKET* packet, DRV_CMD cmd, DRV_REG drv_reg, uint16_t StatusOrValue)
{
  uint8_t delay;
  packet->command = cmd;
  
  packet->regiser = drv_reg;
  
  packet->data = Drv_Generate_Data(drv_reg, StatusOrValue);
  Drv_Generate_Packet(packet);
  //Delay Generation//
  if(cmd == DRV_CMD_NOPE)
    delay = lowByte(StatusOrValue);
  else
    delay = drvDelayTable[drv_reg];
  /////////////////////
  Drv_Send_Packet(packet, DRIVER_RESPONSE_TIMEOUT, delay);
}

/**
  * @brief  if the queue is made before this function put commands at end of the queue , or if the queue inst made ,this function sends one command to driver
  * @param  packet,TimeOut: maximum time out for receiving driver response to the corresponding command , Delay: scale (1 menas 100ms) delay for sending current command (ex: 2 means micro will send the current command to driver after 200 ms )
  * @retval none
  */
void Drv_Send_Packet(DRV_PACKET* packet, uint16_t TimeOut, uint8_t Delay)
{
  if(queueCommandCnt < MAX_NUMBER_OF_CMDS)
  {
    memcpy(queueBuffer[queueCommandCnt], packet->buffer, 8);
    queueBufferTimeOut[queueCommandCnt] = TimeOut;
    queueBufferDelay[queueCommandCnt] = Delay;
    queueCommandCnt++;
    
    if(queueCommandCnt == 1)
    {
      Drv_Send_Command(queueBuffer[0]);
    }
  }
}


/**
  * @brief  if the queue is made before this function put commands at end of the queue , or if the queue inst made ,this function sends one command to driver
  * @param  drvReg: the name of the register, regValue: the status or value of the corresponding register
  * @retval the value equivalent to the status to be sent to the driver
  */
uint16_t Drv_Generate_Data(DRV_REG drvReg,uint16_t regValue)
{
  if (drvReg == (DRV_REG_PUMP || DRV_REG_PFC))
  {
    if(regValue == ON)
      return 0x0010;
    else
      return 0x0000;
  }
  else if (drvReg == DRV_REG_VALVE)
  {
    if(regValue == ON)
      return 0x0020;
    else
      return 0x0000;
  }
  else if(drvReg == DRV_REG_SCRIPT)
  {
    if(regValue == ENABLE)
      return 0x0011;
    else
      return 0x0000;
  }
  else if(drvReg == DRV_REG_CTRL_MODE_SELECT)
  {
    return regValue;
  }
  else if(drvReg == DRV_REG_STOP_START)
  {
    if(regValue == START)
      return 0x0001;
    else
      return 0x0000;
  }
  else if(drvReg == DRV_REG_SPEED) // for this command percent of speed in scale (2*percent)
  {
    if(regValue == 0)
      return 0x0000;
    uint16_t rpm = (uint32_t)regValue * 4095 / 100 / 2 * (reg[SPEED_MAX_PERCENT_REG]-reg[SPEED_MIN_PERCENT_REG]) / 1000 + (uint32_t)reg[SPEED_MIN_PERCENT_REG] * 4095 / 1000;
    if(reg[MOTOR_SPIN_DIRECTION])
      rpm *= -1;
    return rpm;
  }
  else if((drvReg == DRV_REG_TORQUE) || (drvReg == DRV_REG_POWER))
  {
    if(regValue == 0)
      return 0x0000;
    uint16_t trq = (uint32_t)regValue * 4095 / 100 / 2 * (reg[TRQ_MAX_PERCENT]-reg[TRQ_MIN_PERCENT]) / 1000 + (uint32_t)reg[TRQ_MIN_PERCENT] * 4095 / 1000;
    if(reg[MOTOR_SPIN_DIRECTION])
      trq *= -1;
    return trq;
  }
  else
    return regValue;
}



/**
  * @brief  sets the driver power ON or OFF according to the input
  * @param  state: ON or OFF
  * @retval none
  */
void Drv_Power(uint8_t state)
{
  if (state == ON)  ///////////////////////////////////  for power on  ///////////////////////////////////
  {
    if (skipPowerOn == 0)
    {
      CMDs_PWR(CMD_REL, ON);

      ///// Nope command as delay
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 20); //10*25 ms delay

      ///// clearing driver fault
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_CLEAR_STATUS, DRV_REG_FAULT, 0x0000);
      ///// loading parameter into driver ram
      if(reg[DRIVER_CONFIG_NUM] != 0)
        Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, reg[DRIVER_CONFIG_NUM]);

      ///// disable scripting if script_CMD parameter is 0
      if(reg[DRIVER_SCRIPT_EN] == DISABLE)
      {
        Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_SCRIPT, 0x0000);
      }
      
      ///// updatePumpStatus
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_PUMP, appState.pumpOn);
      
      ///// selecting driver mode (speed , toque, power)
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_CTRL_MODE_SELECT, reg[MOTOR_CONTROL_MODE]);
    }
    skipPowerOn = 0;
        
    ///// setting the speed command
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], Drv_Calculate_Percent());
    
    ///// start command 
    if(Drv_Calculate_Percent() != 0)
      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, START);
  }
  
  else /////////////////////////////////// for power off ///////////////////////////////////
  {
    //// setting the speed to zero
//    if(controlMode[reg[MOTOR_CONTROL_MODE]-1] == DRV_REG_TORQUE && skipPowerOff == 0 && appState.actualTorque > 30)
//    {
//      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], 30);
//      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 40); // 40*25 ms delay
//    }
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], 0x0000);
//    ///// Nope command as delay
//    if(controlMode[reg[MOTOR_CONTROL_MODE]-1] == DRV_REG_TORQUE)
//      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 120); //3*40*25 ms delay
//    else
//      Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 40); //40*25 ms delay
   //// stop command
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, STOP);
  }
}


/**
  * @brief  if mismatch current is detected in driver and lifeguard board is activated , this function is called in order to turn the driver power off
  * @param  none
  * @retval none
  */
void Drv_LifeGuard_Action()
{
  if(appSettings.parameterConfirmedValue[LIFE_GUARD_ENABLE - 35])
  {
    delay_ms(1);
    unsigned char CLD = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3);
    if(!CLD)
    {
      CMDs_PWR(CMD_REL, OFF);
      appState.pendingOn = 0;
      queueCommandIdx = 0;
      queueCommandCnt = 0;
      appState.fault = Driver_Current_Mismatch;
    }
  }
}


/**
  * first command : setting speed or trq to 0
  * second command : stopping motor
  * third command : changing mode command
  */
/**
  * @brief  this function change the driver mode(speed or torque) this function stops the motor before changing the mode if the motor is rotating.
  * @param  mode: DRIVER_SPEED_CTRL_MODE or DRIVER_CURRENT_CTRL_MODE
  * @retval none
  */
void Drv_Ctrl_Mode_Select(uint8_t mode)
{
  skipPowerOff = 1;
  
//////setting speed to 0
//  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE,  controlMode[reg[MOTOR_CONTROL_MODE]-1], 0x0000);
/////// Nope command as delay
//  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 60); //60*25 ms delay
//  
//////stopping motor
//  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, STOP);
  Drv_Power(OFF);
/////// Nope command as delay
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 10); //10*25 ms delay
////changing mode command  
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_CTRL_MODE_SELECT, mode);
///// Nope command as delay
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 2); //2*25 ms delay
}

/**
  * @brief  this function sets the motor speed or torque according to the input and the current driver mode(speed or torque)
  * @param  speed : desired motor speed or torque percent
  * @retval none
  */
void  Drv_Set_Speed(uint8_t speed)
{
  if ((((appState.actualSpeed != 0) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque != 0) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3))) && speed == 0)
  {
    skipPowerOff = 1;
    Drv_Power(OFF);
    return;
  }
  else if ((((appState.actualSpeed == 0) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque == 0) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3))) && speed != 0)
  {
    skipPowerOn = 1;
    Drv_Power(ON);
    return;
  }
  else if((((appState.actualSpeed == 0) && reg[MOTOR_CONTROL_MODE] == 1) || ((appState.actualTorque == 0) && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3))) && speed == 0)
  {
    return;
  }
  uint16_t percent = speed;
  
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], percent);
}

/**
  * @brief  this function set the motor speed direction according to the input (first the motor is stopped then it starts in desired direction)
  * @param  direction: demonstrates the motor spin direction
  * @retval none
  */
void Drv_Set_direction()
{
  skipPowerOff = 1;
  skipPowerOn = 1;
  
////// 1 :setting torque or speed zero
//  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE,  controlMode[reg[MOTOR_CONTROL_MODE]-1], 0x0000);
//  ///// Nope command as delay
//  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 60); //60*25 ms delay
//  
////// 2 :stopping motor
//    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, STOP);
//    
////// 3 :setting last speed
//  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, controlMode[reg[MOTOR_CONTROL_MODE]-1], Drv_Calculate_Percent());
///// Nope command as delay
  Drv_Power(OFF);
  Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 40); //40*25 ms delay
  Drv_Power(ON);
////// 4 :starting motor
//  if(Drv_Calculate_Percent())
//    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_STOP_START, START);
}

/**
  * @brief  this function LOADS specified parameter into driver RAM in order the driver to work with dedicated parameter
  * @param  ParameterSetNumber: the number of parameter block which driver is gonna work with
  * @retval none
  */
void Drv_Parameter_command(uint16_t ParameterSetNumber)
{
  if(ParameterSetNumber != 0)
  {
    skipPowerOff = 1;
    
    //// 1 :Stop command
    Drv_Power(OFF);
    //// 2 Nope command as delay
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_NOPE, DRV_REG_NOPE, 10); //10*25 ms delay
    //// 3:Loading parameter
    Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, ParameterSetNumber);
  }
}

/**
  * @brief  this function calculate the received buffer crc
  * @param  buffer: data buffer to be sent 
  * @retval none
  */
uint16_t Drv_Get_CRC(uint8_t* buffer)
{
  uint32_t crc = 0;

  crc += buffer[0];
  crc += ((uint16_t)buffer[1]) << 8;
  crc += buffer[2];
  crc += ((uint16_t)buffer[3]) << 8;
  crc += buffer[4];
  crc += ((uint16_t)buffer[5]) << 8;
  crc = 65536 - crc;
  crc = ((crc & 0xff) << 8) + ((crc & 0xff00) >> 8);
  return (uint16_t)(crc & 0xffff);
}

/**
  * @brief  this function validates and extracts the received command response buffer and sends the rest of the commands
  * @param  pucBuffer: this input is received buffer which is validated and parsed in this function
  * @retval none
  */
void Drv_Response_Received(unsigned char *pucBuffer)
{
  reg[FAULTS] = 0;
  reg[FAULTS+1] = 0;
  uint16_t crc = Drv_Get_CRC(pucBuffer);
  if (*((uint16_t*)(&pucBuffer[6])) == crc)
  {
    timeoutCtr = 0;
    pendingTime = 0;
    isPending = 0;
    appState.globalSucceedPackets += 1;
    appState.localSucceedPackets += 1;
    Drv_Parse_Response(pucBuffer);

    if (queueCommandCnt && ((pucBuffer[1] == queueBuffer[queueCommandIdx][1] + 0x80)))
    {
      if (++queueCommandIdx < queueCommandCnt)
      {
        if (queueBufferDelay[queueCommandIdx-1] == 0)
        {
          Drv_Send_Command(queueBuffer[queueCommandIdx]);
        }
        else
        {
          TIM3_SetCounter(0);
          TIM3_ClearITPendingBit(TIM3_IT_Update);
        }
        
      }
      else if(queueBufferDelay[queueCommandIdx-1] == 0)
      {
        queueCommandCnt = 0;
        queueCommandIdx = 0;
      }
//      UART_Send(3,(char*)pucBuffer, 8);
    }
    else
    {
      appState.fault  = Wrong_Format;
      queueCommandIdx++;
      if(queueCommandIdx == queueCommandCnt)
      {
        queueCommandCnt = 0;
        queueCommandIdx = 0;
      }
        
    }
//    if(pucBuffer[0] == 0x01 /*&& (pucBuffer[1] == 0x86 || pucBuffer[1] == 0xA0)/* && pucBuffer[2] == 0x34 && pucBuffer[3] == 0x40*/)
//      UART_Send(3,pucBuffer, 8);
  }
  
  else
  {
    appState.globalFailPackets += 1;
    appState.localFailPackets += 1;
    appState.fault  = CRC_Fault;
    reg[FAULTS+1] = 1 << (CRC_Fault-17);
//    reg[FAULTS] = 0;
  }
}

/**
  * @brief  this function checks the time passed after receving start cmd response, and if the time reaches to specefic value (like 5 sec) the check fualt is sent and if some specific faults are recevied : clear fault and start cmds are sent again
  * @param  none
  * @retval none
  */
void Drv_Start_Activity_Timeout()
{
  DRV_PACKET pkt;
  if(appState.drvStartTimeOut < DRIVER_CHECKFAULT_AFTER_START_TIMEOUT && appState.drvStartTimeOut > 0)
    appState.drvStartTimeOut += 1;
  else if(appState.drvStartTimeOut == DRIVER_CHECKFAULT_AFTER_START_TIMEOUT && queueCommandCnt == 0)
  {
    Drv_Fill_Generate_Send_Packet(&pkt, DRV_CMD_READ_STATUS, DRV_REG_FAULT, 0x0000);
    appState.drvStartTimeOut += 1;
  }
}

/**
  * @brief  this function checks if a response to the previous command was received in the certain time then sends the rest of the commands
  * @param  none
  * @retval none
  */
void Drv_Activity_Timeout()
{
  if (isPending)
  {
    pendingTime += 10;
    if (pendingTime >= queueBufferTimeOut[queueCommandIdx])
    {
      if (++timeoutCtr < DRIVER_RESPONSE_RETRY_COUNT)
      {
        Drv_Send_Command(lastCommandBuffer);
        appState.globalFailPackets += 1;
        appState.localFailPackets += 1;
      }
      else
      {
        isPending = 0;
        pendingTime = 0;
        timeoutCtr = 0;
        if(appState.fault != Driver_Current_Mismatch)
        {
          appState.fault = Timeout_Fault;
          reg[FAULTS+1] = 1 << (Timeout_Fault-17);
        }

        if(appSettings.settingModeEnable && appSettings.waitingForDrvResponse)
        {
          appSettings.parameterValue[appSettings.currentParameter] = appSettings.parameterConfirmedValue[appSettings.currentParameter];
          appSettings.waitingForDrvResponse = 0;
        }
        
        if(reg[FIRST_BOOT_FLAG_AFTER_POWERON] && appState.pendingOn)        
         {
          reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
          appState.powerOn = 0;
          appState.pendingOn = 0;
          reg[POWER] = appState.powerOn;
          eepromWriteData(POWER, (uint8_t*)&reg[POWER], 2);
         }

        if (queueCommandCnt)
        {
          queueCommandCnt = 0;
          queueCommandIdx = 0;  
        }

        if(appState.pendingOff && appSettings.keyPowerPressFlag)
        {
          powerOffTryCnt++;
          appSettings.keyPowerPressFlag = 0;
        }
        if(powerOffTryCnt >= MAX_POWER_OFF_TRY_COUNT)
        {
          powerOffTryCnt = 0;
          CMDs_PWR(CMD_REL, OFF);
          appState.powerOn = OFF;
          reg[POWER] = OFF;
          eepromWriteData(POWER, (uint8_t*)&reg[POWER],2);
          appState.pendingOn = 0;
          appState.pendingOff = 0;
          if(appState.fault == Driver_Current_Mismatch)
            appState.fault = No_Fault;
        }
        for(char i=0 ; i<7 ; i++)
          lastCommandBuffer[i] = 0;
      }
    }
  }
  else if (queueCommandCnt)
  {
    currentBufferSpentTime += 10;
    if (currentBufferSpentTime >= 10*queueBufferDelay[queueCommandIdx-1]) //10 * queueBufferDelay[queueCommandIdx] =>example : 10 * 5(10 scale) = 50ms
    {
      if(queueCommandIdx == queueCommandCnt)
      {
        queueCommandIdx = 0;
        queueCommandCnt = 0;
      }
      else
      {
        Drv_Send_Command(queueBuffer[queueCommandIdx]);
      }
//      UART_Send(3, (char*)&queueBuffer[queueCommandIdx], 8);
    }
  }
}


/**
  * @brief this function sends the 8-byte command through uart channel 1
  * @param  pucBuffer: the 8-byte command pointer is given to be sent via uart channel 1 
  * @retval none
  */
void Send_Command(unsigned char *pucBuffer)
{
  DMA_Cmd(DMA1_Channel2, DISABLE);
  DMA_SetCurrDataCounter(DMA1_Channel2, 8);
  DMA_ClearFlag(DMA1_FLAG_TC2);
  DMA_Cmd(DMA1_Channel2, ENABLE);

  if (isPending == 0)
  {
    TIM3_SetCounter(0);
    TIM3_ClearITPendingBit(TIM3_IT_Update);
  }
  memcpy(lastCommandBuffer, pucBuffer, 8);
//  UART_Send(1, (char*)lastCommandBuffer, 8);

  UART1_Send_DMA((char*)pucBuffer, 8);
  
  isPending = 1;
  pendingTime = 0;
  
  currentBufferSpentTime = 0;
//  if(lastCommandBuffer[0] == 0x01 && (lastCommandBuffer[1] == 0x06 || lastCommandBuffer[1] == 0x20)/*&& lastCommandBuffer[2] == 0x34 && lastCommandBuffer[3] == 0x41)*/)
//   UART_Send(3,lastCommandBuffer, 8);
}

/**
  * @brief this function will sends driver the commands queued in the buffer
  * @param  pucBuffer: the 8-byte command pointer is given to be sent via uart channel 1
  * @retval none
  */
void Drv_Send_Command(unsigned char *pucBuffer)
{
  if(pucBuffer[1] != 0xFF)
    Send_Command(pucBuffer);
  else
  {
    queueCommandIdx++;
    TIM3_SetCounter(0);
    TIM3_ClearITPendingBit(TIM3_IT_Update);
  }
}


///**
//  * @brief this function sends a queue of commands (it actually sets the number of commands then the commands are sent one by one after the former command response is recieved)
//  * @param  commandCount
//  * @retval none
//  */
//void Send_Command_Queue(/*uint8_t commandCount*/)
//{
//  queueCommandIdx = 0;
////  queueCommandCnt = commandCount;
//  currentBufferSpentTime = 0;
//  
//  if (queueBufferDelay[queueCommandIdx] == 0)
//    Send_Command(queueBuffer[queueCommandIdx]);
//  else
//    TIM3_SetCounter(0);
//}

/**
  * @brief  this function extracts the received buffer and operates the needed functionalities such as(updating registers , turning on or off the driver, clearing faults and ect)
  * @param  buffer: the received buffer to be extracted
  * @retval none
  */
void Drv_Parse_Response(uint8_t* buffer)
{
//   do actions
  if (buffer[1] == 0x81)
  {
    appState.fault = No_Fault;
    reg[FAULTS] = appState.fault;
  }
  else if (buffer[1] == 0x85)
  {
    //UART_Send(3,buffer,8);
    if(buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_VTH][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_VTH][REGISTER_INDEX])
    {
      // Driver Temp Calculation
      uint16_t driverNtcAdc;
      float driverTemp;
      
      driverNtcAdc = (uint16_t)buffer[4] | ((uint16_t)buffer[5] << 8);
      driverTemp = Drv_Calculate_Ntc_Temp(driverNtcAdc);
      
      if(appState.driverActualTemp == 0)
        appState.driverActualTemp = driverTemp;
      appState.driverActualTemp = 0.8*appState.driverActualTemp + 0.2*driverTemp + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0);
    }
    else if(buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_LIMIT_FLAG][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_LIMIT_FLAG][REGISTER_INDEX])
    {
      appState.limitFlag = (uint8_t)buffer[4];
    }
    else if(buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_DC_BUS_VOLTAGE][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_DC_BUS_VOLTAGE][REGISTER_INDEX])
    {
      appState.driverDcBusVoltage = ((uint16_t)buffer[4] | ((uint16_t)buffer[5] << 8))*10;
      appState.driverDcBusVoltage /= 61;
      if(appState.driverDcBusVoltage < DC_BUS_VOLTAGE_LOWER_HAZARD || appState.driverDcBusVoltage > DC_BUS_VOLTAGE_UPPER_HAZARD)
        Buzzer_Operation(Valve);
    }
  }
  
  else if (buffer[1] == 0x86)
  {
    // pump
    if (buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_PUMP][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_PUMP][REGISTER_INDEX])
    {
      if (buffer[4] == 0x20)
      {
        appState.valveOn = 1;
        appState.valveTimeout = 0;
        appState.pumpOn = 0;
      }
      if (buffer[4] == 0x10) // former is :0x27
      {
        appState.pumpOn = 1;
        appState.valveOn = 0;
        appState.valveTimeout = 0;
        reg[PUMP] = 1;
      }
      else if (buffer[4] == 0x00) // former is :0x28
      {
        appState.valveOn = 0;
        appState.valveTimeout = 0;
        appState.pumpOn = 0;
        reg[PUMP] = 0;
      }
      appState.pumpFlag = 1;
      LCD_Glass_Update_By_State();
      eepromWriteData(PUMP, (uint8_t*)&reg[PUMP], 2);
    }
    // power
    else if (buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_STOP_START][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_STOP_START][REGISTER_INDEX])
    {
      if (buffer[4] == 0x0)
      {
        if (skipPowerOff == 0)
        {
          if(appState.fault == Driver_Current_Mismatch)
            appState.fault = No_Fault;
          
          appState.powerOn = 0;
          reg[POWER] = 0;
          appState.pendingOff = 0;
          appSettings.keyPowerPressFlag = 0;
          powerOffTryCnt = 0;
          
          appState.timerChangingTimeout = 0;
          appState.dayTimeOff = -1;
          
          CMDs_PWR(CMD_REL, OFF);
        }
        else
        {
          skipPowerOff = 0;
        }
        appState.actualSpeed = 0;
        appState.actualTorque = 0;
      }
      else if (buffer[4] == 0x1)
      {
        appState.powerOn = 1;
        reg[POWER] = 1;
        appState.pendingOn = 0;
        reg[FIRST_BOOT_FLAG_AFTER_POWERON] = 0;
        appState.dayTimeOn = -1;
        appState.drvStartTimeOut = 1;
      }
      
      updateTempOffsetTimeOut();
      LCD_Glass_Update_By_State();
      eepromWriteData(POWER, (uint8_t*)&reg[POWER], 2);
    }
    // pfc
    else if ((buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_PFC][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_PFC][REGISTER_INDEX]))
    {
      if (buffer[4] == 0x1)
      {
        appState.pfcOn = 1;
        reg[PFC] = 1;
      }
      else if (buffer[4] == 0x0)
      {
        appState.pfcOn = 0;
        reg[PFC] = 0;
      }
      eepromWriteData(PFC, (uint8_t*)&reg[PFC], 2);
    }
    // speed
    else if ((buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_SPEED][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_SPEED][REGISTER_INDEX]) && (controlMode[reg[MOTOR_CONTROL_MODE]-1] == DRV_REG_SPEED))
    {
      uint32_t rpm = (uint32_t)buffer[4];
      rpm += ((uint32_t)buffer[5]) << 8;
      uint32_t percent;
      
      if((int16_t)rpm < 0) // if the spin is in reverse mode then multiply the returned rpm by -1
        rpm = (uint32_t)((uint16_t)rpm*(-1));
      
      if (rpm < (reg[SPEED_MIN_PERCENT_REG] * 4095 / 1000))
        percent = 0;
      else
      {
        percent = (rpm - (uint32_t)reg[SPEED_MIN_PERCENT_REG] * 4095 / 1000) * 1000 / (reg[SPEED_MAX_PERCENT_REG]-reg[SPEED_MIN_PERCENT_REG]) * 2 * 100 / 4095;
        if (percent > 200)
          percent = 200;
      }
      // round percent to be multiply of 10 (2x5%)
      if ((percent % 10) >= 5)
        percent += 5;
      percent = (percent / 10) * 10;
      if(appState.powerOn)
        appState.actualSpeed = (uint8_t)percent;
      updateTempOffsetTimeOut();
      reg[SPEED] = appState.actualSpeed;
      if (rpm != 0 || skipPowerOff != 0 && appState.autoMode == 0)
      {
        appState.speedSetPoint = (uint8_t)percent;
        appState.speedSetpointFlag = 1;
        reg[SPEED_SETPOINT] = appState.speedSetPoint;
        eepromWriteData(SPEED_SETPOINT, (uint8_t*)&reg[SPEED_SETPOINT], 2);
        LCD_Glass_Update_By_State();
      }
    }
    // Torq
    else if((buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_TORQUE][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_TORQUE][REGISTER_INDEX]) ||
            (buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_POWER][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_POWER][REGISTER_INDEX]))
    {
      uint32_t trq = (uint32_t)buffer[4];
      trq += ((uint32_t)buffer[5]) << 8;
      uint32_t torquePercent;
      
      if((int16_t)trq < 0) // if the spin is in reverse mode then multiply the returned trq by -1
        trq = (uint32_t)((uint16_t)trq*(-1));
      
      if (trq < (reg[TRQ_MIN_PERCENT] * 4095 / 1000))
        torquePercent = 0;
      else
      {
        torquePercent = (trq - (uint32_t)reg[TRQ_MIN_PERCENT] * 4095 / 1000) * 1000 / (reg[TRQ_MAX_PERCENT]-reg[TRQ_MIN_PERCENT]) * 2 * 100 / 4095;
        if (torquePercent > 200)
          torquePercent = 200;
      }
      // round torquePercent to be multiply of 10 (2x5%)
      if ((torquePercent % 10) >= 5)
        torquePercent += 5;
      torquePercent = (torquePercent / 10) * 10;
      if(appState.powerOn)
        appState.actualTorque = (uint8_t)torquePercent;
      updateTempOffsetTimeOut();
      reg[TORQUE] = appState.actualTorque;
      if ((trq != 0) || (skipPowerOff != 0) && appState.autoMode == 0)
      {
        appState.speedSetPoint = (uint8_t)torquePercent;
        appState.speedSetpointFlag = 1;
        reg[SPEED_SETPOINT] = appState.speedSetPoint;
        eepromWriteData(SPEED_SETPOINT, (uint8_t*)&reg[SPEED_SETPOINT], 2);
        LCD_Glass_Update_By_State();
      }
    }
    //Motor Ctrl Mode
    else if((buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_CTRL_MODE_SELECT][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_CTRL_MODE_SELECT][REGISTER_INDEX]))
    {
      if(buffer[4] == 0x01 || buffer[4] == 0x02 || buffer[4] == 0x03)
      {
        appSettings.parameterConfirmedValue[MOTOR_CONTROL_MODE - 35] = appSettings.parameterValue[MOTOR_CONTROL_MODE - 35];
        reg[MOTOR_CONTROL_MODE] = appSettings.parameterConfirmedValue[MOTOR_CONTROL_MODE - 35];
        eepromWriteData(MOTOR_CONTROL_MODE, (uint8_t*)&reg[MOTOR_CONTROL_MODE], 2);
        appSettings.waitingForDrvResponse = 0;
      }
    }
    //SCRIPT_COMMAND
    else if((buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_SCRIPT][APP_ID] && buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_SCRIPT][REGISTER_INDEX]))
    {
      if(buffer[4] == 0x11)
        appSettings.parameterValue[DRIVER_SCRIPT_EN - 35] = 1;        
      else if(buffer[4] == 0x00)
       appSettings.parameterValue[DRIVER_SCRIPT_EN - 35] = 0;
      
      appSettings.parameterConfirmedValue[DRIVER_SCRIPT_EN - 35] = appSettings.parameterValue[DRIVER_SCRIPT_EN - 35];
      reg[DRIVER_SCRIPT_EN] = appSettings.parameterConfirmedValue[DRIVER_SCRIPT_EN - 35];
      eepromWriteData(DRIVER_SCRIPT_EN, (uint8_t*)&reg[DRIVER_SCRIPT_EN], 2);
    }
  }
  //parameter loading and saving
  else if (buffer[1] == 0xA0 && appSettings.settingModeEnable)
  {
    if((buffer[2] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_LOAD_PARAM][APP_ID]) && (buffer[3] == addressTable[reg[IMC_CODE_VERSION]][DRV_REG_LOAD_PARAM][REGISTER_INDEX]))
    {
      if(buffer[4] == 0x00)
      {
        appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - 35] = appSettings.parameterValue[DRIVER_CONFIG_NUM - 35];
        reg[DRIVER_CONFIG_NUM] = appSettings.parameterValue[DRIVER_CONFIG_NUM - 35];
        eepromWriteData(DRIVER_CONFIG_NUM, (uint8_t*)&reg[DRIVER_CONFIG_NUM], 2);
//        UART_Send(3, (char*)&reg[DRIVER_CONFIG_NUM], 2);
      }
      else if(buffer[4] == 0x01 || buffer[4] == 0x02)
      {
        appSettings.parameterValue[DRIVER_CONFIG_NUM - 35] = appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - 35];
        reg[DRIVER_CONFIG_NUM] = appSettings.parameterValue[DRIVER_CONFIG_NUM - 35];
        LCD_Glass_Update_By_State();
      }
      appSettings.waitingForDrvResponse = 0;
    }
//    if((buffer[2] == addressTable[SAVE_PARAM_CMD][reg[IMC_CODE_VERSION]][APP_ID]) && (buffer[3] == addressTable[SAVE_PARAM_CMD][reg[IMC_CODE_VERSION]][REGISTER_INDEX]))
//    {
//    }
  }
  else if (buffer[1] == 0x80)
  {
    if(appState.fault != Driver_Current_Mismatch)
    {
      uint16_t faults = (uint16_t)buffer[4];
      faults += ((uint16_t)buffer[5]) << 8;
      reg[FAULTS] = faults;
      
      if (faults == 0)
      {
        appState.fault = No_Fault;
      }
      else
      {
        for (int i = 0; i < 16; i++)
        {
          if (faults & (1 << i))
          {
            appState.fault = (Fault)(i + 1);
            break;
          }
        }
      }
      if(appState.drvStartTimeOut == DRIVER_CHECKFAULT_AFTER_START_TIMEOUT + 1)
      {
        appState.drvStartTimeOut = 0;
        
        if(faults && appState.drvStartTry < MAX_DRV_START_RETRY && appState.powerOn == ON)
        {
          skipPowerOn = 0;
          Drv_Power(ON);
          appState.drvStartTry ++;
        }
        else
        {
          appState.drvStartTry = 0;
        }
      }
    }
  }
}

/**
  * @brief  Calculate the driver temperature according to adcAvg value recieved from driver ntc
  * @param  buffer: recieved 2byte driver ntc data
  * @retval return the calculated temp
  */
float Drv_Calculate_Ntc_Temp(uint16_t buffer)
{
  float vlt, res ;
  vlt = ((float)buffer) * 5/4096;
  res = (1000.0 * vlt) / (5 - vlt);
  return interpolateTemp(res);
}

/**
  * @brief  generating jason as payload for the esp to be sent to site
  * @param  none
  * @retval return the pointer of payload
  */
char* Payload_Generator()
{
  static char payload[75];
  memset(payload, 0, sizeof(payload));
  
  strcat(payload, "{");
  //////////    subscribed variables    //////////
  if(appState.autoFlag)
  {
    sprintf(payload + strlen(payload), "\"mode\":%d,",appState.autoMode);
    appState.autoFlag = 0;
  }
  else if(appState.pumpFlag)
  {
    sprintf(payload + strlen(payload), "\"pump\":%d,",appState.pumpOn);
    appState.pumpFlag = 0;
  }
  else if(appState.powerFlag)
  {
    sprintf(payload + strlen(payload), "\"power\":%d,",appState.powerOn);
    appState.powerFlag = 0;
  }
  else if(appState.speedSetpointFlag)
  {
    sprintf(payload + strlen(payload), "\"sstp\":%d,", appState.speedSetPoint/2);
    appState.speedSetpointFlag = 0;
  }
  else if(appState.tempSetpointFlag)
  {
    sprintf(payload + strlen(payload), "\"tstp\":%.1f,", (float)appState.tempSetPoint/2);
    appState.tempSetpointFlag = 0;
  }
  //////////////////////////////////////////////////////////
  
  //////////  status: pwr,pmp,mde,spd,temp,fault  //////////
  sprintf(payload + strlen(payload), "\"pwr\":%d,\"mde\":%d,\"pmp\":%d,", appState.powerOn, appState.autoMode, appState.pumpOn); //,\"timer\":%.2f, ((appState.dayTimeOff - appState.nowTime - 1)/3600)
  
  if(reg[MOTOR_CONTROL_MODE] == 1)
    sprintf(payload + strlen(payload), "\"spd\":%d,", appState.actualSpeed/2);
  else if(reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)
    sprintf(payload + strlen(payload), "\"spd\":%d,", appState.actualTorque/2);
  
  sprintf(payload + strlen(payload), "\"offset\":%.2f,\"temp\":%.2f",appState.tempOffset, appState.actualTemp); // ,\"flt\":%d,\"dsn\":%d     , appState.fault, appState.disNum
  //////////////////////////////////////////////////////////
  strcat(payload, "}");

  return payload;  // No need to free(), but data may be overwritten in next call
}

char* Payload_Deinit_Generator()
{
  static char payload[75];
  memset(payload, 0, sizeof(payload));
  
  strcat(payload, "{");
  sprintf(payload + strlen(payload), "\"power\":%d,\"mode\":%d,\"pump\":%d,", appState.powerOn, appState.autoMode, appState.pumpOn); //,\"timer\":%.2f, ((appState.dayTimeOff - appState.nowTime - 1)/3600)
  sprintf(payload + strlen(payload), "\"sstp\":%d", appState.speedSetPoint/2);
  strcat(payload, "}");

  return payload;  // No need to free(), but data may be overwritten in next call
}



//////////// some get and set functions ////////////
void Drv_Set_Skip_PowerOn(uint8_t newVal)
{
  skipPowerOn = newVal;  
}

uint8_t Drv_Get_Queue_Command_Cnt(void)
{
  return queueCommandCnt;
}

uint8_t Drv_Get_is_Pending(void)
{
  return isPending;
}

float Drv_Get_Actual_Temp(void)
{
  return appState.driverActualTemp;
}

uint8_t Get_Timer_Changing_TimeOut(void)
{
  return appState.timerChangingTimeout;
}

uint8_t Get_Wifi_Auto_Connect(void)
{
  return appSettings.parameterConfirmedValue[WIFI_AUTO_CONNECT - 35];
}