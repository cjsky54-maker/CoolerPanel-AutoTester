#define OLD_LCD
#define OLD_PCB
#include "initialization.h"
#include "stm8l15x_conf.h"
#include "business_logic.h"
#include "variables.h"
#include "bluetooth.h"
#include "functions.h"
#include "lcd_seg.h"
#include "driver_protocol.h"

#define ADC1_DR_ADDRESS        ((uint16_t)0x5344)
#define USART1_RX_BUF_LEN       8
#define USART1_DR_ADDRESS       (uint16_t)0x5231  /* USART1 Data register Address */
#define USART2_DR_ADDRESS       (uint16_t)0x53E1  /* USART1 Data register Address */
#define USART3_DR_ADDRESS       (uint16_t)0x53F1  /* USART3 Data register Address */


void USART1_RX_DMA_Config(void);


USART_TypeDef * USART[4] = {USART1, USART1, USART2, USART3};

GPIO_TypeDef* LEDs_Port[2] = {GPIOF, GPIOF};
unsigned char LEDs_Pin[2] = {GPIO_Pin_4, GPIO_Pin_5};

GPIO_TypeDef* CMDs_Port[CMDS_NUM] = {GPIOA, GPIOD, GPIOE, GPIOE, GPIOF, GPIOF, GPIOG};
unsigned char CMDs_Pin[CMDS_NUM] = {GPIO_Pin_2, GPIO_Pin_7, GPIO_Pin_6, GPIO_Pin_7, GPIO_Pin_6, GPIO_Pin_7, GPIO_Pin_5};
unsigned char CMDs_State[2][CMDS_NUM] = {{0, 0, 1, 0, 1, 1, 1},	        // Reset state
                                         {1, 1, 0, 1, 0, 0, 0}};	// Set states
uint16_t ADC1ConvertedValue[ADC1_BUF_LEN];

uint8_t Rx1Buffer[USART1_RX_BUF_LEN] = {0, 0, 0, 0, 0, 0, 0, 0};




/**
  * @brief  Configure HSI and LSE 
  * @param  None
  * @retval None
  */
void CLK_Config(void)
{
  /*High speed external clock prescaler: 1*/
  CLK_SYSCLKDivConfig(CLK_SYSCLKDiv_1);
  
//  /* Select HSI as system clock source */
//  CLK_SYSCLKSourceSwitchCmd(ENABLE);
//  CLK_SYSCLKSourceConfig(CLK_SYSCLKSource_HSI);
//  /* High speed external clock prescaler: 1*/
//  CLK_SYSCLKDivConfig(CLK_SYSCLKDiv_1);
//  while (CLK_GetSYSCLKSource() != CLK_SYSCLKSource_HSI)
//  {}

  /* Configures RTC clock */
//  CLK_RTCClockConfig(CLK_RTCCLKSource_LSE, CLK_RTCCLKDiv_32);
//  CLK_PeripheralClockConfig(CLK_Peripheral_RTC, ENABLE);
  
}


/**
  * @brief  Wait 1 sec for LSE stabilization .
  * @param  None.
  * @retval None.
  * Note : TIM4 is configured for a system clock = 2MHz
  */
void LSE_StabTime(void)
{

  CLK_PeripheralClockConfig(CLK_Peripheral_TIM4, ENABLE);

  /* Configure TIM4 to generate an update event each 1 s */
  TIM4_TimeBaseInit(TIM4_Prescaler_16384, 123);
  /* Clear update flag */
  TIM4_ClearFlag(TIM4_FLAG_Update);

  /* Enable TIM4 */
  TIM4_Cmd(ENABLE);

  /* Wait 1 sec */
  while ( TIM4_GetFlagStatus(TIM4_FLAG_Update) == RESET );

  TIM4_ClearFlag(TIM4_FLAG_Update);

  /* Disable TIM4 */
  TIM4_Cmd(DISABLE);

  CLK_PeripheralClockConfig(CLK_Peripheral_TIM4, DISABLE);
}
/**
  * @brief  this function configs the rtc pripheral
  * @param  None
  * @retval None
  */
void RTC_Config(void)
{
  /* Enable LSE */
  CLK_LSEConfig(CLK_LSE_ON);
  /* Wait for LSE clock to be ready */
  while (CLK_GetFlagStatus(CLK_FLAG_LSERDY) == RESET);
  /* wait for 1 second for the LSE Stabilisation */
  LSE_StabTime();

  /* Select LSE (32.768 KHz) as RTC clock source */
  CLK_RTCClockConfig(CLK_RTCCLKSource_LSE, CLK_RTCCLKDiv_1);

  CLK_PeripheralClockConfig(CLK_Peripheral_RTC, ENABLE);
  
  /* Calendar Configuration */
  Calendar_Init();
}




/**
  * @brief  Configure led pins   
  * @param  None
  * @retval None
  */
void LEDs_Config(void)
{
  GPIO_Init(GPIOF, GPIO_Pin_4, GPIO_Mode_Out_PP_Low_Slow); 
  GPIO_Init(GPIOF, GPIO_Pin_5, GPIO_Mode_Out_PP_Low_Slow);
}


/**
  * @brief  Turn OFF/ON led(s)  
  * @param  channel: the selected led (LED1/LED2)
  * @param  status: led new state
  * @retval None
  */
void LEDs_PWR(unsigned int channel, unsigned char state)
{
  unsigned char i;
  for(i=0;i<2;i++)
  {
    if((channel & 1<<i) != 0)
    {
      if(state == 0)
        GPIO_ResetBits(LEDs_Port[i], LEDs_Pin[i]);
      else if(state == 1)
        GPIO_SetBits(LEDs_Port[i], LEDs_Pin[i]);
    }
  }
}


/**
  * @brief  Configure commands pins   
  * @param  None
  * @retval None
  */
void CMDs_Config(void)
{
  // Configure backlight command pin -> PA2
  GPIO_Init(GPIOA, GPIO_Pin_2, GPIO_Mode_Out_PP_Low_Slow); 
  
  // Configure ESP enable pin -> PD7
  GPIO_Init(GPIOD, GPIO_Pin_7, GPIO_Mode_Out_PP_Low_Slow); 
  
  // Configure usart1 direction pin -> PE6
  GPIO_Init(GPIOE, GPIO_Pin_6, GPIO_Mode_Out_PP_Low_Slow);  
    
  // Configure relay command pin -> PE7
  GPIO_Init(GPIOE, GPIO_Pin_7, GPIO_Mode_Out_PP_Low_Slow);
  
 #ifdef OLD_PCB
  // Configure learn key pin -> PC4
  GPIO_Init(GPIOC, GPIO_Pin_4, GPIO_Mode_Out_OD_Low_Slow);
  GPIO_SetBits(GPIOC, GPIO_Pin_4);
 #endif
 
 #ifdef NEW_PCB
  // Configure learn key pin -> PC1
  GPIO_Init(GPIOC, GPIO_Pin_1, GPIO_Mode_Out_OD_Low_Slow);
  GPIO_SetBits(GPIOC, GPIO_Pin_1);
 #endif
 
  // Configure BT reset pin -> PF7
  GPIO_Init(GPIOF, GPIO_Pin_7, GPIO_Mode_Out_PP_High_Slow); 
  
  // Configure clock pin -> PG5
  GPIO_Init(GPIOG, GPIO_Pin_5, GPIO_Mode_Out_PP_High_Fast); 
}

  
/**
  * @brief  Turn OFF/ON command(s)  
  * @param  channel: the selected command 
  * @param  (CMDS_NUM/CMD_BL/CMD_ESP_EN/CMD_USART_DIR/CMD_REL/CMD_RF_KEY/CMD_BT_NRST)
  * @param  status: command new state
  * @retval None
  */
void CMDs_PWR(unsigned int channel, unsigned char state)
{
  unsigned char i, cmdState;
  for(i=0;i<CMDS_NUM;i++)
  {
    if((channel & 1<<i) != 0)
    {
      cmdState = CMDs_State[state][i];
      if(cmdState == 0)
        GPIO_ResetBits(CMDs_Port[i], CMDs_Pin[i]);
      else if(cmdState == 1)
        GPIO_SetBits(CMDs_Port[i], CMDs_Pin[i]);
    }
  }
}


/**
  * @brief  Configure input pins   
  * @param  None
  * @retval None
  */
void Inputs_Config(void)
{
  //Global interrupts must be disabled before calling EXTI_SetPinSensitivity() function
  //disableInterrupts() ;
  
  // PG4 & PG7 -> Data Pin  
  GPIO_Init(GPIOG, GPIO_Pin_4, GPIO_Mode_In_FL_No_IT);  
  GPIO_Init(GPIOG, GPIO_Pin_7, GPIO_Mode_In_FL_IT);  
  EXTI_SetPinSensitivity(EXTI_Pin_7, EXTI_Trigger_Falling);
  
//  #ifdef NEW_LCD
//    GPIO_Init(GPIOC, GPIO_Pin_4, GPIO_Mode_In_FL_IT);
//    EXTI_SetPinSensitivity(EXTI_Pin_4, EXTI_Trigger_Rising_Falling);
//  #endif
  
  // PF6 -> RF Receive
  GPIO_Init(GPIOF, GPIO_Pin_6, GPIO_Mode_In_FL_IT);  
  EXTI_SetPinSensitivity(EXTI_Pin_6, EXTI_Trigger_Rising_Falling);
  // PG0 -> RF OUT 1  
  GPIO_Init(GPIOG, GPIO_Pin_0, GPIO_Mode_In_FL_No_IT);  
  //EXTI_SetPinSensitivity(EXTI_Pin_4, EXTI_Trigger_Falling);
  
  // PG1 -> RF OUT 2  
  GPIO_Init(GPIOG, GPIO_Pin_1, GPIO_Mode_In_FL_No_IT);  
  //EXTI_SetPinSensitivity(EXTI_Pin_5, EXTI_Trigger_Falling);
  
  // PG2 -> RF OUT 3  
  GPIO_Init(GPIOG, GPIO_Pin_2, GPIO_Mode_In_FL_No_IT);  
  //EXTI_SetPinSensitivity(EXTI_Pin_6, EXTI_Trigger_Falling);
  
  // PG3 -> RF OUT 4  
  GPIO_Init(GPIOG, GPIO_Pin_3, GPIO_Mode_In_FL_No_IT);  
  //EXTI_SetPinSensitivity(EXTI_Pin_7, EXTI_Trigger_Falling);
  
  //enableInterrupts();
}


/**
  * @brief  Configure USART1 (used for connecting to driver)   
  * @param  baudrate: the desired baudrate
  * @retval None
  */
void USART1_Config(unsigned long int baudrate)
{
  // Enable clock USART 
  CLK_PeripheralClockConfig(CLK_Peripheral_USART1, ENABLE);
  
  // Configure USART1 Pins -> RX: PC.2, TX: PC.3
  GPIO_Init(GPIOC, GPIO_Pin_2, GPIO_Mode_In_FL_No_IT);
  GPIO_Init(GPIOC, GPIO_Pin_3, GPIO_Mode_Out_PP_High_Fast);
    
  // Initialize USART
  USART_DeInit(USART1);
  USART_Init(USART1, baudrate, USART_WordLength_8b, USART_StopBits_1, USART_Parity_No,
             (USART_Mode_TypeDef)(USART_Mode_Rx | USART_Mode_Tx));
  
  // Enable RXNE Interrupt
//  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); 
  
  USART1_RX_DMA_Config();

  // Enable USART
  USART_Cmd(USART1, ENABLE); 
  
}


/**
  * @brief  Configure USART2 (used for connecting to wifi module)   
  * @param  baudrate: the desired baudrate
  * @retval None
  */
void USART2_Config(unsigned long int baudrate)
{
  // Enable clock USART 
  CLK_PeripheralClockConfig(CLK_Peripheral_USART2, ENABLE);
    
  // Configure USART2 Pins -> RX: PE.3, TX: PE.4
  GPIO_Init(GPIOE, GPIO_Pin_3, GPIO_Mode_In_FL_No_IT);
  GPIO_Init(GPIOE, GPIO_Pin_4, GPIO_Mode_Out_PP_High_Fast);
    
  // Initialize USART
  USART_DeInit(USART2);
  USART_Init(USART2, baudrate, USART_WordLength_8b, USART_StopBits_1, USART_Parity_No,
             (USART_Mode_TypeDef)(USART_Mode_Rx | USART_Mode_Tx));
  
  // Enable RXNE Interrupt
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE); 

  // Enable USART
  USART_Cmd(USART2, ENABLE); 
}


/**
  * @brief  Configure USART3 (used for connecting to bluetooth module)   
  * @param  baudrate: the desired baudrate
  * @retval None
  */
void USART3_Config(unsigned long int baudrate)
{
  // Enable clock USART 
  CLK_PeripheralClockConfig(CLK_Peripheral_USART3, ENABLE);
  
  // Remap USART3 pins to Port F
  SYSCFG_REMAPPinConfig(REMAP_Pin_USART3TxRxPortF, ENABLE);
  
  // Configure USART3 Pins -> RX: PF.1, TX: PF.0
  GPIO_Init(GPIOF, GPIO_Pin_1, GPIO_Mode_In_FL_No_IT);
  GPIO_Init(GPIOF, GPIO_Pin_0, GPIO_Mode_Out_PP_High_Fast);
    
  // Initialize USART
  USART_DeInit(USART3);
  USART_Init(USART3, baudrate, USART_WordLength_8b, USART_StopBits_1, USART_Parity_No,
             (USART_Mode_TypeDef)(USART_Mode_Rx | USART_Mode_Tx));
  
  // Enable RXNE Interrupt
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE); 

  // Enable USART
  USART_Cmd(USART3, ENABLE); 
}


/**
  * @brief  Send data on selected USART port   
  * @param  channel: the selected usart port (1/2/3)
  * @param  pucBuffer: pointer to the send buffer
  * @param  ulCount: the length of buffer that should be transmitted
  * @retval None
  */
void UART_Send(unsigned char channel, const char *pucBuffer, unsigned long ulCount)
{
  uint16_t i;
  USART_ClearFlag(USART[channel], USART_FLAG_TC);
  if(channel == 1)
    CMDs_PWR(CMD_USART_DIR, DIR_TX);
  while(ulCount--)
  {
    if(channel > 0 && channel < 4)
    {
      USART_SendData8(USART[channel], (uint16_t) *pucBuffer++);
      // Loop until the end of transmission
      while(USART_GetFlagStatus(USART[channel], USART_FLAG_TC) == RESET)
      {}
    }
  }
  for(i=0;i<100;i++)
  {}
  if(channel == 1)
    CMDs_PWR(CMD_USART_DIR, DIR_RX);
}

void UART1_Send_DMA(char* pucBuffer, unsigned int uiCount)
{
  if (DMA1_Channel1->CNBTR)
  {
    // DMA is working right now
    return;
  }
  
  // Changing Direction of Onewire to Output
  CMDs_PWR(CMD_USART_DIR, DIR_TX);

  // Enable DMA1 clock
  CLK_PeripheralClockConfig(CLK_Peripheral_DMA1, ENABLE);
  
  // Global DMA Disable
  DMA_GlobalCmd(DISABLE);
  
  // DMA Channel deinit
  DMA_DeInit(DMA1_Channel1);
  
  // Configure DMA
  DMA_Init(DMA1_Channel1, 
           (uint32_t)pucBuffer,
           (uint16_t)USART1_DR_ADDRESS,
           uiCount, 
           DMA_DIR_MemoryToPeripheral, 
           DMA_Mode_Normal,
           DMA_MemoryIncMode_Inc, 
           DMA_Priority_High, 
           DMA_MemoryDataSize_Byte);

  // Clear TC Flag
  DMA_ClearFlag(DMA1_FLAG_TC1);

  //Enable Dma Interrupt
  DMA_ITConfig(DMA1_Channel1, DMA_ITx_TC, ENABLE);
  
  //Enable USART DMA TX Requsts
  USART_DMACmd(USART1, USART_DMAReq_TX, ENABLE);

  // Global DMA Enable
  DMA_GlobalCmd(ENABLE);
  
  // Enable the USART Tx DMA channel
  DMA_Cmd(DMA1_Channel1, ENABLE);
}


//void UART3_Send_DMA(char* pucBuffer, unsigned int uiCount)
//{
//  if (DMA1_Channel1->CNBTR)
//  {
//    // DMA works right now
//    return;
//  }
//  // Enable DMA1 clock
//  CLK_PeripheralClockConfig(CLK_Peripheral_DMA1, ENABLE);
//  
//  // Global DMA Disable
//  DMA_GlobalCmd(DISABLE);
//  
//  // DMA Channel deinit
//  DMA_DeInit(DMA1_Channel1);
//  
//  // Configure DMA
//  DMA_Init(DMA1_Channel1, 
//           (uint16_t)pucBuffer,
//           (uint16_t)USART3_DR_ADDRESS,
//           uiCount, 
//           DMA_DIR_MemoryToPeripheral, 
//           DMA_Mode_Normal,
//           DMA_MemoryIncMode_Inc, 
//           DMA_Priority_High, 
//           DMA_MemoryDataSize_Byte);
//
//  // Clear TC Flag
//  DMA_ClearFlag(DMA1_FLAG_TC1);
//
//  //Enable USART DMA TX Requsts
//  USART_DMACmd(USART3, USART_DMAReq_TX, ENABLE);
//
//  // Global DMA Enable
//  DMA_GlobalCmd(ENABLE);
//  
//  // Enable the USART Tx DMA channel
//  DMA_Cmd(DMA1_Channel1, ENABLE);
//}

uint8_t Is_USART1_DMA_Busy()
{
	int i;
	for (i = 0; i < 100; i++)
	{
		if (!DMA1_Channel1->CNBTR)
		{
			// DMA is free
			return 1;
		}
		delay_ms(1);
	}
	return 0;
}

//uint8_t Is_USART3_DMA_Busy()
//{
//	int i;
//	for (i = 0; i < 100; i++)
//	{
//		if (!DMA1_Channel1->CNBTR)
//		{
//			// DMA is free
//			return 0;
//		}
//		delay_ms(1);
//	}
//	return 1;
//}


/**
  * @brief  Configure I2C1 (used for connecting to touch module (DS818A-2))   
  * @param  None
  * @retval None
  */
void I2C1_Config(void)
{
  /* I2C1 Periph clock enable */
  CLK_PeripheralClockConfig(CLK_Peripheral_I2C1, ENABLE);

  /* Configure SCL pin ?????????? */ 
  // GPIO_Init(GPIOC, GPIO_Pin_1, GPIO_Mode_Out_OD_HiZ_Fast);

  /*Configure SDA pin ?????????? */
  // GPIO_Init(GPIOC, GPIO_Pin_0, GPIO_Mode_Out_OD_HiZ_Fast);

  /* I2C DeInit */
  I2C_DeInit(I2C1);

  /* I2C configuration */
  I2C_Init(I2C1, 10000, 0x00, I2C_Mode_I2C,
           I2C_DutyCycle_2, I2C_Ack_Enable, I2C_AcknowledgedAddress_7bit);

  /* I2C Init */
  I2C_Cmd(I2C1, ENABLE);  

}


/**
  * @brief  Configure TIM2 peripheral for generating 4 Hz interrupts 
  * @param  None
  * @retval None
  */
void TIM2_Config(void)
{
  /* Enable TIM2 clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_TIM2, ENABLE);
  
  /* TIM2 configuration:
     TIM2 Channel1 output frequency = TIM2CLK / (TIM2 Prescaler * (TIM2_PERIOD + 1))
                                   = 16MHz / (128 * 31249) = 4 Hz */
  /* Time Base configuration */
  TIM2_TimeBaseInit(TIM2_Prescaler_128, TIM2_CounterMode_Up, 31249);
  
  /* Enable Update Interrupt */
  TIM2_ITConfig(TIM2_IT_Update, ENABLE);
  
  /* Enable TIM2 */
  TIM2_Cmd(ENABLE);
}


/**
  * @brief  Configure TIM3 peripheral for generating 40 Hz interrupts 
  * @param  None
  * @retval None
  */
void TIM3_Config(void)
{
  /* Enable TIM3 clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_TIM3, ENABLE);
  
  /* TIM3 configuration:
     TIM3 Channel1 output frequency = TIM3CLK / (TIM3 Prescaler * (TIM3_PERIOD + 1))40
                                   = 16MHz / (128 * 3125) = 40 Hz */
  /* Time Base configuration */
  TIM3_TimeBaseInit(TIM3_Prescaler_128, TIM3_CounterMode_Up, 3125);
  
  /* Enable Update Interrupt */
  TIM3_ITConfig(TIM3_IT_Update, ENABLE);
  
  /* Enable TIM3 */
  TIM3_Cmd(ENABLE);
}


/**
  * @brief  Configure TIM5 peripheral (Used for buzzer)  
  * @param  None
  * @retval None
  */
void TIM5_Config(void)
{
  /* Enable TIM5 clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_TIM5, ENABLE);
  
  /* TIM5 Channel1 configuration: PA7 */
  GPIO_Init(GPIOA, GPIO_Pin_7, GPIO_Mode_Out_PP_Low_Fast);
  
  /* TIM5 configuration:
     TIM5 Channel1 output frequency = TIM2CLK / (TIM5 Prescaler * (TIM5_PERIOD + 1))
                                   = 16MHz / (8 * 740) = 2.7 KHz */
  /* Time Base configuration */
  TIM5_TimeBaseInit(TIM5_Prescaler_8, TIM5_CounterMode_Up, 739);

  /* Channel 1 configuration in PWM1 mode */
  /* TIM5 channel Duty cycle is 100 * TIM2_PULSE / (TIM2_PERIOD + 1) = 100 * 370/740 = 50 % */
  TIM5_OC1Init(TIM5_OCMode_PWM1, TIM5_OutputState_Enable, 370, TIM5_OCPolarity_Low, TIM5_OCIdleState_Reset);
  TIM5_OC1PreloadConfig(ENABLE);

  /* TIM5 Main Output Enable */
  TIM5_CtrlPWMOutputs(ENABLE);
}


/**
  * @brief  Turn OFF/ON buzzer   
  * @param  state: the new state of buzzer
  * @retval None
  */
void Buzzer_PWR(unsigned char state)
{
  if (state == ON)
  {
    TIM5_Cmd(ENABLE);
  }
  else if (state == OFF)
  {
    TIM5_Cmd(DISABLE);
    TIM5->CNTRH = 0;
    TIM5->CNTRL = 0;
  }
}


/**
  * @brief  play buzzer   
  * @param  ms: the time buzzer is played in mili second
  * @retval None
  */
void Buzzer_Play(unsigned short ms)
{
  unsigned long int i, cnt = 1000*ms;
  Buzzer_PWR(ON);
  for(i=0;i<cnt;i++)
  {}
  Buzzer_PWR(OFF);
}


/**
  * @brief  Configure ADC1 & DMA1 for reading ADC data (temperature sensor) using DMA   
  * @param  None
  * @retval None
  */
void ADC1_DMA_Config(void)
{
  /* Enable ADC1 clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_ADC1, ENABLE);

  /* Enable DMA1 clock */
  CLK_PeripheralClockConfig(CLK_Peripheral_DMA1, ENABLE);
  
  /* ADC1 Channel3 configuration: PC7 ??????????????/*/
  // GPIO_Init(GPIOC, GPIO_Pin_7, GPIO_Mode_In_FL_No_IT);
  
  /* Initialize and configure ADC1 */
  ADC_Init(ADC1, ADC_ConversionMode_Continuous, ADC_Resolution_12Bit, ADC_Prescaler_2);
  ADC_SamplingTimeConfig(ADC1, ADC_Group_SlowChannels, ADC_SamplingTime_96Cycles);
  ADC_SamplingTimeConfig(ADC1, ADC_Group_FastChannels, ADC_SamplingTime_96Cycles);

  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);

  /* Enable ADC1 Channels 3 */
  ADC_ChannelCmd(ADC1, ADC_Channel_3, ENABLE); /* connected to Temperature sensor*/
  
  /* Connect ADC to DMA channel 0 */
  SYSCFG_REMAPDMAChannelConfig(REMAP_DMA1Channel_ADC1ToChannel0);

  DMA_Init(DMA1_Channel0, (unsigned int)ADC1ConvertedValue,
           ADC1_DR_ADDRESS,
           ADC1_BUF_LEN,
           DMA_DIR_PeripheralToMemory,
           DMA_Mode_Circular,
           DMA_MemoryIncMode_Inc,
           DMA_Priority_High,
           DMA_MemoryDataSize_HalfWord);

  /* DMA Channel0 enable */
  DMA_Cmd(DMA1_Channel0, ENABLE);

  /* Enable DMA1 channel0 Transfer complete interrupt */
  //DMA_ITConfig(DMA1_Channel0, DMA_ITx_TC, ENABLE);

  /* DMA enable */
  DMA_GlobalCmd(ENABLE);
  
  /* Enable ADC1 DMA requests */
  ADC_DMACmd(ADC1, ENABLE);
  
  /* Start Reading data */
  ADC_SoftwareStartConv(ADC1);
}


/**
  * @brief  Configures the LCD GLASS relative GPIO port IOs and LCD peripheral.
  * @param  None
  * @retval None
  */
void LCD_GLASS_Config(void)
{
  /*
    The LCD is configured as follow:
     - clock source = LSE (32.768 KHz)
     -> LCD CLK = RTC CLK/2
     - Voltage source = Internal
     - Prescaler = 2
     - Divider = 18 (16 + 2)  
     - Mode = 1/4 Duty, 1/3 Bias
     - LCD frequency = (clock source * Duty) / (Prescaler * Divider)
                     = 228 Hz ==> Frame frequency = 57 Hz */

  /* Enable LCD clock */
  CLK_RTCClockConfig(CLK_RTCCLKSource_LSE, CLK_RTCCLKDiv_1);
  CLK_PeripheralClockConfig(CLK_Peripheral_RTC, ENABLE);
  CLK_PeripheralClockConfig(CLK_Peripheral_LCD, ENABLE);
  

  /* Initialize the LCD */
 #ifdef OLD_LCD
  LCD_Init(LCD_Prescaler_2, LCD_Divider_18, LCD_Duty_1_4,
           LCD_Bias_1_2, LCD_VoltageSource_Internal);
 #endif
 
 #ifdef NEW_LCD
  LCD_Init(LCD_Prescaler_2, LCD_Divider_18, LCD_Duty_1_4,
           LCD_Bias_1_3, LCD_VoltageSource_Internal);
 #endif
 
  /* Mask register -> Seg1~3 & Seg6~20 are used*/ 
  // Seg0~7
  LCD_PortMaskConfig(LCD_PortMaskRegister_0, 0xCE);
  // Seg8~15
  LCD_PortMaskConfig(LCD_PortMaskRegister_1, 0xFF);
  // Seg16~23
  LCD_PortMaskConfig(LCD_PortMaskRegister_2, 0x1F);
  // seg24~31
  // LCD_PortMaskConfig(LCD_PortMaskRegister_3, 0x00);
 #ifdef OLD_LCD
  LCD_ContrastConfig(LCD_Contrast_Level_7);
 #endif
  
 #ifdef NEW_LCD
  LCD_ContrastConfig(LCD_Contrast_Level_5);
 #endif
  
  LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast()/*LCD_DeadTime_0*/);
  LCD_PulseOnDurationConfig(LCD_PulseOnDuration_1);
  // ToDo: enable high drive
  LCD_HighDriveCmd(ENABLE);
  
  // Enable Start of Frame Interrupt
  LCD_ITConfig(ENABLE);  

  LCD_Cmd(ENABLE); /*!< Enable LCD peripheral */
}

/**
  * @brief  configs bluetooth by finding its baudrate and Increasing it's power
  * @param  None
  * @retval None
  */
void Bluetooth_Config()
{
  uint32_t baud = BT_DetectBaud();
  if (baud != 0 && BT_CheckBaud(baud))
  {
//          Send_Log_QC(BT_MDL_CONNECTION, LOG_SUCCESS, NULL, INFO_LOG, BT_SRC);
  }
  else
  {
//          Send_Log_QC(BT_MDL_CONNECTION, LOG_FAIL, NULL, ERROR_LOG, BT_SRC);
  }
//  ReloadWatchdog("Inside main configuration 2");
  delay_ms(400);
  BT_Increase_Power();
  delay_ms(100);
}


/**
  * @brief  Generates delay in mili second
  * @param  ms: delay value in mili seconf
  * @retval None
  */
void delay_ms(uint16_t ms)
{
  unsigned long int i, cnt = (unsigned long) ms*415;
  for(i=0;i<cnt;i++)
  {}
}


/**
  * @brief  Configures all used peripherals with appropriate settings
  * @param  None
  * @retval None
  */
void Periph_Config()
{
  CLK_Config();
  //clk = CLK_GetClockFreq();
  USART2_Config(115200);
  RTC_Config();
  LEDs_Config();
  CMDs_Config();
  Inputs_Config();
  TIM2_Config();
  TIM3_Config();
  TIM5_Config();
  USART1_Config(9600);
  
  USART3_Config(115200);
  ADC1_DMA_Config();
  LCD_GLASS_Config();
  CMDs_PWR(CMD_BL, ON);
  /* Enable general interrupts */
  enableInterrupts();
  LCD_GLASS_Struct_Deinit(); 
//  LCD_Glass_Play_Demo(lcdGlass);
  LCD_Glass_Update_By_State();
  //UART_Send(2,"int cnfg", 8);
  Buzzer_PWR(ON);
  delay_ms(300);
  Buzzer_PWR(OFF);
  //UART_Send(2,"before bl cnfg", 14);
  Bluetooth_Config();
  //UART_Send(2,"bl configed", 11);
}

/**
  * @brief  configs the uart 1 peripheral
  * @param  none
  * @retval none
  */
void USART1_RX_DMA_Config(void)
{
  /* Deinitialize DMA channels */
  DMA_GlobalDeInit();
  
   // Enable DMA1 clock
  CLK_PeripheralClockConfig(CLK_Peripheral_DMA1, ENABLE);
  
  // Global DMA Disable
  DMA_GlobalCmd(DISABLE);

//  DMA_DeInit(DMA1_Channel1);
  DMA_DeInit(DMA1_Channel2);    // usart1 rx

  /* DMA channel Rx of USART Configuration */
  DMA_Init(DMA1_Channel2, (uint32_t)Rx1Buffer, (uint16_t)USART1_DR_ADDRESS,
           USART1_RX_BUF_LEN, DMA_DIR_PeripheralToMemory, DMA_Mode_Circular,
           DMA_MemoryIncMode_Inc, DMA_Priority_Medium, DMA_MemoryDataSize_Byte);

//  /* DMA channel Tx of USART Configuration */
//  DMA_Init(USART_DMA_CHANNEL_TX, (uint16_t)TxBuffer, (uint16_t)USART1_DR_ADDRESS,
//           DATA_TO_TRANSFER, DMA_DIR_MemoryToPeripheral, DMA_Mode_Normal,
//           DMA_MemoryIncMode_Inc, DMA_Priority_High, DMA_MemoryDataSize_Byte);
  
  DMA_ITConfig(DMA1_Channel2, DMA_ITx_TC, ENABLE);

  /* Enable the USART Tx/Rx DMA requests */
//  USART_DMACmd(EVAL_COM1, USART_DMAReq_TX, ENABLE);
  USART_DMACmd(USART1, USART_DMAReq_RX, ENABLE);
  
  /* Global DMA Enable */
  DMA_GlobalCmd(ENABLE);

  /* Enable the USART Tx DMA channel */
//  DMA_Cmd(USART_DMA_CHANNEL_TX, ENABLE);
  /* Enable the USART Rx DMA channel */
  DMA_Cmd(DMA1_Channel2, ENABLE);         
  
}

/**
  * @brief  this function writes the buffer values in to eeorom.
  * @param  numberOfBytes: number of data bytse to be written in to a  eeprom
  * @param  dataToEeprom: data register which is gunna be written in to eeprom 
  * @param  eepromDataAddress: eeprom section address
  * @retval none
  */
uint8_t eepromWriteData(uint32_t eepromDataAddress, uint8_t* dataToEeprom, uint16_t numberOfBytes)
{
  uint8_t timeOut = 0;
////////////////////unlocking EEPROM////////////////////
  if(FLASH_GetFlagStatus(FLASH_FLAG_DUL) == RESET)
  {
    FLASH_Unlock(FLASH_MemType_Data);
    // Waiting for EEPROM unlock
    timeOut = eepromUnlockTimeOut();
    if(timeOut)
      return 0; // it means flash is not unlocked
  }
////////////////////////////////////////////////////////  
  uint8_t writeByteTimedOut = 0;
  
  for(uint16_t cnt = 0 ; cnt < numberOfBytes ; cnt ++)
  {
    FLASH_ProgramByte(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS + 2*eepromDataAddress + cnt, dataToEeprom[cnt]);
    writeByteTimedOut = eepromWriteDataFinishTimeOut();
    if(writeByteTimedOut) //if writing byte is timed out , the function will breaks and returns 0 and doesn't write the remained bytes
      return 0; 
  }
  
  /*
  unsigned char writeByte[2]={0};
  uint8_t writeByteTimedOut = 0;
  
  writeByte[0] = dataToEeprom & 0xFF;
  writeByte[1] = (dataToEeprom & 0xFF00) >> 8;
  
  FLASH_ProgramByte(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS+2*eepromDataAddress,writeByte[1]);
  writeByteTimedOut = eepromWriteDataFinishTimeOut();
  if(!writeByteTimedOut)
    FLASH_ProgramByte(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS+2*eepromDataAddress+0x0001,writeByte[0]);
  */
  return 1; // it means write has been done successfully
}

/**
  * @brief  reads specified bytes of eeprom in to corresponding registers
  * @param  address: eeprom section address
  * @param  buffer: data buffer to be filled with eeprom data values
  * @param  numberOfBytes: number of data byte to be read from eeprom
  * @retval none
  */
void eepromReadData(uint32_t Address, uint8_t* buffer, uint16_t numberOfBytes)
{
 for (uint16_t cnt = 0 ; cnt < numberOfBytes ; cnt++)
 {
   buffer[cnt] = FLASH_ReadByte(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS + 2 * Address + cnt);
 }
 //return ((FLASH_ReadByte(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS + 2 * Address + 0x0001)) | ((FLASH_ReadByte(FLASH_DATA_EEPROM_START_PHYSICAL_ADDRESS + 2 * Address)) << 8));
}



/**
  * @brief  this function is called after the panel is booted , to initialize the registers (if the first boot is taken place then the registers are deinitialized with default values but if its not the first time of booting then registers are filled with eeprom data values)
  * @param  none
  * @retval none
  */
void Init_Registers()
{
  uint8_t constantWriteByte = 0x01;
  
  Deinit_Appstate();
  Deinit_Appsettings();
  
  eepromReadData(FIRST_BOOT_IS_PASSED, (uint8_t*)&reg[FIRST_BOOT_IS_PASSED], 2);
  if(!reg[FIRST_BOOT_IS_PASSED])
  {
    Reset_Registers_And_Eeprom_To_Factory_Values();
    reg[FIRST_BOOT_IS_PASSED] = 0x0001;
    eepromWriteData(FIRST_BOOT_IS_PASSED, &constantWriteByte, 1);   
  }
  else
  {
   Update_Ram_Registers_With_Eeprom_Datas();
  }
}


/**
  * @brief  this function makes a delay until eeprom writing data is finished(this is called right after calling eepromwrite command)
  * @param  none
  * @retval none
  */
uint8_t eepromWriteDataFinishTimeOut()
{
  uint16_t cnt = 0;
  uint8_t timedOut = 0;
  while (FLASH_GetFlagStatus(FLASH_FLAG_EOP) == RESET)
  {
    cnt++;   
    if(cnt == 20000)
    {
      timedOut = 1;
      break;
    }
  }
  return timedOut;
}

/**
  * @brief  this function makes a delay until eeprom unlocking process is finished(this is called right after calling eeprom unlock command)
  * @param  none
  * @retval timeOut: if the time exceeded the time out then this  flag returns 1 else it returns 0
  */
uint8_t eepromUnlockTimeOut()
{
  uint16_t cnt = 0;
  uint8_t timeOut = 0;
  while (FLASH_GetFlagStatus(FLASH_FLAG_DUL) == RESET)
  {
    cnt++;
    if(cnt == 20000)
    {
     timeOut = 1;
     break;
    }
  }
  return timeOut;
}

uint8_t* getRx1BufferPointer()
{
  return Rx1Buffer;
}
uint16_t* getADC1ConvertedValue()
{
  return ADC1ConvertedValue;
}

