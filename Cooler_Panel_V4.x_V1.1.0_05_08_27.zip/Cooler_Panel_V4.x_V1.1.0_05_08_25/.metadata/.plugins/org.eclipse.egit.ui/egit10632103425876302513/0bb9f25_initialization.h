/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __INITIALIZATION_H
 #define __INITIALIZATION_H

#include "stm8l15x.h"
#include "lcd_seg.h"


#define NEW_LCD
#define NEW_PCB
#define PCB_VERSION  410
#define CODE_VERSION 13


//RF_MODULE_TYPE 
#define RF_MDL_TYPE     CY41
#define RXC6            0
#define CY41            1

//REMOTE_TYPE 
#define REMOTE_TYPE  BW
#define WHITE           0
#define BW              1
#define BLACK           2

#define ADC1_BUF_LEN    210

#define OFF             0
#define ON              1

//#define DISABLE         0
//#define ENABLE          1

#define DIR_RX          0
#define DIR_TX          1

#define LED1            1
//#define LED2            2

#define CMDS_NUM        6
#define CMD_BL          1
#define CMD_RF_KEY      2
#define CMD_REL_SIG     4
#define CMD_USART_DIR   8
#define CMD_REL_PWR     16
#define CMD_CLK         32

#define SOFTWARE_VERSION        1
#define HARDWARE_VERSION        1

void CLK_Config(void);
void TIM4_Delay(void);
void RTC_Config(void);
void LEDs_Config(void);
void LEDs_PWR(unsigned char status);
void CMDs_Config(void);
void CMDs_PWR(unsigned int channel, unsigned char status);
void CMDs_PWR_Mannual(unsigned int channel);
void Inputs_Config(void);
void USART1_Config(unsigned long int baudrate);
void USART2_Config(unsigned long int baudrate);
//void USART3_Config(unsigned long int baudrate);
void UART_Send(unsigned char channel, const char *pucBuffer, unsigned long ulCount);
void UART1_Send_DMA(char* pucBuffer, unsigned int uiCount);
//void UART3_Send_DMA(char* pucBuffer, unsigned int uiCount);
uint8_t Is_USART1_DMA_Busy();
//uint8_t Is_USART3_DMA_Busy();
//void I2C1_Config(void);
//void TIM1_DMA_Config(void);
void TIM1_Config(void);
void TIM2_Config(void);
void TIM3_Config(void);
void TIM5_Config(void);
void Buzzer_PWR(unsigned char state);
void Buzzer_Play(unsigned short ms);
void ADC1_DMA_Config(void);
void DMA_Reconfig(DMA_Channel_TypeDef* DMA_Channelx);
void LCD_GLASS_Config(void);
void Read_Out_Protected(void);

//void Bluetooth_Config();

void delay_ms(uint16_t ms);
void Periph_Config();
void Init_Registers();

uint8_t eepromWriteData(uint32_t eepromDataAddress, uint8_t* dataToEeprom, uint16_t numberOfBytes);
uint8_t eepromWriteDataFinishTimeOut();
uint8_t eepromUnlockTimeOut();
void eepromReadData(uint32_t Address, uint8_t* buffer, uint16_t numberOfBytes);
void eepromClear(uint32_t Address, uint16_t numberOfWord);
void IWDG_Config(void);
void IWDG_Refresh(void);

uint8_t* getRx1BufferPointer();
uint16_t* getADC1ConvertedValue();
#endif /* __INITIALIZATION_H */