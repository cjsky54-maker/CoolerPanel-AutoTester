#ifndef __LCD_SEG_H_
  #define __LCD_SEG_H_

#define FIG_NUM         27
#define SEVEN_SEG_NUM   6
#define RAM_REG_NUM     14

//#define KEY_CLOCK       0
//#define KEY_UP          1
//#define KEY_DOWN        2
//#define KEY_POWER       3
//#define KEY_WATER       4
//#define KEY_AUTO        5
//#define KEY_SETTINGS    6
#define LINE_TOP        7
#define LINE_BOTTOM     8
#define FIG_BT          9
#define FIG_WIFI        10
#define FIG_WATER       11
#define FIG_ERROR       12
#define FIG_CLOCK       13
#define FIG_DEGREE_BIG  14
#define FIG_POINT_BIG   15
#define FIG_FAN         16
#define FIG_FAN_P1      17
#define FIG_FAN_P2      18
#define FIG_FAN_P3      19
#define FIG_FAN_P4      20
#define FIG_FAN_P5      21
#define FIG_ONE         22
#define FIG_POINT_SMALL 23
#define FIG_PERCENT     24
#define FIG_DEGREE_SMALL 25
#define FIG_AUTO        26

#define TOUCH_DOWN      0
#define TOUCH_UP        1
#define TOUCH_CLOCK     2
#define TOUCH_POWER     3
#define TOUCH_WATER     4
#define TOUCH_AUTO      5
#define TOUCH_SETTINGS  6

#define OFF             0
#define ON              1

#define SEVEN_SEG_OFF   10
#define SEVEN_SEG_ERR   11

#define LCD_STNADBY_TIMER 60
#define SEVEN_SEG_SYMBOL_NUMS 17

#define SEG_OFF         10
#define LETTER_E        11
#define LETTER_L        12
#define LETTER_P        13

typedef struct
{
  unsigned char needUpdate;
  unsigned char changesCompleted;
  unsigned char figs[FIG_NUM];
  unsigned char sevenSeg[SEVEN_SEG_NUM];
  unsigned char lcdRAM[RAM_REG_NUM];
} LCD_GLASS;

typedef enum
{
  KEY_CLOCK = 0,
  KEY_UP = 1,
  KEY_DOWN = 2,
  KEY_POWER = 3,
  KEY_WATER = 4,
  KEY_AUTO = 5,
  KEY_SETTINGS = 6,
} KEY_TYPE;

void LCD_GLASS_Struct_Deinit();
void LCD_GLASS_Struct_Init();
void LCD_GLASS_Update_Fig_Struct(unsigned char fig, unsigned char state);
void LCD_GLASS_Update_Fig(unsigned char fig, unsigned char state);
void LCD_GLASS_Update_SevenSeg_Struct(unsigned char sevenSegNum, unsigned char sevenSegVal);
void LCD_GLASS_Update_SevenSeg(unsigned char sevenSegNum, unsigned char sevenSegVal);
void LCD_GLASS_Update_Struct();
void LCD_GLASS_Update();

//setter getter
void LCD_GLASS_SET_changesCompleted(unsigned char value);



#endif /* __LCD_SEG_H_ */
