/*
 * ask_decoder.h
 *
 *  Created on: Dec 13, 2025
 *      Author: Mohammad Hossein
 */
/**
  ==============================================================================
                    ##### ASK Signal Specification #####
  ==============================================================================
  A valid ASK signal is composed of 25 bits. The period of each pulse is between
  1.2 to 1.5 milliseconds. If the duty cycle of the pulse is near 25%, that bit 
  is 0, and if the duty cycle of the pulse is near 75%, that bit is 1. The total
  duration of the signal is between 30 to 40 milliseconds. When a key is pressed
  on the remote control (transmitter), the signal is repeated every 40 to 50 
  milliseconds. (The free time between two signals is between 9 to 12 milliseconds).
  When no signal is on the bus, the receiver gets noise pulses.

  ==============================================================================
                  ##### How Library is implemented #####
  ==============================================================================
  For decoding the signal, the input signal on a pin is connected to 2 input 
  capture of one timer. So, one input-capture gets the onTime (on the falling 
  edge of the signal), and the other gets the period (on the rising edge of the 
  signal) and resets the counter. The interrupt of input capture, which measures
  the period, should be enabled. So, when its flag is set, on-time is available 
  on one input capture, and the period is available on the other input capture. 
  Because noise pulses exist on the bus, the interrupt of input capture is not 
  enabled at first. When a pulse greater than 8 milliseconds is received, the 
  timer overflows, and on this event, the interrupt of input capture is enabled.
  After receiving the complete signal, the interrupt of input capture is disabled.
  Also, if the period or duty cycle of each bit pulse is not correct, the input 
  capture interrupt is disabled and waits for a new reception of a pulse greater
  than 8 milliseconds. Because the first bit is not measured from the beginning,
  it is not decoded correctly and is not added to the signal. Also, the last bit
  can not be decoded, due to not having a rising edge.

  ==============================================================================
                   ##### How to use this driver #####
  ============================================================================== 
  The library has 2 functions. The ASK_StartReception should be called inside 
  the update IRQ Handler. The ASK_HandleReception should be called inside the 
  CCx IRQ Handler. After calling this function, rcvFlag should be checked. When 
  packet reception is completed, the rcvFlag becomes 1, and address & data values
  become available in sigAddr and sigData variables. 
  ==============================================================================
*/ 
#ifndef OTHER_LIB_INC_ASK_DECODER_H_
#define OTHER_LIB_INC_ASK_DECODER_H_

#include "stm8l15x.h"
#include "business_logic.h"
#include "stm8l15x_conf.h"

#define NUMBER_OF_DATA_IGNORE  4
#define FIRST_ACCEPTABLE_PACKET_NUM 1
#define MAX_NUMBER_OF_ADDR_FOR_REMOTE_SAVE 5
#define RF_REG_CLEAR_TIMEOUT 200 //200 * 10ms = 2sec
  

typedef enum
{
	ASK_STAT_PRESSED = 0,
	ASK_STAT_RELEASED = 1,
}ASK_STAT;


typedef struct
{
  unsigned short onTime[27];        // The time signal is on (in us)
  unsigned short period[27];        // The period of signal (in us)
  float duty;                   // The duty cycle of signal (onTime/period) (0~1)   
  unsigned char index;          // The step of recieving signal
  unsigned long sigTot;          // Total recieved signal (Address + Data) (24 bit)
  unsigned short sigAddr;       // The address of recieved signal
  unsigned char sigData;        // The data of recieved signal
  unsigned short pressDuration;		// The duration the key keep pressed (1uint ~ 45ms (depends on transmitter))
  unsigned short numOfReceivedCorrectPacket;   // number of correct packets received which addresses are saved
  unsigned char packetIgnoreCounter;  //count how many packets to be ignored
  unsigned char performRemoteNow;
  unsigned short noiseCnt;
  ASK_STAT status;					// 0: Released / 1: Pressed
  unsigned char rcvFlag;        // 0: recption is ongoing / 1: reception is completed
  // last values
  unsigned char lastIndex;			// The index of last complete reception
  unsigned long lastSigTot;			// The sigTot of last complete reception
  unsigned short lastSigAddr;			// The sigAddr of last complete reception
  unsigned char lastSigData;			// The sigData of last complete reception
  unsigned short lastPressDuration;	// The pressDuration of last complete reception
  // temp values
  unsigned short sigAddrTemp[MAX_NUMBER_OF_ADDR_FOR_REMOTE_SAVE];
  unsigned short rfRegClearTimer;
} ASK_PACKET;



void ASK_StartReception(ASK_PACKET* askPacket);
void ASK_HandleReception(ASK_PACKET* askPacket);
uint8_t ASK_SaveRemote(ASK_PACKET* askPacket);
uint8_t ASK_IsRemoteSaved(ASK_PACKET* askPacket);
void ASK_ReadRemoteAddressesFromEepromToReg(void);
void ASK_ClearRemoteAddresses(void);
uint8_t ASK_Check_To_Perform_Remote_Operations(ASK_PACKET* askPacket);
void ASK_Perform_Remote_Operations(ASK_PACKET* askPacket);
void ASK_Rf_Reg_Clear(ASK_PACKET* askPacket);
#endif /* OTHER_LIB_INC_ASK_DECODER_H_ */