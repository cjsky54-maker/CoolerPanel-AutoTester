#include "functions.h"
//#include <string.h>
#define GENPOLY 0x0013 // x^4 + x + 1



unsigned char convert_int_to_string (int32_t number, char digits[10])
{
	unsigned char length = 1;
	char inverse[10], minus;
	int32_t index = 0, temp, result, i=0;
	if (number >= 0)
	{
		temp = number;
		minus = 0;
	}
	else
	{
		temp = -1 * number;
		minus = 1;
	}
	while (temp > 0)
	{
		result = temp / 10;
		inverse[index] = temp - result * 10;
		index ++;
		temp = result;
	}

	length = index;
	if (index == 0)
	{
		length = 1;
		digits[0] = 48;
		i = 1;
	}
	else
	{
		if(minus == 1)
		{
			digits[0] = 45;
			i = 1;
			length++;
		}
		while(index > 0)
		{
			digits[i] = inverse[index-1]+48;
			i++;
			index--;
		}
	}
	digits[i] = 0;
	return length;
}

unsigned char convert_long_to_string (long long number, char digits[20])
{
	unsigned char length = 1;
	char inverse[20], minus;
	int32_t index = 0, i=0;
	unsigned long long temp, result;
	if (number >= 0)
	{
		temp = number;
		minus = 0;
	}
	else
	{
		temp = -1 * number;
		minus = 1;
	}
	while (temp > 0)
	{
		result = temp / 10;
		inverse[index] = temp - result * 10;
		index ++;
		temp = result;
	}

	length = index;
	if (index == 0)
	{
		length = 1;
		digits[0] = 48;
		i = 1;
	}
	else
	{
		if(minus == 1)
		{
			digits[0] = 45;
			i = 1;
			length++;
		}
		while(index > 0)
		{
			digits[i] = inverse[index-1]+48;
			i++;
			index--;
		}
	}
	digits[i] = 0;
	return length;
}

unsigned char convert_float_to_string (float number, unsigned char digit_num, char digits[15])
{
	int32_t before = 0, pow = 1, temp, after;
	unsigned char length = 0, add_minus = 0;
	signed char i = 0;
	before = (int32_t)number;
	length = convert_int_to_string(before, digits);
	digits[length] = 46;
	length++;
	if(number > -1 && number < 0)
	{
		add_minus = 1;
	}
	if(number < 0)
	{
		number *= -1;
	}
	number -= before;
	for(i=0;i<digit_num;i++)
	{
		temp = (int32_t)(pow * number);
		temp *= 10;
		after = (long int)(number * pow * 10);
		digits[length] = after - temp + 48;
		pow *= 10;
		length ++;
	}
	digits[length] = 0;
	if(add_minus == 1)
	{
		for(i=length;i>=0;i--)
		{
			digits[i+1] = digits[i];
		}
		digits[0] = 45;
		length++;
	}
	return length;
}


unsigned char convert_float_to_string_dotless (float number, unsigned char digit_num, char digits[15])
{
	long int before = 0, pow = 1, temp, after;
	unsigned char length = 0, add_minus = 0;
	signed char i = 0;
	// this if added to return just "0" if the number was 0 and not 000 (if two digits after point is set) (97.10.08)
	if(number == 0)
	{
		digits[0] = '0';
		digits[1] = 0;
		length = 1;
	}
	else
	{
		before = (int32_t)number;
		length = convert_int_to_string(before, digits);
		if(number > -1 && number < 0)
		{
			add_minus = 1;
		}
		if(number < 0)
		{
			number *= -1;
		}
		number -= before;
		for(i=0;i<digit_num;i++)
		{
			temp = (int32_t)(pow * number);
			temp *= 10;
			after = (long int)(number * pow * 10);
			digits[length] = after - temp + 48;
			pow *= 10;
			length ++;
		}
		digits[length] = 0;
		if(add_minus == 1)
		{
			for(i=length;i>=0;i--)
			{
				digits[i+1] = digits[i];
			}
			digits[0] = 45;
			length++;
		}
	}
	return length;
}

unsigned char convert_double_to_string (double number, unsigned char digit_num, char digits[20])
{
	int32_t before = 0, pow = 1, temp, after;
	unsigned char length = 0, add_minus = 0;
	signed char i = 0;
	before = (int32_t)number;
	length = convert_int_to_string(before, digits);
	digits[length] = 46;
	length++;
	if(number > -1 && number < 0)
	{
		add_minus = 1;
	}
	if(number < 0)
	{
		number *= -1;
	}
	number -= before;
	for(i=0;i<digit_num;i++)
	{
		temp = (int32_t)(pow * number);
		temp *= 10;
		after = (long int)(number * pow * 10);
		digits[length] = after - temp + 48;
		pow *= 10;
		length ++;
	}
	digits[length] = 0;
	if(add_minus == 1)
	{
		for(i=length;i>=0;i--)
		{
			digits[i+1] = digits[i];
		}
		digits[0] = 45;
		length++;
	}
	return length;
}

uint32_t convert_string_to_uint(char* string)
{
	unsigned char i;
	uint32_t number = 0;
	for(i=0;i<15;i++)
	{
		if(string[i] > 47 && string[i] < 58)	// 0~9 -> 48~57
		{
			number = number*10 + (string[i]-48);
		}
		else if(string[i] == 0)
		{
			break;
		}
		else
		{
			number = 0;
			break;
		}
	}
	return number;
}

unsigned long long convert_string_to_ulonglong(char* string)
{
	unsigned char i;
	unsigned long long number = 0ULL;
	for(i=0;i<15;i++)
	{
		if(string[i] > 47 && string[i] < 58)	// 0~9 -> 48~57
		{
			number = number*10ULL + (string[i]-48);
		}
		else if(string[i] == 0)
		{
			break;
		}
		else
		{
			number = 0;
			break;
		}
	}
	return number;
}

float convert_string_to_float(char* string)
{
	uint32_t i, mode = 0;	// mode:0 -> before point, mode:1 -> after point
	float number = 0, pow;
	for(i=0;i<15;i++)
	{
		if(mode == 0)
		{
			if(string[i] > 47 && string[i] < 58)	// 0~9 -> 48~57
			{
				number = number*10 + (string[i]-48);
			}
			else if(string[i] == 46)	// point character
			{
				mode = 1;
				pow = 10;
			}
			else if(string[i] == 0)
			{
				break;
			}
			else
			{
				number = 0;
				break;
			}
		}
		else if(mode == 1)
		{
			if(string[i] > 47 && string[i] < 58)	// 0~9 -> 48~57
			{
				number += (float)(string[i]-48)/pow;
				pow *= 10;
			}
			else if(string[i] == 0)
			{
				break;
			}
			else
			{
				number = 0;
				break;
			}
		}
	}
	return number;
}

double convert_string_to_double(char* string)
{
	uint32_t i, mode = 0;	// mode:0 -> before point, mode:1 -> after point
	double number = 0, pow;
	for(i=0;i<15;i++)
	{
		if(mode == 0)
		{
			if(string[i] > 47 && string[i] < 58)	// 0~9 -> 48~57
			{
				number = number*10 + (string[i]-48);
			}
			else if(string[i] == 46)	// point character
			{
				mode = 1;
				pow = 10;
			}
			else if(string[i] == 0)
			{
				break;
			}
			else
			{
				number = 0;
				break;
			}
		}
		else if(mode == 1)
		{
			if(string[i] > 47 && string[i] < 58)	// 0~9 -> 48~57
			{
				number += (float)(string[i]-48)/pow;
				pow *= 10;
			}
			else if(string[i] == 0)
			{
				break;
			}
			else
			{
				number = 0;
				break;
			}
		}
	}
	return number;
}

unsigned short String_Length (char* str)
{
	unsigned short i = 0;
	for(i=0;i<10000;i++)
	{
		if(str[i] == 0)
		{
			break;
		}
	}
	return i;
}

unsigned char String_Compare(char* str_new,char* str_ref)
{
	unsigned short L, i;
	unsigned char match = 1;
	L = String_Length(str_ref);
	for(i=0;i<L;i++)
	{
		if(str_new[i] != str_ref[i])
		{
			match = 0;
			break;
		}
	}
	return match;
}


void Concatenate (char* str_total, char* str_new)
{
	unsigned short L1, L2, i;
	L1 = String_Length(str_total);
	L2 = String_Length(str_new);
	for(i=0;i<L2;i++)
	{
		str_total[L1+i] = str_new[i];
	}
	str_total[L1+L2] = 0;
}

void concatenateInt(char* strTotal, uint32_t number, char* separator)
{
	char string[10];
	convert_int_to_string(number, string);
	Concatenate(strTotal, string);
	Concatenate(strTotal, separator);
}

void concatenateLong(char* strTotal, unsigned long long number, char* separator)
{
	char string[20];
	convert_long_to_string(number, string);
	Concatenate(strTotal, string);
	Concatenate(strTotal, separator);
}

void concatenateFloatDotless(char* strTotal, float number, unsigned char digitNum, char * separator)
{
	char string[15];
	convert_float_to_string_dotless(number, digitNum, string);
	Concatenate(strTotal, string);
	Concatenate(strTotal, separator);
}

void concatenateFloat(char* strTotal, float number, unsigned char digitNum, char * separator)
{
	char string[15];
	convert_float_to_string(number, digitNum, string);
	Concatenate(strTotal, string);
	Concatenate(strTotal, separator);
}

void concatenateDouble(char* strTotal, double number, unsigned char digitNum, char * separator)
{
	char string[20];
	convert_double_to_string(number, digitNum, string);
	Concatenate(strTotal, string);
	Concatenate(strTotal, separator);
}


unsigned char string_equal(char* str1, char* str2)
{
	int i=0, counter=0;
	if(String_Length(str1) == String_Length(str2)){
		for(i=0;i<String_Length(str1);i++){
			if(str1[i] == str2[i])
			{
				counter++;
			}
		}
	}
	if(counter == String_Length(str1))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}


void String_Copy(char* string1 , char* string2)	//Copy String 2 in String 1
{
	int i=0;
	for(i=0;i<String_Length(string1);i++)
	{
		string1[i]=0;
	}
	for(i=0;i<String_Length(string2);i++)
	{
		string1[i]=string2[i];
	}
}


void Set_Bits(unsigned short* number, unsigned short bits)
{
	unsigned short temp;
	temp = *number;
	temp |= bits;
	*number = temp;
}

void Reset_Bits(unsigned short* number, unsigned short bits)
{
	unsigned short temp;
	temp = *number;
	temp &= ~bits;
	*number = temp;
}

uint32_t merge2ShortToInt(unsigned short LSW , unsigned short MSW)
{
	uint32_t merged;
	merged = (uint32_t)MSW << 16;
	merged += LSW;
	return merged;
}

unsigned char uintGetBit(uint32_t number, unsigned char position)
{
	unsigned char uctemp;
	uint32_t uitemp;
	if(position < 32)
	{
		uitemp = number >> position;
		uctemp = (unsigned char) uitemp & 1;
	}
	else
	{
		uctemp = 2;		// if position is out of range
	}
	return uctemp;
}

void uintSetBit(uint32_t *number, unsigned char position)
{
	uint32_t uitemp = 0;
	uitemp = 1 << position;
	*number = *number | uitemp;
}

void uintResetBit(uint32_t *number, unsigned char position)
{
	uint32_t uitemp = 0;
	uitemp = 1 << position;
	uitemp = ~uitemp;
	*number = *number & uitemp;
}
        
void ushortSetBit(uint16_t *number, unsigned short position)
{
	*number = *number | position;
}

void ushortResetBit(uint16_t *number, unsigned short position)
{
	position = ~position;
	*number = *number & position;
}

int32_t Pow(int32_t a, int32_t b)
{
	if(b == 0){
		return 1;
	}
	int32_t i=0,temp;
	temp=a;
	for(i=0;i<b-1;i++)
	{
		a=a*temp;
	}
	temp = a;

	return temp;
}
float powFloat(float a, int32_t b)
{
	if(b == 0){
		return 1;
	}
	int32_t i=0;
	float temp;
	temp=a;
	for(i=0;i<b-1;i++)
	{
		a=a*temp;
	}
	temp = a;

	return temp;
}

float absF(float number)
{
	float output;
	output = number;
	if(output < 0)
	{
		output *= -1;
	}
	return output;
}

uint32_t makecrc4(uint32_t b)
/*
 * Takes b as input, which should be the information vector
 * already multiplied by x^4 (ie. shifted over 4 bits), and
 * returns the crc for this input based on the defined generator
 * polynomial GENPOLY
 */
{
	int i;

	i=0;
	while (b>=16) { /* >= 2^4, so degree(b) >= degree(genpoly) */
		if (getbitint(b,i) == 1)
			b ^= GENPOLY << (28-i); /* reduce with GENPOLY */
		i++;
	}
	return b;
}


uint32_t getbitint(uint32_t b, int32_t n)
{
	return (b >> (32-n)) & 1;
}

void decToBin(uint32_t number, char* binStr)
{
	int i = 0;
	binStr[0] = 0;
	unsigned char bin[32];
	if(number == 0)
	{
		binStr[0] = '0';
		binStr[1] = 0;
		return;
	}
	for(i=0;number>0;i++)
	{
		bin[i]=number%2;
		number=number/2;
	}
	for(i=i-1;i>=0;i--)
	{
		concatenateInt(binStr, bin[i],"");
		if(i%4 == 0)
		{
			Concatenate(binStr, " ");
		}
	}
}


unsigned char lowByte(unsigned short num)
{
	unsigned short low;
	low = num & 0xFF;
	return (unsigned char) low;
}

unsigned char highByte(unsigned short num)
{
	unsigned short high;
	high = num & 0xFF00;
	high >>= 8;
	return (unsigned char) high;
}

unsigned short lowHalfWord(uint32_t num)
{
	uint32_t low;
	low = num & 0xFFFF;
	return (unsigned short) low;
}

unsigned short highHalfWord(uint32_t num)
{
	uint32_t high;
	high = num & 0xFFFF0000;
	high >>= 16;
	return (unsigned short) high;
}

unsigned short halfWord(unsigned char* data, unsigned char start, BYTE_ORDER order)
{
	if(order == LSB_FIRST)
	{
		return data[start] + (data[start+1] << 8);
	}
	else if(order == MSB_FIRST)
	{
		return data[start+1] + (data[start] << 8);
	}
	return 0;
}

uint32_t word(unsigned char *byte_array, unsigned char first_index, unsigned char order)
{
	unsigned char i;
	uint32_t word = 0;
	if (order == LSB_FIRST)
	{
		for(i=3;i>0;i--)
		{
			word += byte_array[first_index+i];
			word <<= 8;
		}
		word += byte_array[first_index];
	}
	else if (order == MSB_FIRST)
	{
		for(i=0;i<3;i++)
		{
			word += byte_array[first_index+i];
			word <<= 8;
		}
		word += byte_array[first_index+3];
	}

	return word;
}
unsigned char Get_Ones(unsigned short val)
{
  return val%10;
}

unsigned char Get_Hundreds(unsigned short val)
{
  return (val/100)%10;
}
unsigned char Get_Tens(unsigned short val)
{
  return (val/10)%10;
}

unsigned char Get_Fraction(float val)
{
  unsigned short valFloor = (unsigned short)(val*10);
  if( ((unsigned short)(val*100)%10 >= 5) && ((unsigned char)(valFloor%10) < 9) )
    return (unsigned char)(valFloor%10) + 1;
  else
    return (unsigned char)(valFloor%10);
}
