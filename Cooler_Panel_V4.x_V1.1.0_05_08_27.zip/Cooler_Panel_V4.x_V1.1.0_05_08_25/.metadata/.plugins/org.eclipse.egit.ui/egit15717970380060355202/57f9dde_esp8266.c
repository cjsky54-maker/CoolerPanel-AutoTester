#include "esp8266.h"
#include "variables.h"
#include "initialization.h"
#include "stm8l15x_conf.h"
#include "functions.h"
#include "stdio.h"
#include "string.h"

#define WIFI_USART 2
#define HTML_BUFFER_SIZE 2048

extern WIFI_STATUS wfStatus;
//extern App_State appState;
///////////////// HEADER HTML /////////////////
const unsigned char wifiHeaderHtml[] =// "<html>\r\n<head>\r\n  <style>\r\n    body {\r\n      display: flex;\r\n      justify-content: center;\r\n      align-items: flex-start;\r\n      height: 100vh;\r\n      margin: 0;\r\n      font-family: Arial, sans-serif;\r\n    }\r\n    .container {\r\n      text-align: center;\r\n      border: 1px solid #ccc;\r\n      padding: 20px;\r\n      border-radius: 10px;\r\n      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\r\n      margin-top: 150px;\r\n    }\r\n  </style>\r\n</head>\r\n<body>\r\n  <div class=\"container\">\r\n    <h2>Wi-Fi Configuration</h2>\r\n    <form action=\"/wifi_config\" method=\"get\">\r\n      SSID: \r\n      <select name=\"ssid\">\r\n        %s\r\n      </select><br><br>\r\n      Password: <input type=\"text\" name=\"pass\"><br><br>\r\n      <input type=\"submit\" value=\"connect\">\r\n    </form>\r\n  </div>\r\n</body>\r\n</html>";

"<html>"
"<head>"
"  <style>"
"    body {"
"      display: flex;"
"      justify-content: center;"
"      align-items: flex-start;"
"      height: 100vh;"
"      margin: 0;"
"      font-family: Arial, sans-serif;"
"    }"
"    .container {"
"      text-align: center;"
"      border: 1px solid #ccc;"
"      padding: 20px 20px 1px 20px;"
"      border-radius: 10px;"
"      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);"
"      margin-top: 150px;"
"    }"
"    .not-connected {"
"      margin-top: 30px;"
"      margin-bottom: 1px;"
"    }"
"    .button-group {"
"      display: flex;"
"      justify-content: center;"
"      gap: 10px;"
"      margin-top: 10px;"
"    }"
"  </style>"
"</head>"
"<body>"
"  <div class=\"container\">"
"    <h2>Wi-Fi Configuration</h2>"
"    <form action=\"/wifi_config\" method=\"get\">"
"      SSID: "
"      <select name=\"ssid\">";
///////////////////////////////////////////////

///////////////// FOOTER HTML /////////////////
const unsigned char wifiFooter_1_Html[] =
//        "        <option value=\"sepehranmotor1\">sepehranmotor1</option>\r\n"
//        "        <option value=\"PakranCoExt\">PakranCoExt</option>\r\n"
"      </select><br><br>"
"      Password: <input type=\"text\" name=\"pass\"><br><br>"
//"      <input type=\"submit\" value=\"connect\">\r\n";
"      <div class=\"button-group\">"
"        <input type=\"submit\" value=\"Connect\">"
"        <input type=\"submit\" value=\"Disconnect\" formaction=\"/wifi_disconnect\">"
"      </div>";
//"      <p class=\"not-connected\">not connected</p><br>\r\n"
const unsigned char wifiFooter_2_Html[] =
"    </form>"
"  </div>"
"</body>"
"</html>";
///////////////////////////////////////////////

const unsigned char wifiConnectionResponseHeaderHtml[] = 
"<html>"
"<head>"
"  <style>"
"    body {"
"      display: flex;"
"      justify-content: center;"
"      align-items: flex-start;"
"      height: 100vh;"
"      margin: 0;"
"      font-family: Arial, sans-serif;"
"    }"
"    .container {"
"      text-align: center;"
"      border: 1px solid #ccc;"
"      padding: 20px;"
"      border-radius: 10px;"
"      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);"
"      margin-top: 150px;"
"    }"
"  </style>"
"</head>"
"<body>"
"  <div class=\"container\">"
"    <h2>Wi-Fi Configuration</h2>";

const unsigned char wifiConnectionResponseFooterHtml[] = 
//"    <p>Connected</p>\r\n"
"  </div>"
"</body>"
"</html>";



//**
//  * @brief  Returns Reception complete flag
//  * @param  wfStatus: received response
//  * @retval None
//  */
//unsigned char recieveWifiAtResponse(WIFI_STATUS* wfStatus)
//{
//  unsigned char receptionComplete = 0;
//  if(wfStatus->mode == 0)
//  {
//          
//          if(wfStatus->rxBuffer[wfStatus->index-2] == 'O' && wfStatus->rxBuffer[wfStatus->index-1] == 'K' && wfStatus->rxBuffer[wfStatus->index] == '\r' && wfStatus->index != 0)
//              wfStatus->mode = 1;
//          wfStatus->index++;
//          if(wfStatus->index > 750)
//          {
//              wfStatus->mode = 0;
//              wfStatus->index = 0;
//              wfStatus->sendingAtCmd = 0;
//          }
//  }
//  else if(wfStatus->mode == 1)
//  {
//          if(wfStatus->rxBuffer[wfStatus->index] == '\n')
//          {
//              wfStatus->index ++;
//              wfStatus->rxBuffer[wfStatus->index] = 0;
//              wfStatus->length = wfStatus->index;
//              receptionComplete = 1;
//          }
//          wfStatus->mode = 0;
//          wfStatus->index = 0;
//          wfStatus->sendingAtCmd = 0;
//  }
//  return receptionComplete;
//}

void EspPower(unsigned char state)
{
  if(state == ON)
    GPIOD->ODR |= 0x80;
  else
    GPIOD->ODR &= 0x7F;
}


void Wifi_Config()
{
  EspPower(ON);
  //ToDo: wfStatus dar inja tarif shavad?
  delay_ms(100);
//  WIFI_Send_3(&wfStatus, AT_TEST, "", 0, 1);
//  delay_ms(100);
//  WIFI_Send_3(&wfStatus, CHECK_SLEEP_MODE,"", 0, 1);
//  delay_ms(100);
//  WIFI_Send_3(&wfStatus, SET_SLEEP_MODE,"0", 0, 1);
//  delay_ms(100);
//  USART2_Config(19200);
//  WIFI_Send_3(&wfStatus, SET_UART_CONFIG,"230400,8,1,0,1",1000, 1);
//  if(wfStatus.receptionStatus == RECEPTION_OK)
  WIFI_Send_3(&wfStatus, AT_TEST,"",1000, 2);
//  WIFI_Send_3(&wfStatus, AT_CWLAP_CONFIG,"1,2",5000, 1);
//  WIFI_Send_3(&wfStatus, LIST_AVAILABLE_APS,"",6000, 1);
//  WIFI_Send_3(&wfStatus, WF_RESET_CMD,"",5000, 1);
  if(wfStatus.receptionStatus == RECEPTION_OK)
  {
//    delay_ms(100);
//    WIFI_Send_3(&wfStatus, CHECK_UART_CONFIG,"",2000, 1);
//    if(wfStatus.receptionStatus == RECEPTION_OK);
      delay_ms(100);
      WIFI_Send_3(&wfStatus, WF_RESET_CMD,"",2000, 2);
//  if(wfStatus.receptionStatus == RECEPTION_READY);
//  while(wfStatus.receptionStatus != RECEPTION_READY)
//  {}
//      if(0)
    if(wfStatus.receptionStatus == RECEPTION_READY);
    {
//      while(wfStatus.receptionStatus != RECEPTION_OK)
//      {}
//        delay_ms(100);
//        WIFI_Send_3(&wfStatus, AT_WF_GET_VERSION,"",5000, 2);
//        if(wfStatus.receptionStatus == RECEPTION_OK)
//      while(wfStatus.receptionStatus != RECEPTION_OK)
//      {}
      WIFI_Send_3(&wfStatus, AT_ECHO, "0", 1000, 2);
      if(wfStatus.receptionStatus == RECEPTION_OK);
      {
        delay_ms(100);
        
        WIFI_Send_3(&wfStatus, CHECK_WIFI_MODE, "", 1000, 2);
        if(wfStatus.EspMode != 3)
          WIFI_Send_3(&wfStatus, SET_WIFI_MODE, "3", 1000, 2);
          
        if(wfStatus.receptionStatus == RECEPTION_OK);
        {
         delay_ms(100);
         
         WIFI_Send_3(&wfStatus, CHECK_SOFTAP_MODE_CONFIG, "", 1000, 2);
         if(wfStatus.EspNamePassConfiged != 1)
           WIFI_Send_3(&wfStatus, SET_SOFTAP_MODE_CONFIG, "\"pakran_cooler\",\"12345678\",5,3", 4000, 2);
         
         if(wfStatus.receptionStatus == RECEPTION_OK)
         {
           delay_ms(100);
           WIFI_Send_3(&wfStatus, SET_MULTIPLE_CONNECTION,"1",2000, 2);
           if(wfStatus.receptionStatus == RECEPTION_OK)
            {
              delay_ms(100);
              WIFI_Send_3(&wfStatus, TCP_SERVER,"1,80",3000, 3);
  //            if(wfStatus.receptionStatus == RECEPTION_OK)
  //            {
  //              delay_ms(100);
  //              WIFI_Send_3(&wfStatus, AT_CWLAP_CONFIG,"1,2",5000 ,2);
  //              if(wfStatus.receptionStatus == RECEPTION_OK)
  //              {
  //                delay_ms(100);
  //                WIFI_Send_3(&wfStatus, LIST_AVAILABLE_APS,"",6000 ,2);
  //              }
  //            }
            }
          }
        }
      }
    }
  }
}


void WIFI_Recieve(WIFI_STATUS* wfStatus)
{
  if(wfStatus->mode == 0)
  {
    //a line except last line is recieved
    if(wfStatus->apiRxBuffer[wfStatus->apiRow][wfStatus->apiCol] == '\r')
    {
      wfStatus->mode = 1;
    }
    
    if((wfStatus->apiRxBuffer[wfStatus->apiRow][wfStatus->apiCol-1] == '>') &&
       (wfStatus->apiRxBuffer[wfStatus->apiRow][wfStatus->apiCol]   == ' '))
    {
      wfStatus->receivedRow = wfStatus->apiRow;
      wfStatus->length[wfStatus->receivedRow] = wfStatus->apiCol+1;
      wfStatus->apiRow = !wfStatus->apiRow;
      wfStatus->apiCol = 0;
      wfStatus->apiReceived = 1;
      wfStatus->mode = 0;
    }
    else
      wfStatus->apiCol++;
  }
  else if(wfStatus->mode == 1)
  {
    if(wfStatus->apiRxBuffer[wfStatus->apiRow][wfStatus->apiCol] == '\n')
    {
      wfStatus->receivedRow = wfStatus->apiRow;
      wfStatus->length[wfStatus->receivedRow] = wfStatus->apiCol+1;
      wfStatus->apiRow = !wfStatus->apiRow;
      wfStatus->apiCol = 0;
      wfStatus->apiReceived = 1;
      wfStatus->mode = 0;
      
      if(!wfStatus->sendingAtCmd)
        {
          wfStatus->receptionComplete = 1;
          wfStatus->receptionStatus = RECEPTION_NON_AT_CMD_RESPONSE;
          WIFI_Extract_Packet(wfStatus);
        }
    }
  }
}


void WIFI_Extract_Packet(WIFI_STATUS* wfStatus)
{
  
  if(wfStatus->sendingAtCmd == 1)  // AT_CMD_RESPONSE //
  {
    //////////////////////////////      AT_CWLAP_CONFIG      //////////////////////////////
    if(!strcmp(wfStatus->atCommand, AT_CWLAP_CONFIG))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    LIST_AVAILABLE_APIS    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, LIST_AVAILABLE_APS))
      {
  //      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "+CWLAP:") != NULL /*&& strstr(wfStatus->apiRxBuffer[!wfStatus->apiRow], "\"\"") == NULL*/)
          if((wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '+') &&
             (wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'C') &&
             (wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'W') &&
             (wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'L') &&
             (wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == 'A') &&
             (wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'P'))
          {
            char* ssidStart;
            char* ssidStop;
            char ssidLength;
            
            ssidStart = strchr(wfStatus->apiRxBuffer[wfStatus->receivedRow],'"');
            if(ssidStart != NULL)
            {
              ssidStart++;
              ssidStop = strchr(ssidStart,'"') - 1;              
              ssidLength = (ssidStop - ssidStart) + 1;
              if(ssidLength > MAX_API_LENGTH)
                ssidLength = MAX_API_LENGTH ;
              if(ssidLength != 0)
              {
                snprintf(wfStatus->ssids[wfStatus->extractMode],sizeof(wfStatus->ssids[wfStatus->extractMode]),"%.*s", ssidLength, (const char*)ssidStart);
                wfStatus->extractMode ++;
              }
            }
          }
        else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
        {
          wfStatus->receptionComplete = 1;
          wfStatus->receptionStatus = RECEPTION_OK;
          wfStatus->extractMode = 0;
        }
      }
    //////////////////////////////    AT_TEST    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, AT_TEST))
      {
        if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
        {
          wfStatus->receptionComplete = 1;
          wfStatus->receptionStatus = RECEPTION_OK;
        }
      }
    //////////////////////////////    WF_RESET_CMD    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, WF_RESET_CMD))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "ready") != NULL)
      {
        wfStatus->receptionStatus = RECEPTION_READY;
        wfStatus->receptionComplete = 1;
      }
    }
    //////////////////////////////    WF_ECHO_CMD    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, AT_ECHO))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionStatus = RECEPTION_OK;
        wfStatus->receptionComplete = 1;
      }
    }
    //////////////////////////////    SET_WIFI_MODE    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, SET_WIFI_MODE))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->EspMode = wfStatus->txBuffer[14] - 48;
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    CHECK_WIFI_MODE    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, CHECK_WIFI_MODE))
    {
      if(/*wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '+' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'C' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'W' &&*/
         wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'M' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == 'O' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'D' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'E')
      wfStatus->EspMode = wfStatus->apiRxBuffer[wfStatus->receivedRow][12] - 48; //char to decimal (-48)
      else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'O' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'K')
      {
        wfStatus->receptionStatus = RECEPTION_OK;
        wfStatus->receptionComplete = 1;
      }
    }
    //////////////////////////////    AT_WF_GET_VERSION    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, AT_WF_GET_VERSION))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    SET_SOFTAP_MODE_CONFIG    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, SET_SOFTAP_MODE_CONFIG))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->EspNamePassConfiged = 1;
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    CHECK_SOFTAP_MODE_CONFIG    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, CHECK_SOFTAP_MODE_CONFIG))
    {
      if(wfStatus->apiRxBuffer[wfStatus->receivedRow][12] == 'p' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][13] == 'a' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][14] == 'k' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][15] == 'r' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][16] == 'n')
      wfStatus->EspNamePassConfiged = 1;
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    SET_MULTIPLE_CONNECTION    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, SET_MULTIPLE_CONNECTION))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////  CHECK_MULTIPLE_CONNECTION  //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, CHECK_MULTIPLE_CONNECTION))
    {
      if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '+' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'C' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'I' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'P' )
      {
        wfStatus->cipMux = wfStatus->apiRxBuffer[wfStatus->receivedRow][8];
      }
      else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'O' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'K' )
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
      
    }
    //////////////////////////////         TCP_SERVER         //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, TCP_SERVER))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////      STOP_TCP_SERVER      //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, STOP_TCP_SERVER))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    SET_DATA_SEND_CONFIG    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, SET_DATA_SEND_CONFIG))
      {
  //      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "> ") != NULL)
        if((wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '>') &&
           (wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == ' ') )
        {
          wfStatus->receptionComplete = 1;
          wfStatus->receptionStatus = RECEPTION_OK;
        }
  //      else if((wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'b') &&
  //              (wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'u') &&
  //              (wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 's') &&
  //              (wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'y'))
  //      {
  //        wfStatus->receptionComplete = 1;
  //        wfStatus->receptionStatus = RECEPTION_BUSY;
  //      }
      }
    //////////////////////////////         SEND_DATA         //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, SEND_DATA))
    {
  //    if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "SEND OK") != NULL)
      if((wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'S') &&
         (wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'E') &&
         (wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'N') &&
         (wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'D') &&
         (wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == ' ') &&
         (wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'O') &&
         (wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'K') )
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK; 
      }
    }
    //////////////////////////////      STOP_TCP_SERVER      //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, STOP_TCP_SERVER))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////          CIP_START          //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, CIP_START))
    {
      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////    CHECK_CONNECTED_WIFI    //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, CHECK_CONNECTED_WIFI))
    {
      if(wfStatus->apiRxBuffer[!wfStatus->receivedRow][0] == 'N' &&
         wfStatus->apiRxBuffer[!wfStatus->receivedRow][1] == 'o' /*&&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == ' ' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'A' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == 'P' 
         strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "No AP") != NULL*/)
      {
        wfStatus->wificonnectionstatus = DISCONNECTED;
      }
      else if(wfStatus->apiRxBuffer[!wfStatus->receivedRow][0] == '+' &&
              wfStatus->apiRxBuffer[!wfStatus->receivedRow][1] == 'C' &&
              wfStatus->apiRxBuffer[!wfStatus->receivedRow][2] == 'W' &&
              wfStatus->apiRxBuffer[!wfStatus->receivedRow][3] == 'J' /*&&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == 'A' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'P' 
              strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "+CWJAP") != NULL*/)
      {
        wfStatus->wificonnectionstatus = CONNECTED;
        //// getting the SSID which esp8266 is connected to
        char* ssidStart; 
        char* ssidStop;
        char ssidLength;
        ssidStart = strchr(wfStatus->apiRxBuffer[!wfStatus->receivedRow], '"');
        if(ssidStart != NULL)
        {
          ssidStart++;
          ssidStop = strchr(ssidStart,'"') - 1;              
          ssidLength = (ssidStop - ssidStart) + 1;
          if(ssidLength > MAX_API_LENGTH)
            ssidLength = MAX_API_LENGTH ;
          snprintf(wfStatus->connectedSsid,sizeof(wfStatus->connectedSsid),"%.*s", ssidLength, (const char*)ssidStart);
        }
      }
        
      else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'O' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'K' )
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
      }
    }
    //////////////////////////////      CONNECT_TO_WIFI      //////////////////////////////
    else if(!strcmp(wfStatus->atCommand, CONNECT_TO_WIFI))
    {
      
      if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'O' &&
         wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'K')
  //    else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "OK") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_OK;
        wfStatus->wificonnectionstatus = CONNECTED;
      }
         
      else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'F' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'A' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'I' &&
              wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'L')
  //    else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "FAIL") != NULL)
      {
        wfStatus->receptionComplete = 1;
        wfStatus->receptionStatus = RECEPTION_FAIL;
         wfStatus->wificonnectionstatus = DISCONNECTED;
      }
      
    }
    ///////////////////////////////   DISCONNECT_FROM_WIFI   ///////////////////////////////
    else if(!strcmp(wfStatus->atCommand, DISCONNECT_FROM_WIFI))
      {
        if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'O' &&
           wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'K')
        {
          wfStatus->receptionComplete = 1;
          wfStatus->receptionStatus = RECEPTION_OK;
          wfStatus->wificonnectionstatus = DISCONNECTED;
        }
        else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'F' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'A' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'I' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'L')
        {
          wfStatus->receptionComplete = 1;
          wfStatus->receptionStatus = RECEPTION_FAIL;
        }
      }
  }
  //////////////////////////////    NON_AT_CMD_RESPONSE    //////////////////////////////
  else
  {
    if((wfStatus->receptionStatus == RECEPTION_NON_AT_CMD_RESPONSE))
      {
//        if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '+'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'S'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'T'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'A'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == '_'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'C'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'O'  &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][7] == 'N' &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][8] == 'N' &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][9] == 'E' &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][10] == 'C' &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][11] == 'T' &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][12] == 'E' &&
//           wfStatus->apiRxBuffer[wfStatus->receivedRow][13] == 'D' )
//        {
//          wfStatus->targetconnectionStatus = CONNECTED;
//          Buzzer_Play(20);
//        }
//        else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '+'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'S'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'T'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'A'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == '_'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'D'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'I'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][7] == 'S'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][8] == 'C'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][9] == 'O'  &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][10] == 'N' &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][11] == 'N' &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][12] == 'E' &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][13] == 'C' &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][14] == 'T' &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][15] == 'E' &&
//                wfStatus->apiRxBuffer[wfStatus->receivedRow][16] == 'D' )
//        {
//          wfStatus->targetconnectionStatus = DISCONNECTED;
//          Buzzer_Play(20);
//          delay_ms(20);
//          Buzzer_Play(20);
//        }
          
  //      else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow], "+IDP") != NULL)
  //      else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 9] == 'C'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 8] == 'O'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 7] == 'N'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 6] == 'N'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 5] == 'E'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 4] == 'C'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 3] == 'T'  &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 2] == '\r' &&
  //              wfStatus->apiRxBuffer[wfStatus->receivedRow][wfStatus->length[wfStatus->receivedRow] - 1] == '\n' )
        if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == '+'  &&
           wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'I'  &&
           wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'P'  &&
           wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'D'  &&
           wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == ',')
        {
          char* start = strchr(wfStatus->apiRxBuffer[wfStatus->receivedRow], '/');
          
          if(start[2] == 'H' && start[3] == 'T' && start[4] == 'T' && start[5] == 'P')
          {
            wfStatus->targetRequestsHtml = 1;
            wfStatus->targetConnectionId = wfStatus->apiRxBuffer[wfStatus->receivedRow][5];
          }
          else if (start[1] == 'w' && start[2] == 'i' && start[3] == 'f' && start[4] == 'i')
          {
            if(start[6] == 'c' && start[7] == 'o'&& start[8] == 'n')
            {
              wfStatus->targetConnectionId = wfStatus->apiRxBuffer[wfStatus->receivedRow][5];
              wfStatus->targetRequestsConfig = 1;
              
              char* start;
              char* stop;
              char length;
              
              //parsing selected SSID
              start = strchr(wfStatus->apiRxBuffer[wfStatus->receivedRow], '=');
              if(start != NULL)
              {
                start ++;
                stop = strchr(start, '&') - 1;
                length = stop - start + 1;
                
                snprintf(wfStatus->selectedSsid, sizeof(wfStatus->selectedSsid), "%.*s", length, (const char*)start);
              }
              
              //parsing password
              start = strchr(stop, '=');
              if(start != NULL)
              {
                start ++;
                stop = strrchr(start, 'H') - 2;
                length = stop - start + 1;
                
                snprintf(wfStatus->receivedPassword, sizeof(wfStatus->receivedPassword), "%.*s", length, (const char*)start);
              }
            }
            else if(start[6] == 'd' && start[7] == 'i'&& start[8] == 's')
            {
               wfStatus->targetConnectionId = wfStatus->apiRxBuffer[wfStatus->receivedRow][5];
              wfStatus->targetRequestsDisconnect = 1;
            }
          }

        }
        
        else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'C'  &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'L'  &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == 'O'  &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'S'  &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'E'  &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][7] == 'D'  &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][8] == '\r' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][9] == '\n' )
        {
          wfStatus->targetRequestsHtml = 0;
        }
        else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'W' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'I' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'F' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'I' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == ' ' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'D' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'I' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][7] == 'S' /*&&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][8] == 'C' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][9] == 'O' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][10] == 'N' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][11] == 'N' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][12] == 'E' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][13] == 'C' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][14] == 'T' */)
        {
          wfStatus->wificonnectionstatus = DISCONNECTED;
        }
        else if(wfStatus->apiRxBuffer[wfStatus->receivedRow][0] == 'W' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][1] == 'I' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][2] == 'F' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][3] == 'I' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][4] == ' ' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][5] == 'C' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][6] == 'O' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][7] == 'N' /*&&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][8] == 'N' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][9] == 'E' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][10] == 'C' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][11] == 'T' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][12] == 'E' &&
                wfStatus->apiRxBuffer[wfStatus->receivedRow][13] == 'D' */)
        {
          wfStatus->wificonnectionstatus = CONNECTED;
        }
  //      if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow],"+STA_CONNECTED:") != NULL)
  //      {
  //        wfStatus->targetconnectionStatus = CONNECTED;
  //      }
  //      else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow],"+STA_DISCONNECTED:") != NULL)
  //      {
  //        wfStatus->targetconnectionStatus = DISCONNECTED;
  //      }
  //      else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow],"CONNECT\r\n") != NULL)
  //      {
  //        wfStatus->targetRequestsHtml = 1;
  ////        Buzzer_Play(20); 
  //      }
  //      else if(strstr(wfStatus->apiRxBuffer[wfStatus->receivedRow],"CLOSED\r\n") != NULL)
  //      {
  //        wfStatus->targetRequestsHtml = 0;
  ////        Buzzer_Play(20);
  //      }
      }
  }
}

void WIFI_Send_2(WIFI_STATUS* wfStatus)
{
  Concatenate(wfStatus->txBuffer, "AT");
  if(!string_equal(wfStatus->atCommand, AT_TEST))
  {
    if(!string_equal(wfStatus->atCommand , AT_ECHO))
      Concatenate(wfStatus->txBuffer, "+");
    Concatenate(wfStatus->txBuffer, wfStatus->atCommand);
    if(!string_equal(wfStatus->data , "") && !string_equal(wfStatus->atCommand , AT_ECHO))
      Concatenate(wfStatus->txBuffer,"=");
    Concatenate(wfStatus->txBuffer, wfStatus->data);
  }
  Concatenate(wfStatus->txBuffer, "\r\n");	//\r(13) \n(10)
  
  UART_Send(WIFI_USART, wfStatus->txBuffer, String_Length(wfStatus->txBuffer));
}


void WIFI_Send_3(WIFI_STATUS* wfStatus, char* command, char* data, unsigned int timeout, unsigned char retryCnt)
{
  uint8_t attempts = retryCnt;
  while(attempts)
  {
    unsigned long int counter;
    counter = (unsigned long int)timeout * 415;

    wfStatus->atCommand[0] = 0;
    wfStatus->data[0] = 0;
    
    strcpy(wfStatus->atCommand, command);
    if(!string_equal(wfStatus->atCommand, SEND_DATA))
      strcpy(wfStatus->data, data);
    Clear_ApiRxBuffer(wfStatus);
    wfStatus->txBuffer[0] = 0;
    Clear_lengthBuffer(wfStatus);
    wfStatus->resetMode = 0;
    wfStatus->mode = 0;
    wfStatus->extractMode = 0;
    wfStatus->apiCol = 0;
    wfStatus->apiRow = 0;
    wfStatus->receivedRow = 0;
    wfStatus->receptionComplete = 0;
    wfStatus->receptionStatus = RECEPTION_NONE;
    wfStatus->sendingAtCmd = 1;
    
    if(string_equal(wfStatus->atCommand, SEND_DATA))
      UART_Send(WIFI_USART, (const char*)data, strlen((const char*)data));
    else
      WIFI_Send_2(wfStatus);
    
    while(wfStatus->receptionStatus == RECEPTION_NONE && counter != 0)
    {
      counter --;
      if(wfStatus->apiReceived)
      {
        wfStatus->apiReceived = 0;
        WIFI_Extract_Packet(wfStatus);
      }
      if(counter == 0)
        wfStatus->receptionStatus = RECEPTION_TIMEOUT;
    }
    if(wfStatus->receptionStatus != RECEPTION_TIMEOUT)
      break;
    else
      attempts --;
  }
    wfStatus->sendingAtCmd = 0;
}

////////////////// for Api Rx buffer //////////////////
void Clear_ApiRxBuffer(WIFI_STATUS* wfStatus)
{
//  for(char i = 0 ; i < NUMBER_OF_COLUMNS ; i++)
  {
//    wfStatus->apiRxBuffer[0][i] = 0;
//    wfStatus->apiRxBuffer[1][i] = 0;
    memset(wfStatus->apiRxBuffer[0], 0, NUMBER_OF_COLUMNS);
    memset(wfStatus->apiRxBuffer[1], 0, NUMBER_OF_COLUMNS);
  }
}
///////////////////////////////////////////////////////


//////////////////   for Rx buffer   //////////////////
//void Clear_Row(WIFI_STATUS* wfStatus, char rowsNumber)
//{
//  for(char i = 0 ; i < NUMBER_OF_COLUMNS ; i++)
//  {
//    wfStatus->rxBuffer[rowsNumber][i] = 0;
//  }
//}
//
//void Clear_RxBuffer(WIFI_STATUS* wfStatus)
//{
//  for(char i = 0 ; i < NUMBER_OF_ROWS ; i++)
//  {
//    Clear_Row(wfStatus, i);
//  }
//}
///////////////////////////////////////////////////////
void Clear_lengthBuffer(WIFI_STATUS* wfStatus)
{
  for(char i = 0 ; i < NUMBER_OF_ROWS ; i++)
  {
    wfStatus->length[i]=0;
  }
}


// Function to make SSID_OPTION and to send to esp8266
void sendSsidOption(WIFI_STATUS* wfStatus) 
{
    // Buffer to hold the new option string
    char option[60] = {0};

    // Creating the new option string and sending it
    for(char i=0 ; i < MAX_NUMBER_OF_APIS ; i++)
    {
      if(!ssidIsRepetitive(wfStatus, i))
      {
        if(wfStatus->ssids[i][0] != 0)
        {
          snprintf(option, sizeof(option), "<option>%s</option>\r\n" , wfStatus->ssids[i]);
          WIFI_Send_Html_Content(wfStatus, (const unsigned char*)option);
//          sprintf(buffer,"%c,%d",wfStatus->targetConnectionId,strlen((const char*) option));
//          WIFI_Send_3(wfStatus, SET_DATA_SEND_CONFIG,buffer,500, 4);
//          if(wfStatus->receptionStatus == RECEPTION_OK)
//            WIFI_Send_3(wfStatus, SEND_DATA, option, 700, 3);
          
          memset(wfStatus->ssids[i], 0, 32);
          memset(option, 0 ,60);
        }
        else
          break;
      }
    }
}

char ssidIsRepetitive(WIFI_STATUS* wfStatus, char currentSsid)
{
  for(char h = currentSsid + 1 ; h < MAX_NUMBER_OF_APIS ; h++)
  {
    if(string_equal((char*)wfStatus->ssids[currentSsid], (char*)wfStatus->ssids[h]))
    {
      memset(wfStatus->ssids[currentSsid], 0, 32);
      return 1;
    }
  }
  return 0;
}

void Decode_Received_Html_Ssid_Password(WIFI_STATUS* wfStatus)
{
  char Decoded_content[MAX_API_LENGTH]={0};
  char len = (char)strlen((const char*)wfStatus->receivedPassword);
  char a = 0,b = 0;
  
  //// decoding password
  while(a < len)
  {
    if(wfStatus->receivedPassword[a] == '%')
    {
      Decoded_content[b] = (char)(Hex_To_Int(wfStatus->receivedPassword[a+1])*16 + Hex_To_Int(wfStatus->receivedPassword[a+2]));
      a += 3;
    }
    else if(wfStatus->receivedPassword[a] == '+')
    {
      Decoded_content[b] = ' ';
      a++;
    }
    else
    {
      Decoded_content[b] = wfStatus->receivedPassword[a];
      a++;
    }
    b++;
  }
  memset(wfStatus->receivedPassword, 0, strlen((const char*)wfStatus->receivedPassword));
  memcpy(wfStatus->receivedPassword, Decoded_content, strlen(Decoded_content));
  
  
  //// decoding ssid
  a = 0;
  b = 0;
  memset(Decoded_content, 0, strlen((const char*)Decoded_content));
  len = (char)strlen((const char*)wfStatus->selectedSsid);
  
  while(a < len)
  {
    if(wfStatus->selectedSsid[a] == '%')
    {
      Decoded_content[b] = (char)(Hex_To_Int(wfStatus->selectedSsid[a+1])*16 + Hex_To_Int(wfStatus->selectedSsid[a+2]));
      a += 3;
    }
    else if(wfStatus->selectedSsid[a] == '+')
    {
      Decoded_content[b] = ' ';
      a++;
    }
    else
    {
      Decoded_content[b] = wfStatus->selectedSsid[a];
      a++;
    }
    b++;
  }
  memset(wfStatus->selectedSsid, 0, strlen((const char*)wfStatus->selectedSsid));
  memcpy(wfStatus->selectedSsid, Decoded_content, strlen(Decoded_content));
}

int Hex_To_Int(char c)
{
    if ('0' <= c && c <= '9') return c - '0';
    if ('a' <= c && c <= 'f') return c - 'a' + 10;
    if ('A' <= c && c <= 'F') return c - 'A' + 10;
    return -1;
}

void WIFI_Send_Html_Content(WIFI_STATUS* wfStatus, const unsigned char* html)
{
  int len;
  char buffer[8] = {0};
  
  len = strlen((const char*)html);
  sprintf(buffer,"%c,%d",wfStatus->targetConnectionId,len);
  WIFI_Send_3(wfStatus, SET_DATA_SEND_CONFIG,buffer,700, 3);
  if(wfStatus->receptionStatus == RECEPTION_OK)
    WIFI_Send_3(wfStatus, SEND_DATA, (char*)html, 700, 1);
}

//////// mqtt packet generator and sender functions ////////
void mqtt_connect(char* server_token, char* client_identifier, WIFI_STATUS* wfStatus)
{
//  uint8_t server_token[] = "BBUS-UKSuNF0Fno0zeAgeisfg9Tzw3BluI4";  //35 chars
//  uint8_t client_identifier[] = "pakran";  // 6 chars
  uint8_t Protocol_Name[] = "MQTT";  // 4 chars
  
  uint8_t connect_packet[128] = {0};
  uint8_t offset = 0;
  
  connect_packet[offset++] = 0x10; // MQTT Control Packet type (CONNECT)
  
  // Placeholder for remaining length (to be calculated later)
  offset++; 
  
  // Protocol Name Length (MSB_LSB)
  connect_packet[offset++] = 0x00;
  connect_packet[offset++] = (uint8_t)strlen((const char*)Protocol_Name);
  
  // Protocol Name
  strcpy((char *)&connect_packet[offset], (const char*)Protocol_Name);
  offset += (uint8_t)strlen((const char*)Protocol_Name);
  
  connect_packet[offset++] = 0x04;  // Protocol Level

  connect_packet[offset++] = 0xC0;  // Connect Flags (Clean Session)

  connect_packet[offset++] = 0x00;  // Keep Alive (MSB)
  connect_packet[offset++] = 0x3C;  // Keep Alive (LSB)

  // Client Identifier Length
  connect_packet[offset++] = 0x00;
  connect_packet[offset++] = (uint8_t)strlen((const char*)client_identifier);

  // Client Identifier
  strcpy((char *)&connect_packet[offset], (const char*)client_identifier);
  offset += (uint8_t)strlen((const char*)client_identifier);
  
  // Username Length
  connect_packet[offset++] = 0x00;
  connect_packet[offset++] = strlen((const char*)server_token);

  // Username (Server Token)
  strcpy((char *)&connect_packet[offset], (const char*)server_token);
  offset += (uint8_t)strlen((const char*)server_token);
  
  // Set the remaining length
  connect_packet[1] = offset - 2;

//its like :
//    uint8_t connect_packet[] = {
//        0x10, 0x44, // MQTT Control Packet type (CONNECT) and remaining length
//        0x00, 0x04, // Protocol Name Length
//        'M', 'Q', 'T', 'T', // Protocol Name
//        0x04, // Protocol Level
//        0xC0, // Connect Flags (User Name Flag)
//        0x00, 0x3C, // Keep Alive (60 seconds)
//        0x00, 0x07, // Client Identifier Length
//        'c', 'l', 'i', 'e', 'n', 't', '1', // Client Identifier
//        0x00, 0x24, // Token Length
//        'B', 'B', 'U', 'S', '-', 'U', 'K', 'S', 'u', 'N', 'F', '0', 'F', 'n', 'o', '0', 'z', 'e', 'A', 'g', 'e', 'i', 's', 'f', 'g', '9', 'T', 'z', 'w', '3', 'B', 'l', 'u', 'I', '4' // Token
//    };
  WIFI_Send_3(wfStatus, CHECK_MULTIPLE_CONNECTION, "", 1000, 3);
  if(wfStatus->cipMux == 1)
  {
    WIFI_Send_3(wfStatus, STOP_TCP_SERVER, "0", 1000, 3);
    WIFI_Send_3(wfStatus, SET_MULTIPLE_CONNECTION, "0", 1000, 3);
  }
  WIFI_Send_3(wfStatus, CIP_START, "\"TCP\",\"industrial.api.ubidots.com\",1883,0", 1000, 3);
  WIFI_Send_Html_Content(wfStatus, (const unsigned char*)connect_packet);
  
}



