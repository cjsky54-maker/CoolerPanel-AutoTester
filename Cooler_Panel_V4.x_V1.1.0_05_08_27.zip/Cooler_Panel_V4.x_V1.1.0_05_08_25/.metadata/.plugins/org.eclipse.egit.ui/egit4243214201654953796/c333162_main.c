#include "stm8l15x_conf.h"
#include "initialization.h"
#include "lcd_seg.h"
#include "adc_reading.h"
#include "bs818a_2.h"
#include "string.h"
#include "functions.h"
#include "stdio.h"
#include "stm8l15x_it.h"
//#include "business_logic.h"
#include "driver_protocol.h"
#include "ask_decoder.h"

int main( void )
{
  Init_Registers();
  Periph_Config();
  while(1)
  {
    IWDG_Refresh();
  }
}
