#ifndef VARIABLES_H_
#define VARIABLES_H_

#define PARAMS_NUM		26
#define PARAMS_NUM_USER		11
#define CODE_VERSION 		103

#define VARLEN			74
#define VARLEN_WRITABLE		51
#define EEPROM_USED_LEN		100

#define EEPROM_START	        	PARAM_BUZZER_MODE
#define EEPROM_LEN			FIRMWARE_VERSION

#define PARAM_RESET_FACTORY				0
#define PARAM_BUZZER_MODE				1
#define PARAM_BRIGTHNESS				2
#define PARAM_STANDBY_BRIGHTNESS		        3
#define PARAM_STANDBY_ACTIVATION_TIME	                4
#define PARAM_PUMP_MODE					5
#define PARAM_TEMP_CALIBRATION			        6
#define PARAM_AUTO_SENSITIVITY			        7
#define PARAM_AUTO_POWER_ON				8
#define PARAM_CLEAR_REMOTES				9
#define PARAM_TEMP_COMP_SENSITIVITY			10
//#define PARAM_AUTO_VALVE_TIME			        11

#define PARAM_CONTROL_MODE				20
#define PARAM_MIN_PERCENT				21
#define PARAM_MAX_PERCENT				22
#define PARAM_RCCB_ENABLE				23
#define PARAM_VALVE_ON_TIME				24
#define PARAM_MAX_MOTOR_POWER				25
//#define PARAM_CONFIG_NUM				26

#define REMOTE_NUM				        5
#define REMOTE_ADDRRES_1				30
#define REMOTE_ADDRESS_2				31
#define REMOTE_ADDRRES_3				32
#define REMOTE_ADDRESS_4				33
#define REMOTE_ADDRRES_5				34

#define CMD_SETPOINT_PERCENT			        40
#define CMD_SETPOINT_TEMP				41
#define CMD_BITS					42
#define FIRMWARE_VERSION				43

#define CMD_IO_CONTROL                                  50

#define STAT_PERCENT					60
#define STAT_TEMP					61
#define STAT_TEMP_COMP					62
#define STAT_TEMP_DRV					63
#define STAT_VOL_OW					64
#define STAT_VOL_AC					65
#define STAT_VOL_PFC					66
#define STAT_ERROR					67	// 2 regs
#define STAT_WARNING					69
#define STAT_TOUCH					70
#define	STAT_REMOTE					71
#define	STAT_BITS					72
#define STAT_IO_CONTROL					73

// CMD_BITS & STAT BITS definition
#define BITS_POWER					0	// CMD & STAT
#define BITS_RUN					1	// CMD & STAT
#define BITS_PUMP					2	// CMD & STAT
#define BITS_VALVE					3	// CMD & STAT
#define BITS_PFC					4	// STAT
#define BITS_AUTO					5	// CMD
#define BITS_PANEL_MODE					6	// CMD	(2 bits)
#define BITS_COOLER_THERMAL				8	// CMD
#define BITS_FIRST_BOOT_IS_PASSED		        9	// CMD

// IO-control register bits defination
#define IO_BIT_BACKLIGHT				1 << 0
#define IO_BIT_RF_KEY					1 << 1
#define IO_BIT_SIG_RELAY				1 << 2
#define IO_BIT_USART_DIR				1 << 3
#define IO_BIT_POW_RELAY				1 << 4
#define IO_BIT_CMD_CLK					1 << 5
#define IO_BIT_BUZZER_ON				1 << 6
#define IO_BIT_RF_CLEAR					1 << 7
#define IO_BIT_LCD_ON					1 << 8
#define IO_BIT_LCD_OFF					1 << 9
#define IO_BIT_RUN					(1U << 10)
#define IO_BIT_PUMP					(1U << 11)
#define IO_BIT_VALVE					(1U << 12)
#define IO_BIT_RESET					(1U << 13)
#define IO_BIT_SET					(1U << 14)
#define IO_BIT_MANUAL					(1U << 15)

extern unsigned short reg[VARLEN];

unsigned char VAR_Set_Reg(unsigned char index, unsigned short val);
unsigned char VAR_Update_Reg_Bits(unsigned char index, unsigned short val, unsigned char startBit, unsigned char bitNum);

#endif /* VARIABLES_H_ */
