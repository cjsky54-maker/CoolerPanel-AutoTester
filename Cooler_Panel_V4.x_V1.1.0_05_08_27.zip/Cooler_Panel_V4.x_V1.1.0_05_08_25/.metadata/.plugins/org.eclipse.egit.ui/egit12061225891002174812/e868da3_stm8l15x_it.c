/**
******************************************************************************
* @file    Project/STM8L15x_StdPeriph_Template/stm8l15x_it.c
* @author  MCD Application Team
* @version V1.6.1
* @date    30-September-2014
* @brief   Main Interrupt Service Routines.
*          This file provides template for all peripherals interrupt service routine.
******************************************************************************
* @attention
*
* <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
*
* Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
* You may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*        http://www.st.com/software_license_agreement_liberty_v2
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the License is distributed on an "AS IS" BASIS, 
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "stm8l15x_it.h"
#include "initialization.h"
#include "bs818a_2.h"
#include "lcd_seg.h"
#include "adc_reading.h"
#include "math.h"
#include "driver_protocol.h"
#include "protocol.h"
#include "functions.h"
#include "stdio.h"
#include "variables.h"
#include "lcd_seg.h"
#include "ask_decoder.h"
#include "application.h" 

/** @addtogroup STM8L15x_StdPeriph_Template
* @{
*/

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
unsigned char data1, data2;// RF_OUT, RF_RCV_SIG=0, anyKeyOnRemote=0 , sigIndex = 0, sigValue[30], ASK_StartPeriod = 0;
unsigned char tim2Cnt = 0, secCnt = 0, remaining = 0, ledStat = 0, tim3Cnt = 0, cnt3=0;
unsigned short newAddr = 0;
BS818A_StructTypeDef bs818;
PROT_PACKET pckt2 = {.timeOut.limit = 10}, outpckt2;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

#ifdef _COSMIC_
/**
  * @brief Dummy interrupt routine
  * @par Parameters:
  * None
  * @retval 
  * None
  */
INTERRUPT_HANDLER(NonHandledInterrupt,0)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}
#endif

/**
  * @brief TRAP interrupt routine
  * @par Parameters:
  * None
  * @retval 
  * None
  */
INTERRUPT_HANDLER_TRAP(TRAP_IRQHandler)
{
  /* In order to detect unexpected events during development,
  	 it is recommended to set a breakpoint on the following instruction.
  */
}
/**
  * @brief FLASH Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(FLASH_IRQHandler,1)
{
  /* In order to detect unexpected events during development,
  	 it is recommended to set a breakpoint on the following instruction.
  */
}
/**
  * @brief DMA1 channel0 and channel1 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(DMA1_CHANNEL0_1_IRQHandler,2)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  USART_ITConfig(USART1, USART_IT_TC, ENABLE);
  
  DMA_ClearFlag(DMA1_FLAG_TC1);
  DMA_ClearITPendingBit(DMA1_IT_TC1);
}
/**
  * @brief DMA1 channel2 and channel3 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(DMA1_CHANNEL2_3_IRQHandler,3)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  TIM3_SetCounter(0);
  DMA_ClearFlag(DMA1_FLAG_TC2);
  Drv_Handle_Reception(getRx1BufferPointer());
  if(APP_UpdateDisplay_Is_Needed())
  {
      APP_UpdateDisplay();
  }
}
/**
  * @brief RTC / CSS_LSE Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(RTC_CSSLSE_IRQHandler,4)
{
  /* In order to detect unexpected events during development,
 	 it is recommended to set a breakpoint on the following instruction.
  */
    RTC_ClearITPendingBit(RTC_IT_ALRA);
}
/**
  * @brief External IT PORTE/F and PVD Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTIE_F_PVD_IRQHandler,5)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief External IT PORTB / PORTG Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTIB_G_IRQHandler,6)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief External IT PORTD /PORTH Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTID_H_IRQHandler,7)
{
  /* In order to detect unexpected events during development,
  	 it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief External IT PIN0 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI0_IRQHandler,8)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  /* Cleat Interrupt pending bit */
  EXTI_ClearITPendingBit(EXTI_IT_Pin0);
}

/**
  * @brief External IT PIN1 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI1_IRQHandler,9)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN2 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI2_IRQHandler,10)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN3 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI3_IRQHandler,11)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(APP_Handle_RCCB())
  {
      APP_UpdateDisplay();
  }
  EXTI_ClearITPendingBit(EXTI_IT_Pin3);
}

/**
  * @brief External IT PIN4 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI4_IRQHandler,12)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
#if RF_MDL_TYPE == RXC6
//  delay_ms(1);
//  RF_OUT = GPIO_ReadInputData(GPIOG) & 0xF;
//  VAR_Set_Reg(STAT_REMOTE, (unsigned short)RF_OUT);
//  RF_RCV_SIG = GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_4);
//  RF_OUT = ((RF_OUT & 0x1) << 3) | ((RF_OUT & 0x2) << 1) | ((RF_OUT & 0x4) >> 1) | ((RF_OUT & 0x8) >> 3); //reverse data bits
//  Perform_Remote_Operations(RF_OUT);
//
//  if(RF_RCV_SIG)
//  {
//    anyKeyOnRemote = PRESSED;
//    APP_Buzzer_Play_Time(BUZZER_ON_SHORT);
//    setLcdIsInStandby(0);
//    setLcdStandByTimer(0);
//    appState.standby = STATE_OFF;
//    Init_Display_Brightness(appState.LcdNormalContrastLevel);
//  }
//  else
//  {
//    anyKeyOnRemote = RELEASED;
//    cnt3=0;
//  }

#endif
  EXTI_ClearITPendingBit(EXTI_IT_Pin4);
}

/**
  * @brief External IT PIN5 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI5_IRQHandler,13)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN6 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI6_IRQHandler,14)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN7 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI7_IRQHandler,15)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  BS818A_2_Read(&bs818);
  Key_Handle_Touch_Int(bs818);
  Key_Handle_Pending(&appState.pressedKey, &appState.pressType);
  APP_Handle_Key();
  EXTI_ClearITPendingBit(EXTI_IT_Pin7);
}
/**
  * @brief LCD /AES Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(LCD_AES_IRQHandler,16)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  LCD_ClearITPendingBit();
}
/**
  * @brief CLK switch/CSS/TIM1 break Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(SWITCH_CSS_BREAK_DAC_IRQHandler,17)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief ADC1/Comparator Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(ADC1_COMP_IRQHandler,18)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(ADC_GetITStatus(ADC1,ADC_IT_OVER) != RESET)
  {
    DMA_Reconfig(DMA1_Channel0);
    ADC_ClearITPendingBit(ADC1, ADC_IT_OVER);
  }
}

/**
 * @brief TIM2 Update/Overflow/Trigger/Break /USART2 TX Interrupt routine.
 * @param  None
 * @retval None
 */
INTERRUPT_HANDLER(TIM2_UPD_OVF_TRG_BRK_USART2_TX_IRQHandler,19)
{
	/* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
	 */
	if(TIM2_GetITStatus(TIM2_IT_Update) != RESET)
	{
		///////////////// 0.25 sec /////////////////
		tim2Cnt++;
		ADCR_CalculateTemp();
		if(Drv_IsBusIdle())
		{
			ADCR_CalculateVow();
		}
		ADCR_CalculateVac();
		APP_Aggregate_Error();
		if(APP_Check_Error())
		{
			APP_UpdateDisplay();
		}
		APP_Calculate_Compensated_Temp();
		//    APP_Remote_Save();
		////////////////////////////////////////////

		///////////////// 1.0  sec /////////////////
		if(tim2Cnt == 4)
		{
			tim2Cnt = 0;
			secCnt++;
			if(secCnt == 10)
			{
				secCnt = 0;
			}
			ledStat = secCnt % 2;
			LEDs_PWR(ledStat);
			remaining = secCnt % 5;
			if(remaining == 0)
			{
                                if(appState.panelState == PANEL_STAT_NORMAL)// && appState.drvSetting->runCmd == DRV_RUN_START)
				{
					Drv_Read_Register(DRV_REG_LIMIT_FLAG);
				}
			}
			else if(remaining == 1)
			{
				if((appState.panelState == PANEL_STAT_NORMAL && appState.drvSetting->runCmd == DRV_RUN_START) ||
                                   (appState.panelState == PANEL_STAT_ERROR && appState.drvState->pwrStat != DRV_PWR_OFF))	// to Recover from connection error
				{
					Drv_Read_Fault();
				}
			}
			else if(remaining == 2)
			{
				Drv_Handle_Error();
                                Drv_Handle_Warning();
                                APP_Aggregate_Warning();
				Drv_Clear_If_Needed();
			}
			else if(remaining == 3)
			{
                                if(appState.panelState == PANEL_STAT_NORMAL)
				{
					Drv_Handle_Conflict();
				}
			}
//			else if(remaining == 4)
//			{
//
//			}
                        
			APP_UpdateDisplay_Temp();
			if(APP_Handle_Auto())
			{
				APP_UpdateDisplay();
			}
		}


		TIM2_ClearITPendingBit(TIM2_IT_Update);
	}
}

/**
  * @brief Timer2 Capture/Compare / USART2 RX Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM2_CC_USART2_RX_IRQHandler,20)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  if( (USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET) )// (USART_GetFlagStatus(USART2, USART_FLAG_OR) != RESET) )
  {
    unsigned char rcvFlag2;
    PROT_ErrorTypeDef error = PROT_ERR_NO;
    
    data2 = USART_ReceiveData8(USART2);
    pckt2.buffer[pckt2.index] = data2;
    rcvFlag2 = PROT_Handle_Reception(&pckt2);
    
    // receive our packet
    if(rcvFlag2 == 1)
    {
      rcvFlag2 = 0;
      error = PROT_Packet_Analyse(&pckt2);
      // if there is no error in received packet, response to it
      if(error == PROT_ERR_NO)
      {
        PROT_Packet_Execute(&pckt2, &outpckt2);
        UART_Send(2, outpckt2.buffer, outpckt2.length);
      }
    }
  }
}


/**
  * @brief Timer3 Update/Overflow/Trigger/Break Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM3_UPD_OVF_TRG_BRK_USART3_TX_IRQHandler,21)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(TIM3_GetITStatus(TIM3_IT_Update) != RESET)
  {
    ///////////////// 10m  sec /////////////////
    TIME_IncreaseMS();
    tim3Cnt++; 
    APP_Check_Timing();
    PROT_Handle_Timeout(&pckt2);

    
    ///////////////// 100m sec /////////////////
    if(tim3Cnt == 10) 
    {
      tim3Cnt = 0;
      
      // this function should be called before Key_Handle_Touch_Time
      Key_Handle_Long_Continuous(KEY_UP, 3);
      Key_Handle_Long_Continuous(KEY_DOWN, 3);
      
      Key_Handle_Touch_Time();
      Key_Handle_Pending(&appState.pressedKey, &appState.pressType);
      APP_Handle_Key();
    }

    TIM3_ClearITPendingBit(TIM3_IT_Update);
  }
}

//uint8_t cc = 0;
/**
  * @brief Timer3 Capture/Compare /USART3 RX Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM3_CC_USART3_RX_IRQHandler,22)
{
//  GPIO_ResetBits(GPIOG,GPIO_Pin_0);
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  
  if (USART_GetFlagStatus(USART3, USART_FLAG_RXNE) != RESET)
  {
    unsigned char data3 = USART_ReceiveData8(USART3);
  }
//  GPIO_SetBits(GPIOG,GPIO_Pin_0);
}
/**
  * @brief TIM1 Update/Overflow/Trigger/Commutation Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM1_UPD_OVF_TRG_COM_IRQHandler,23)
{
//  GPIO_SetBits(GPIOG,GPIO_Pin_1);
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(TIM1_GetITStatus(TIM1_IT_Update) != RESET)
  {
#if RF_MDL_TYPE == CY41
    ASK_StartReception();
    REMOTE_Handle_Release();
#endif
    TIM1_ClearITPendingBit(TIM1_IT_Update);
  }
//  GPIO_ResetBits(GPIOG,GPIO_Pin_1);
}


/**
  * @brief TIM1 Capture/Compare Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM1_CC_IRQHandler,24)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
//  GPIO_SetBits(GPIOG,GPIO_Pin_2);
  if(TIM1_GetITStatus(TIM1_IT_CC2) != RESET)
  {
#if RF_MDL_TYPE == CY41
    ASK_HandleReception();
    if(appState.settings->learnStat == LEARN_PENDING)
    {
            if(REMOTE_Handle_Learn(&newAddr))
            {
                    SETTINGS_Save_Remote(newAddr);
                    APP_Buzzer_Play_Time(BUZZER_ON_LONG);
                    APP_UpdateDisplay();
            }
    }
    else if(appState.settings->learnStat == LEARN_NO)
    {
            appState.remotePressedKey = REMOTE_Handle_Reception();
            APP_Handle_Remote();
    }
#endif
  }
//  GPIO_ResetBits(GPIOG,GPIO_Pin_2);
}

/**
  * @brief TIM4 Update/Overflow/Trigger Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM4_UPD_OVF_TRG_IRQHandler,25)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}
/**
  * @brief SPI1 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(SPI1_IRQHandler,26)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */		
}

/**
  * @brief USART1 TX / TIM5 Update/Overflow/Trigger/Break Interrupt  routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(USART1_TX_TIM5_UPD_OVF_TRG_BRK_IRQHandler,27)
{
//  GPIO_SetBits(GPIOG,GPIO_Pin_3);
  /* In order to detect unexpected events during development,
  it is recommended to set a breakpoint on the following instruction.
  */
  if(USART_GetITStatus(USART1, USART_IT_TC) != RESET)
  {
    // Changing Direction of Onewire to Input
    CMDs_PWR(CMD_USART_DIR, DIR_RX);
    
    USART_ClearFlag(USART1, USART_FLAG_TC);
    USART_ClearITPendingBit(USART1, USART_IT_TC);
    USART_ITConfig(USART1, USART_IT_TC, DISABLE);
    
    Drv_Handle_Send();
  }
//  GPIO_ResetBits(GPIOG,GPIO_Pin_3);
}

/**
  * @brief USART1 RX / Timer5 Capture/Compare Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(USART1_RX_TIM5_CC_IRQHandler,28)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  data1 = USART_ReceiveData8(USART1);
  
  //  Driver_Receive_Byte(data1);
  //  TIM3_SetCounter(0);
  //  UART_Send(2, &data1, 1);
  //  volatile uint8_t sr = USART2->SR;
  //  USART_SendData8(USART2, data1);
  //  USART_ClearFlag(USART1, USART_FLAG_RXNE);
  //  TIM5_ClearFlag(TIM5_FLAG_CC1 | TIM5_FLAG_CC2);
}

/**
  * @brief I2C1 / SPI2 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(I2C1_SPI2_IRQHandler,29)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}


/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
