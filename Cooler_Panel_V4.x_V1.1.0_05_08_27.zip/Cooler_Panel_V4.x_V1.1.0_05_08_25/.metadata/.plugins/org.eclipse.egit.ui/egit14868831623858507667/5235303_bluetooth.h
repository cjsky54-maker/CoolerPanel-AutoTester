/*
 * bluetooth.h
 *
 *  Created on: Feb 6, 2020
 *	Editted on :2024 by Amirhossein Nikzamir
 *      Author: Masoud Shahrabi
 */

#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_


#include "stm8l15x_conf.h"

   
//#define HM10		//Bluetooth Model: HM10, AT05, or BT05
#define AT05
//#define BT05

#define DISCONNECTED	                0
#define CONNECTED		        1

// Commands
#define NO_CMD				0
#define INCREASE_PWR		        1
#define ON_NOTIFICATION		        2
#define CHANGE_NAME			3
#define BT_RESET_CMD		4
#define AT_CMD				5
#define AT_GET_BAUD			6
#define AT_SET_BAUD			7
#define AT_BT_GET_VERSION		        8

#define BLE_BAUD			9600


typedef struct
{
	unsigned char atCommand;			// The AT command sent to the module
	unsigned char connectionStatus;		// Show connection to mobile
	unsigned char sendingAtCmd;			// Should be set for commands that return sth other than OK and should be cleared as soon as possible to avoid conflicting with receiving mobile packets
	uint32_t connectionTimeout;		// Number of seconds from receiving the last packet from mobile
	uint32_t atCmdTimeout;			// For timeout waiting for receiving AT response
	unsigned char respBuffer[50];		// response of module after sending AT command
	unsigned char index;				// index of respBuffer
	unsigned char mode;					// reception mode
	unsigned char length;				// length of received response
	unsigned char resetMode;			// determines status of reset pin
	uint32_t atTimeoutValue;		// resolution: mili second / determines times waiting for receiving at response
	unsigned char atSentNum;			// number of times AT commands is sent
	unsigned char isDxBt24;
	unsigned char versionRead;
} BLUETOOTH_STATUS;

#define BT_NRST_PORT	        GPIOF
#define BT_NRST_PIN		GPIO_Pin_7

unsigned char BT_RecieveAtResponse(unsigned char receivedData);
void BT_CheckConnection(void);
void BT_AtCmdTimeout(void);
void BT_ChangeName(unsigned char* idModelChanged);
void BT_ResetOperations(void);
void BT_ExtractCmd(char* btCmdPacket);
void BT_Increase_Power(void);
void BT_Enable_Notification(void);
uint8_t BT_CheckBaud(uint32_t baud);
void BT_SetBaud(uint32_t newBaudRate);
void BT_Send_At_Command(unsigned char cmd, char* cmdBuffer, unsigned int timeOut);

uint32_t BT_DetectBaud(void);

///// getter and setter functions /////
unsigned char BT_GetSendingAtCmd(void);
char* BT_GetRespBuffer(void);
unsigned char BT_GetConnectionStatus(void);
void BT_SetConnectionStatus(unsigned char newVal);
void BT_ResetConnectionTimeout(void);

#endif /* BLUETOOTH_H_ */