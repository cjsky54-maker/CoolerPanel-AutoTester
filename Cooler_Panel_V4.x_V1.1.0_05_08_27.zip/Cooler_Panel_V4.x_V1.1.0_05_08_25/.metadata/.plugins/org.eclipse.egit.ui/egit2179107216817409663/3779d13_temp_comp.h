/*
 * temp_comp.h
 *
 *  Created on: Jul 13, 2026
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_TEMP_COMP_H_
#define OTHER_LIB_INC_TEMP_COMP_H_

#include "main.h"

#define TEMPCOMP_WATT_MAX			600

#define TEMPCOMP_OFF_FINAL_INCREASE		3.8
#define TEMPCOMP_OFF_BREAKPOINT_RATIO	        0.9
#define TEMPCOMP_OFF_BREAKPOINT_TIME	        30*60
#define TEMPCOMP_OFF_TOTAL_TIME			60*60
#define TEMPCOMP_ON_BREAKPOINT_RATIO	        0.75
#define TEMPCOMP_ON_BREAKPOINT_TIME		25*60
#define TEMPCOMP_ON_TOTAL_TIME			60*60

typedef struct
{
	float tempStart;
	float tempEnd;
	float breakPointTempRatio;
	unsigned short breakPointTime;
	unsigned short totalTime;
	float a1;
	float b1;
	float a2;
	float b2;
	float offset;
	TIMING_StructTypedef elapsed;
	unsigned char isReached;
}TEMP_CompenationTypeDef;


void TEMPCOMP_Off_Start(TEMP_CompenationTypeDef* tempComp);
void TEMPCOMP_Start(TEMP_CompenationTypeDef* tempComp, signed short watt);
void TEMPCOMP_Calculate_Offset(TEMP_CompenationTypeDef* tempComp);

#endif /* OTHER_LIB_INC_TEMP_COMP_H_ */
