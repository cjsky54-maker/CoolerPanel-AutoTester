/*
 * adc_reading.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_ADC_READING_H_
#define OTHER_LIB_INC_ADC_READING_H_

typedef struct
{
  float temp;		        // the temprature in degree
  float adcAvg; 	        // average of ADC raw data
  unsigned long adcSum;         // sum of ADC raw data
} ADC_READING;
   
int findIndex(float target_resistance); 
float interpolateTemp(float target); 
void adc1AveragingBuffer(unsigned short* ADCConvertedValue, ADC_READING* adcReading);
void calculateTemp(ADC_READING* adcReading); //should be called second in a loop

#endif /* OTHER_LIB_INC_ADC_READING_H_ */
