#include "lcd_seg.h"
#include "stm8l15x_conf.h"

// The value for each bit of seven segment for each number 0~9 & OFF & E & L & P & d & F & H
const unsigned char sevenSegCode[SEVEN_SEG_SYMBOL_NUMS] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x00, 0x79, 0x38, 0x73, 0x5E, 0x71, 0x76};

// pixel to ram conversion -> 4 high bits (7~4)-> byte number (0~13), 3 low bits (2~0) -> bit number
// The positionn to array is according to above definitions
const unsigned char figRamPosition[FIG_NUM] = {0xA5, 0x71, 0x35, 0x25, 0x61, 0x94, 0xD0, 0x01, 0x14, 0x72,
                                               0xA6, 0x36, 0x02, 0x03, 0x12, 0xB4, 0x17, 0x15, 0xC7, 0x93,
                                               0x57, 0x23, 0x21, 0xC1, 0x85, 0x51, 0x95};
const unsigned char sevenSegRamPosition[SEVEN_SEG_NUM][7] = {{0xB2, 0x76, 0x42, 0x06, 0x37, 0xA7, 0x73},
                                                       {0x13, 0x47, 0x83, 0xB7, 0xC0, 0x50, 0x84},
                                                       {0x11, 0x45, 0x81, 0xB5, 0xB6, 0x46, 0x82},
                                                       {0x07, 0x43, 0x77, 0xB3, 0x80, 0x10, 0x44},
                                                       {0x20, 0x54, 0x90, 0xC4, 0xC5, 0x55, 0x91},
                                                       {0x16, 0x52, 0x86, 0xC2, 0xC3, 0x53, 0x87}};


LCD_GLASS lcdGlass;

/**
  * @brief  Deinit the LCD_GLASS structure
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the LCD_GLASS structure fields are updated)
  */
void LCD_GLASS_Struct_Deinit()
{
  unsigned char i;
  lcdGlass.needUpdate = 0;
  for(i=0;i<FIG_NUM;i++)
    lcdGlass.figs[i] = OFF;
  for(i=0;i<SEVEN_SEG_NUM;i++)
    lcdGlass.sevenSeg[i] = SEVEN_SEG_OFF;
  for(i=0;i<RAM_REG_NUM;i++)
    lcdGlass.lcdRAM[i] = 0;
}

    
  /**
  * @brief  Init the LCD_GLASS structure
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the LCD_GLASS structure fields are updated)
  */
void LCD_GLASS_Struct_Init()
{
  unsigned char i;
  lcdGlass.needUpdate = 0;
  for(i=0;i<FIG_NUM;i++)
    lcdGlass.figs[i] = ON;
  for(i=0;i<SEVEN_SEG_NUM;i++)
    lcdGlass.sevenSeg[i] = 8;
}


/**
  * @brief  Update the value of a figure and its corresponding ram position in the structure 
  * @param  fig: the figure its state is updated
  * @param  state: the new state of figure  
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the figs and lcdRAM fields in LCD_GLASS structure are updated)
  */
void LCD_GLASS_Update_Fig_Struct(unsigned char fig, unsigned char state)
{
  unsigned char byte, bit;
  if(fig < FIG_NUM && state < 2)
  {
    lcdGlass.figs[fig] = state;
    byte = figRamPosition[fig] & 0xF0;
    byte >>= 4;
    bit = figRamPosition[fig] & 0xF;
    bit = 1<<bit;
    if(state == OFF)
      lcdGlass.lcdRAM[byte] &= ~bit;
    else
      lcdGlass.lcdRAM[byte] |= bit;
  
    lcdGlass.needUpdate = 1;
  }
}


/**
  * @brief  Update the value of a figure and its corresponding ram position in the structure 
            Also update the affected ram position of microcontroller
  * @param  fig: the figure its state is updated
  * @param  state: the new state of figure  
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the figs and lcdRAM fields in LCD_GLASS structure are updated)
  */
void LCD_GLASS_Update_Fig(unsigned char fig, unsigned char state)
{
  unsigned char byte, bit;
  if(fig < FIG_NUM && state < 2)
  {
    lcdGlass.figs[fig] = state;
    byte = figRamPosition[fig] & 0xF0;
    byte >>= 4;
    bit = figRamPosition[fig] & 0xF;
    bit = 1<<bit;
    if(state == OFF)
      lcdGlass.lcdRAM[byte] &= ~bit;
    else
      lcdGlass.lcdRAM[byte] |= bit;
    LCD_WriteRAM((LCD_RAMRegister_TypeDef)(LCD_RAMRegister_0+byte), lcdGlass.lcdRAM[byte]);
  }
}

/**
  * @brief  Update the value of a seven segment and its corresponding ram positions in the structure 
  * @param  sevenSegNum: the position of seven segment
  * @param  sevenSegVal: the value of seven segment  
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the sevenSeg and lcdRAM fields in LCD_GLASS structure are updated)
  */
void LCD_GLASS_Update_SevenSeg_Struct(unsigned char sevenSegNum, unsigned char sevenSegVal)
{
  unsigned char i, code, state, posByte, posBit;
  if(sevenSegNum < SEVEN_SEG_NUM && sevenSegVal < SEVEN_SEG_SYMBOL_NUMS)
  {
    lcdGlass.sevenSeg[sevenSegNum] = sevenSegVal;
    code = sevenSegCode[sevenSegVal];
    for(i=0;i<7;i++)
    {
      state = code & (1<<i);
      posByte = sevenSegRamPosition[sevenSegNum][i] & 0xF0;
      posByte >>= 4; 
      posBit = sevenSegRamPosition[sevenSegNum][i] & 0xF;
      posBit = 1<<posBit;
      if(state == OFF)
        lcdGlass.lcdRAM[posByte] &= ~posBit;
      else
        lcdGlass.lcdRAM[posByte] |= posBit;
    }
    
    lcdGlass.needUpdate = 1;
  }
}


/**
  * @brief  Update the value of a seven segment and its corresponding ram positions in the structure 
            Also update the affected ram positions of microcontroller
  * @param  sevenSegNum: the position of seven segment
  * @param  sevenSegVal: the value of seven segment  
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the sevenSeg and lcdRAM fields in LCD_GLASS structure are updated)
  */
void LCD_GLASS_Update_SevenSeg(unsigned char sevenSegNum, unsigned char sevenSegVal)
{
  unsigned char i, code, state, posByte, posBit;
  if(sevenSegNum < SEVEN_SEG_NUM && sevenSegVal < SEVEN_SEG_SYMBOL_NUMS)
  {
    lcdGlass.sevenSeg[sevenSegNum] = sevenSegVal;
    code = sevenSegCode[sevenSegVal];
    for(i=0;i<7;i++)
    {
      state = code & (1<<i);
      posByte = sevenSegRamPosition[sevenSegNum][i] & 0xF0;
      posByte >>= 4; 
      posBit = sevenSegRamPosition[sevenSegNum][i] & 0xF;
      posBit = 1<<posBit;
      if(state == OFF)
        lcdGlass.lcdRAM[posByte] &= ~posBit;
      else
        lcdGlass.lcdRAM[posByte] |= posBit;
      LCD_WriteRAM((LCD_RAMRegister_TypeDef)(LCD_RAMRegister_0+posByte), lcdGlass.lcdRAM[posByte]);
    }
  }
}


/**
  * @brief  Update the lcdRAM field of structure according to figs and sevenSeg fields of structure  
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None (the lcdRAM fields in LCD_GLASS structure is updated)
  */
void LCD_GLASS_Update_Struct()
{
  unsigned char i;
  for(i=0;i<FIG_NUM;i++)
    LCD_GLASS_Update_Fig_Struct(i, lcdGlass.figs[i]);
  for(i=0;i<SEVEN_SEG_NUM;i++)
    LCD_GLASS_Update_SevenSeg_Struct(i, lcdGlass.sevenSeg[i]);
}


/**
  * @brief  Update the microcontroller lcd ram according to the lcdRAM field in LCD_GLASS structure   
  * @param  lcdGlass: pointer to LCD_GLASS structure
  * @retval None
  */
void LCD_GLASS_Update()
{
  unsigned char i;
  if(lcdGlass.needUpdate == 1 )//&& lcdGlass.changesCompleted == 1)
  {
    for(i=0;i<RAM_REG_NUM;i++)
      LCD_WriteRAM((LCD_RAMRegister_TypeDef)(LCD_RAMRegister_0+i), lcdGlass.lcdRAM[i]);
//    lcdGlass.changesCompleted = 0;
    lcdGlass.needUpdate = 0;
  }
}


void LCD_GLASS_SET_changesCompleted(unsigned char value)
{
  lcdGlass.changesCompleted = value;
}



