#include "adc_reading.h"
#include "variables.h"


typedef enum
{
	ADC_CHANNEL_VAC = 0,
	ADC_CHANNEL_VOW = 1,
	ADC_CHANNEL_TEMP = 2,
}ADC_CHANNELTypedef;

#define GAIN_ADC_TO_VOLTAGE		        3.3/4096
#define GAIN_VOW				2
#define GAIN_VAC			        105.1  // 101(100k + 1K) * 1.08089(correction coefficient)

#define OW_MIN_VOLTAGE  			2.2
#define OW_MAX_VOLTAGE  			3.3

#define AC_MAX_VOL_ERR_SET  		250
#define AC_MAX_VOL_ERR_RESET  		240
#define AC_MIN_VOL_ERR_RESET  		160
#define AC_MIN_VOL_ERR_SET  		145
#define AC_VOL_ERR_RESET_DURATION	20000
#define OW_VOL_ERR_SET_DURATION		5000

ADC_READING adcReading = {0};
unsigned short adcConvertedValue[ADC1_BUF_LEN];

// Array of the resistance according to sensor data sheet
const float R[35] = {40308.0, 36311.0, 32754.0, 29584.0, 26755.0, 24227.0, 21965.0,
					 19938.0 ,18119.0 ,	16485.0, 15016.0, 13693.0, 12500.0, 11423.0,
					 10451.0, 9570.0, 8773.0, 8051.0, 7395.0, 6799.0, 6257.0,
					 5764.0, 5314.0, 4904.0, 4530.0, 4187.0, 3874.0, 3588.0,
					 3325.0, 3084.0, 2863.0, 2660.0, 2473.0, 2301.0, 2143.0};

// Array of temperatures according to sensor data sheet
// Temperatures from -4�C to 64�C in 2�C steps
const float Temperatures[35] = {-4.0, -2.0, 0.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0,
								16.0, 18.0, 20.0, 22.0, 24.0, 26.0, 28.0, 30.0, 32.0, 34.0,
								36.0, 38.0, 40.0, 42.0, 44.0, 46.0, 48.0, 50.0, 52.0, 54.0,
								56.0, 58.0, 60.0, 62.0, 64.0};

void ADCR_AverageBuffer(ADC_CHANNELTypedef channel);
int findIndex(float target_resistance);
float interpolateTemp(float target);

void ADCR_Init(void)
{
	adcReading.error = 0;
	adcReading.tempFiltered = 0;
	adcReading.state = STATE_OFF;
	adcReading.errorClear.limit = AC_VOL_ERR_RESET_DURATION;
	adcReading.errorSet.limit = OW_VOL_ERR_SET_DURATION;
	adcReading.startUp.limit = 2000;
	TIMING_Start(&adcReading.startUp);
}

unsigned short* ADCR_Get_Buffer(void)
{
	return adcConvertedValue;
}

ADC_READING* ADCR_Get_Struct(void)
{
	return &adcReading;
}

/**
 * @brief  Calculate the average of reading adc data
 * @param  channel: one of the ADC_CHANNEL_VAC , ADC_CHANNEL_VOW or ADC_CHANNEL_TEMP
 * @retval None (the adcSum and adcAvg field in ADC_READING structure is updated)
 */
void ADCR_AverageBuffer(ADC_CHANNELTypedef channel)
{
	unsigned short i;

	adcReading.adcSum[channel] = 0;
	for(i=0; i<ADC1_CH_BUF_LEN; i++)
	{
		adcReading.adcSum[channel] += adcConvertedValue[ADC1_CH_NUM * i + channel];
	}
	adcReading.adcAvg[channel] = (float)adcReading.adcSum[channel] / ADC1_CH_BUF_LEN;
	adcReading.adcVol[channel] = adcReading.adcAvg[channel] * GAIN_ADC_TO_VOLTAGE;
}

/**
 * @brief  Calculate the environment temperature
 * @param  None
 * @retval None
 */
void ADCR_CalculateTemp(void)
{
	float res;

	ADCR_AverageBuffer(ADC_CHANNEL_TEMP);
	res = (10000.0 * adcReading.adcVol[ADC_CHANNEL_TEMP]) / (3.3 - adcReading.adcVol[ADC_CHANNEL_TEMP]);
	adcReading.temp = interpolateTemp(res);

	if (adcReading.tempFiltered == 0)
	{
		adcReading.tempFiltered = adcReading.temp;
	}
	adcReading.tempFiltered = adcReading.tempFiltered * 0.8 + adcReading.temp * 0.2;
	VAR_Set_Reg(STAT_TEMP, (unsigned short)(adcReading.tempFiltered * 10));
}

/**
 * @brief  Calculate the onewire voltege
 * @param  None
 * @retval None
 */
void ADCR_CalculateVow(void)
{
	ADCR_AverageBuffer(ADC_CHANNEL_VOW);
	adcReading.vOW = adcReading.adcVol[ADC_CHANNEL_VOW] * GAIN_VOW;
	VAR_Set_Reg(STAT_VOL_OW, (unsigned short)(adcReading.vOW * 1000));

	if(adcReading.state == STATE_ON)
	{
		if(adcReading.vOW > OW_MIN_VOLTAGE && adcReading.vOW < OW_MAX_VOLTAGE)
		{
			CLEAR_BIT(adcReading.error, ADC_ERROR_OW_DISCONNECTED);
			TIMING_Clear(&adcReading.errorSet);
		}
		else
		{
			if(adcReading.errorSet.isCounting == 0)
			{
				TIMING_Start(&adcReading.errorSet);
			}
			else if(TIMING_Check(&adcReading.errorSet))
			{
				SET_BIT(adcReading.error, ADC_ERROR_OW_DISCONNECTED);
			}
		}
	}
	else
	{
		if(TIMING_Check(&adcReading.startUp))
		{
			adcReading.state = STATE_ON;
		}
	}
}

/**
 * @brief  Calculate the AC voltege
 * @param  None
 * @retval None
 */
void ADCR_CalculateVac(void)
{
	unsigned char vAcErr = adcReading.error & (ADC_ERROR_HIGH_VOLTAGE | ADC_ERROR_LOW_VOLTAGE);

	ADCR_AverageBuffer(ADC_CHANNEL_VAC);
	adcReading.vAC = adcReading.adcVol[ADC_CHANNEL_VAC] * GAIN_VAC;
	VAR_Set_Reg(STAT_VOL_AC, (unsigned short)(adcReading.vAC * 10));

	// Update AC Voltage Errors
	if(adcReading.state == STATE_ON)
	{
		if(vAcErr == 0)
		{
			if(adcReading.vAC > AC_MAX_VOL_ERR_SET)
			{
				TIMING_Start(&adcReading.errorClear);
				SET_BIT(adcReading.error, ADC_ERROR_HIGH_VOLTAGE);
			}
			else if(adcReading.vAC < AC_MIN_VOL_ERR_SET)
			{
				TIMING_Start(&adcReading.errorClear);
				SET_BIT(adcReading.error, ADC_ERROR_LOW_VOLTAGE);
			}
		}
		else
		{
			if(adcReading.vAC > AC_MIN_VOL_ERR_RESET && adcReading.vAC < AC_MAX_VOL_ERR_RESET)
			{
				if(TIMING_Check(&adcReading.errorClear))
				{
					CLEAR_BIT(adcReading.error, ADC_ERROR_LOW_VOLTAGE | ADC_ERROR_HIGH_VOLTAGE);
				}
			}
			else
			{
				TIMING_Start(&adcReading.errorClear);

				// update Error type
				if(adcReading.vAC > AC_MAX_VOL_ERR_SET)
				{
					SET_BIT(adcReading.error, ADC_ERROR_HIGH_VOLTAGE);
					CLEAR_BIT(adcReading.error, ADC_ERROR_LOW_VOLTAGE);
				}
				else if(adcReading.vAC < AC_MIN_VOL_ERR_SET)
				{
					SET_BIT(adcReading.error, ADC_ERROR_LOW_VOLTAGE);
					CLEAR_BIT(adcReading.error, ADC_ERROR_HIGH_VOLTAGE);
				}
			}
		}
	}
	else
	{
		if(TIMING_Check(&adcReading.startUp))
		{
			adcReading.state = STATE_ON;
		}
	}
}

/**
 * @brief  Find the index of target resistance in the lookup table
 * @param  target_resistance: the ntc sensor resistance
 * @retval the index of target resistance in the lookup table
 */
int findIndex(float target_resistance)
{
	int i = 0;
	for (i = 0; i < 35; i++)
	{
		if (target_resistance > R[i])
		{
			return i;
		}
	}
	return 35;
}

/**
 * @brief  Perform interpolation to find temperature associated to target resistance
 * @param  target: the ntc sensor resistance
 * @retval the calculated temperature
 */
float interpolateTemp(float target)
{
	float computed_temperature = 0;
	int index = findIndex(target);

	// If target resistance is larger than the first resistance in the array
	if (index == 0)
	{
		computed_temperature = ( (target - R[0]) * (Temperatures[0] - Temperatures[1]) /
				(R[0] - R[1]) ) + Temperatures[0];
	}
	// If target resistance is in range of min and max resistance
	else if ((index > 0) && (index < sizeof(R)))
	{
		computed_temperature = Temperatures[index - 1] + (target - R[index - 1]) *
				(Temperatures[index] - Temperatures[index - 1]) / (R[index] - R[index - 1]);
	}
	// If target resistance is less than min resistance
	else if (index == sizeof(R))
	{
		computed_temperature = Temperatures[35 - 1] - ( (Temperatures[35 - 2] - Temperatures[35 - 1]) * (R[35 - 1] - target) / (R[35 - 2]- R[35 - 1]) );
	}

	return computed_temperature;
}
