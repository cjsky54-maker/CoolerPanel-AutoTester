/*
 * application.h
 *
 *  Created on: Apr 21, 2026
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_APPLICATION_H_
#define OTHER_LIB_INC_APPLICATION_H_

#include "main.h"

#define DISPLAY_PARAM_NUM       6
#define AUTO_POWER_ON_DELAY     5000
#define HYSTERESIS_OFFSET       0.5 // degree

#define APP_TIMING_FLAG_10MS    (1U << 0)
#define APP_TIMING_FLAG_100MS   (1U << 1)
#define APP_TIMING_FLAG_250MS   (1U << 2)
#define APP_TIMING_FLAG_1_0SEC  (1U << 3)
#define APP_TIMING_FLAG_1_1SEC  (1U << 4)
#define APP_TIMING_FLAG_1_2SEC  (1U << 5)
#define APP_TIMING_FLAG_1_3SEC  (1U << 6)

typedef enum
{
	PANEL_STAT_OFF = 0,
	PANEL_STAT_NORMAL = 1,
	PANEL_STAT_SETTINGS = 2,
	PANEL_STAT_ERROR = 3,
	PANEL_STAT_TEST = 4,
}PANEL_StateTypeDef;

typedef enum
{
	DISPLAY_PARAM_NO = 0,
	DISPLAY_PARAM_CODE_VERSION = 1,
	DISPLAY_PARAM_DROP_RATE_LAST = 2,
	DISPLAY_PARAM_DROP_RATE_TOTAL = 3,
	DISPLAY_PARAM_VAC_INPUT = 4,
	DISPLAY_PARAM_DC_BUS_VOL = 5,
	DISPLAY_PARAM_DRV_TEMP = 6,
}DISPLAY_ParamTypeDef;

typedef enum
{
	APP_ERROR_RCCB = 1 << 0,
}
APP_ErrorTypeDef;

typedef enum
{
	AUTO_MODE_MANUAL = 0,
	AUTO_MODE_AUTO = 1,
}AUTO_ModeTypeDef;

typedef enum
{
	TIMER_OFF = 0,
	TIMER_ON = 1,
	TIMER_IN_SETTING = 2,
}TIMER_StateTypeDef;

typedef struct
{
	TIMER_StateTypeDef state;
	unsigned char value;
	TIMING_StructTypedef timingTimer;
	TIMING_StructTypedef timingSet;
}TIMER_HandleTypeDef;

typedef enum
{
	BUZZER_ON_OFF = 0,
	BUZZER_ON_SHORT = 50,
	BUZZER_ON_LONG = 400,
	BUZZER_ON_CONT = 150,
} Buzzer_OnTimeTypeDef;

typedef struct
{
	Buzzer_OnTimeTypeDef onTime;
	TIMING_StructTypedef timingBuzzer;
}BUZZER_StateTypeDef;

typedef struct
{
	PANEL_StateTypeDef panelState;
	PowerState standby;
	PowerState lock;
	PowerState rccbEnable;
	AUTO_ModeTypeDef pumpMode;
	AUTO_ModeTypeDef autoMode;
	AUTO_ModeTypeDef autoPowerOnMode;
	unsigned char autoSensitivity;
	DISPLAY_ParamTypeDef displayParam;
	unsigned char setPointTempX2;
	ADC_READING* adcReading;
	DRV_StateTypedef* drvState;
	DRV_SettingTypeDef* drvSetting;
	DRV_StructTypeDef* drvStruct;
	SETTINGS_HandleTypeDef* settings;
	DISPLAY_StructTypeDef* display;
	REMOTE_StructTypeDef* remote;
	REMOTE_KEY remotePressedKey;
	KEY pressedKey;
	KEY_PRESS_TYPE pressType;
	TIMER_HandleTypeDef timer;
	APP_ErrorTypeDef appError;
	uint32_t errorTot;
	uint32_t errorTotLast;
	signed char errorNum;
	unsigned short warningTot;
	signed char warningNum;
	signed char warningNumLast;
	TIMING_StructTypedef timingStandby;
	TIMING_StructTypedef timingValve;
	TIMING_StructTypedef displayParamComingOut;
	TIMING_StructTypedef displayParamUpdate;
	TIMING_StructTypedef timingUpdateDisplay;
	TIMING_StructTypedef timingAutoPowerOn;
	TIMING_StructTypedef testComingOut;
	TIMING_StructTypedef testPump;
	uint8_t testModeReg;
	unsigned short maxMotorPower;
	BUZZER_StateTypeDef buzzerState;
	uint8_t LcdStandByContrastLevel;
	uint8_t LcdNormalContrastLevel;
	TEMP_CompenationTypeDef compOff;
	TEMP_CompenationTypeDef compOn;
	float tempCalib;	// calibration offset
	float tempComp;		// compensated temperature
}APP_STATE;

extern APP_STATE appState;
extern volatile uint8_t appTimingFlags;

void APP_Init(void);
void APP_Check_Timing(void);
void APP_Handle_TimingFlags(void);
void APP_Handle_Key(void);
void APP_Handle_Remote(void);
unsigned char APP_Handle_Auto(void);
void APP_UpdateDisplay(void);
void APP_UpdateDisplay_Temp(void);
unsigned char APP_UpdateDisplay_Is_Needed(void);
void APP_Aggregate_Error(void);
void APP_Calculate_Error_Number(void);
unsigned char APP_Check_Error(void);
void APP_Aggregate_Warning(void);
void APP_Calculate_Warning_Number(void);
unsigned char APP_Handle_RCCB(void);
void APP_Calculate_Compensated_Temp(void);
void APP_Buzzer_Play(void);
void APP_Buzzer_Play_Time(Buzzer_OnTimeTypeDef onTime);
void APP_Handle_Buzzer(void);
void APP_Clear_PressedKey(void);
unsigned char APP_DisplayParam_Read(void);
void APP_Load_Parameters(void);

#endif /* OTHER_LIB_INC_APPLICATION_H_ */
