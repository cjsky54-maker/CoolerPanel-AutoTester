/*
 * settings.c
 *
 *  Created on: May 9, 2026
 *      Author: Mohammad Hossein
 */

#include "settings.h"
#include "variables.h"


#define FIRST_INDEX			0
#define START_INDEX                     1
#define MAX_INDEX_BASIC	        	9
#define MIN_INDEX_ADVANCED      	20
#define MAX_INDEX_ADVANCED	PARAMS_NUM - 1

const uint16_t paramMinValue[PARAMS_NUM] = {0, 0, 1, 1, 15,  0, 0,   1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,  0,  60, 0,  1};
const uint16_t paramMaxValue[PARAMS_NUM] = {1, 1, 3, 3, 120, 1, 100, 8, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 50, 100, 1, 30};
const uint8_t paramStepValue[PARAMS_NUM] = {1, 1, 1, 1, 15,  1, 1,   1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,  5,   5, 1,  1};
uint16_t paramDefValue[EEPROM_USED_LEN] =  {0, 1, 3, 2, 60,  1, 50,  4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 100, 1,  5,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 70, 32, 422};
const uint8_t paramHasFraction[PARAMS_NUM] = {0};
const uint8_t paramNumIcon[PARAMS_NUM] =  {DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF,
										   DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_DEGREE, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF,
										   DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF,
										   DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF,
										   DISP_NUM_ICON_OFF, DISP_NUM_ICON_PERCENT, DISP_NUM_ICON_PERCENT, DISP_NUM_ICON_OFF, DISP_NUM_ICON_OFF};

SETTINGS_HandleTypeDef settingsHandle;

//private functions
void SETTINGS_Update_Parameter(ChangeTypeDef change);
void SETTINGS_Update_Value(ChangeTypeDef change);
void SETTINGS_Reset_Factory(void);

void SETTINGS_Init(void)
{
	unsigned char i;
	settingsHandle.index = START_INDEX;
	settingsHandle.state = SETTINGS_STAT_PARAM;
	settingsHandle.needSave = 0;
	settingsHandle.timingBack.limit = 10000;
	settingsHandle.timingComeOut.limit = 60000;
	settingsHandle.advancedMode = OFF;
	settingsHandle.learnStat = LEARN_NO;
	for(i=0;i<PARAMS_NUM;i++)
	{
		settingsHandle.value[i] = reg[i];
	}
        TIMING_Start(&settingsHandle.timingComeOut);
}

void SETTINGS_Toggle_Advance(void)
{
        if(settingsHandle.advancedMode == OFF)
        {
                settingsHandle.advancedMode = ON;
                settingsHandle.index = MIN_INDEX_ADVANCED;
        }
        else
        {
                settingsHandle.advancedMode = OFF;
                settingsHandle.index = START_INDEX;
        }
        settingsHandle.state = SETTINGS_STAT_PARAM;
        settingsHandle.learnStat = LEARN_NO;
        TIMING_Clear(&settingsHandle.timingBack);
        TIMING_Start(&settingsHandle.timingComeOut);
}

SETTINGS_HandleTypeDef* SETTINGS_Get_Handle(void)
{
	return &settingsHandle;
}

void SETTINGS_Load_Default(void)
{
	unsigned char i;
	for(i=0;i<=EEPROM_LEN;i++)
	{
		reg[i] = paramDefValue[i];
	}
}

void SETTINGS_Reset_Factory(void)
{
	unsigned char i;
	for(i=0;i<=PARAMS_NUM_USER;i++)
	{
		reg[i] = paramDefValue[i];
		settingsHandle.value[i] = paramDefValue[i];
	}
}

void SETTINGS_Clear_Remote(void)
{
	unsigned char i;
	for(i=0;i<REMOTE_NUM;i++)
	{
		reg[REMOTE_ADDRRES_1 + i] = 0;
	}
	settingsHandle.value[PARAM_CLEAR_REMOTES] = 0;
}

void SETTINGS_Save_Remote(unsigned short newAddr)
{
	unsigned char i;

	// return if remote is already saved
	if(REMOTE_IsSaved())
	{
		settingsHandle.learnStat = LEARN_DONE;
		return;
	}

	for(i=0;i<REMOTE_NUM;i++)
	{
		if((reg[REMOTE_ADDRRES_1+i] == 0x00))
		{
			reg[REMOTE_ADDRRES_1+i] = newAddr;
			settingsHandle.learnStat = LEARN_DONE;
			break;
		}
	}

	if(settingsHandle.learnStat == LEARN_PENDING)
	{
		for(i=1;i<REMOTE_NUM;i++)
		{
			reg[REMOTE_ADDRRES_1+i-1] = reg[REMOTE_ADDRRES_1+i];
		}
		reg[REMOTE_ADDRRES_1+REMOTE_NUM-1] = newAddr;
		settingsHandle.learnStat = LEARN_DONE;
	}

	settingsHandle.needSave = 1;
}

void SETTINGS_Update_Parameter(ChangeTypeDef change)
{
	if(change == CHANGE_DECREASE)
	{
		if(settingsHandle.index > FIRST_INDEX)
		{
			if(settingsHandle.index == MIN_INDEX_ADVANCED)
			{
				settingsHandle.index = MAX_INDEX_BASIC;
			}
			else
			{
				settingsHandle.index--;
			}
		}
//		else
//		{
//			if(settingsHandle.advancedMode == OFF)
//			{
//				settingsHandle.index = MAX_INDEX_BASIC;
//			}
//			else
//			{
//				settingsHandle.index = MAX_INDEX_ADVANCED;
//			}
//		}
	}
	else if(change == CHANGE_INCREASE)
	{
		if(settingsHandle.index < MAX_INDEX_ADVANCED)
		{
			if(settingsHandle.index == MAX_INDEX_BASIC)
			{
				if(settingsHandle.advancedMode == ON)
				{
					settingsHandle.index = MIN_INDEX_ADVANCED;
				}
//				else
//				{
//					settingsHandle.index = FIRST_INDEX;
//				}
			}
//			else if(settingsHandle.index == MAX_INDEX_ADVANCED)
//			{
//				settingsHandle.index = FIRST_INDEX;
//			}
			else
			{
				settingsHandle.index++;
			}
		}
	}
	settingsHandle.valueOngoing = settingsHandle.value[settingsHandle.index];
}

void SETTINGS_Update_Value(ChangeTypeDef change)
{
	TIMING_Start(&settingsHandle.timingBack);
	if(change == CHANGE_DECREASE)
	{
		if(settingsHandle.valueOngoing - paramMinValue[settingsHandle.index] >= paramStepValue[settingsHandle.index])
		{
			settingsHandle.valueOngoing -= paramStepValue[settingsHandle.index];
		}
		else if(settingsHandle.valueOngoing >= paramMinValue[settingsHandle.index])
		{
			settingsHandle.valueOngoing = paramMinValue[settingsHandle.index];
		}
	}
	else if(change == CHANGE_INCREASE)
	{
		if(paramMaxValue[settingsHandle.index] - settingsHandle.valueOngoing >= paramStepValue[settingsHandle.index])
		{
			settingsHandle.valueOngoing += paramStepValue[settingsHandle.index];
		}
		else if(paramMaxValue[settingsHandle.index] >= settingsHandle.valueOngoing)
		{
			settingsHandle.valueOngoing = paramMaxValue[settingsHandle.index];
		}
	}
}

void SETTINGS_Update_ParamVal(ChangeTypeDef change)
{
	if(settingsHandle.state == SETTINGS_STAT_PARAM)
	{
		SETTINGS_Update_Parameter(change);
	}
	else if(settingsHandle.state == SETTINGS_STAT_VALUE)
	{
		SETTINGS_Update_Value(change);
	}
	TIMING_Start(&settingsHandle.timingComeOut);
}

void SETTINGS_Perform_Change(void)
{
	if(settingsHandle.index == PARAM_CLEAR_REMOTES)
	{
		SETTINGS_Clear_Remote();
	}
	else if(settingsHandle.index == PARAM_RESET_FACTORY)
	{
		SETTINGS_Reset_Factory();
	}
	else
	{
		reg[settingsHandle.index] = settingsHandle.value[settingsHandle.index];
	}
	if(settingsHandle.index == PARAM_BRIGTHNESS)
	{
		Init_Display_Brightness(settingsHandle.value[settingsHandle.index]);
	}
}

void SETTINGS_Update_State(StepTypeDef step)
{
	if(step == STEP_BACK)
	{
		if(settingsHandle.state == SETTINGS_STAT_VALUE)
		{
			settingsHandle.valueOngoing = settingsHandle.value[settingsHandle.index];
		}
		else if(settingsHandle.state == SETTINGS_STAT_LEARN)
		{
			settingsHandle.learnStat = LEARN_NO;
		}
		settingsHandle.state = SETTINGS_STAT_PARAM;
		TIMING_Clear(&settingsHandle.timingBack);
	}
	else if(step == STEP_OK)
	{
		if(settingsHandle.state == SETTINGS_STAT_PARAM)
		{
			settingsHandle.state = SETTINGS_STAT_VALUE;
			settingsHandle.valueOngoing = settingsHandle.value[settingsHandle.index];
			TIMING_Start(&settingsHandle.timingBack);
		}
		else if(settingsHandle.state == SETTINGS_STAT_VALUE)
		{
			settingsHandle.state = SETTINGS_STAT_PARAM;
			TIMING_Clear(&settingsHandle.timingBack);
			if(settingsHandle.value[settingsHandle.index] != settingsHandle.valueOngoing)
			{
				settingsHandle.value[settingsHandle.index] = settingsHandle.valueOngoing;
				SETTINGS_Perform_Change();
				settingsHandle.needSave = 1;
			}
		}
	}
	TIMING_Start(&settingsHandle.timingComeOut);
}

void SETTINGS_Comming_Out(void)
{
	if(settingsHandle.needSave == 1)
	{
		writeRegToEeprom(EEPROM_START, EEPROM_LEN);
                settingsHandle.needSave = 0;
	}
	settingsHandle.state = SETTINGS_STAT_PARAM;
	TIMING_Clear(&settingsHandle.timingComeOut);
	TIMING_Clear(&settingsHandle.timingBack);
}

void SETTINGS_Learn_Init(void)
{
	settingsHandle.state = SETTINGS_STAT_LEARN;
	settingsHandle.learnStat = LEARN_PENDING;
	TIMING_Start(&settingsHandle.timingBack);
}
