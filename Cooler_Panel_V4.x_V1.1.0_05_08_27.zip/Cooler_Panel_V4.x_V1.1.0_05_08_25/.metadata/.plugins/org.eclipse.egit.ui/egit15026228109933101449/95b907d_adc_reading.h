/*
 * adc_reading.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_ADC_READING_H_
#define OTHER_LIB_INC_ADC_READING_H_

#include "main.h"

#define ADC1_CH_NUM		3
#define ADC1_CH_BUF_LEN		70
#define ADC1_BUF_LEN		ADC1_CH_NUM * ADC1_CH_BUF_LEN   //210

typedef enum
{
	ADC_ERROR_HIGH_VOLTAGE		= 1 << 0,
	ADC_ERROR_LOW_VOLTAGE		= 1 << 1,
	ADC_ERROR_OW_DISCONNECTED	= 1 << 2,
} ADC_Error;

typedef struct
{
	float vOW;							// measured One Wire Bus Voltage
	float vAC;							// measured AC voltage in V
	float temp;							// measured temperature in degree
        float temp2;							// measured temperature in degree
	float tempFiltered;					        // filtered measured temperature in degree
        float tempFiltered2;					        // filtered measured temperature in degree
	float adcAvg[ADC1_CH_NUM];		                	// average of ADC raw data
	unsigned long adcSum[ADC1_CH_NUM];	                        // sum of ADC raw data
	float adcVol[ADC1_CH_NUM];
	unsigned char error;				                // error in ADC parameters (ADC_ERROR_xxx)
	TIMING_StructTypedef errorClear;                                // Clear Low/High Voltage Error after x seconds
	TIMING_StructTypedef errorSet;		                        // Set One Wire Voltage Error after y seconds
	TIMING_StructTypedef startUp;
	PowerState state;
} ADC_READING;


void ADCR_Init(void);
unsigned short* ADCR_Get_Buffer(void);
ADC_READING* ADCR_Get_Struct(void);
void ADCR_CalculateTemp(void);
void ADCR_CalculateTemp2(void);
void ADCR_CalculateVac(void);

float interpolateTemp(float target);

#endif /* OTHER_LIB_INC_ADC_READING_H_ */
