#include "driver_protocol.h"
#include "string.h"
#include "main.h"


//IMC parameters
#define NUMBER_OF_IMC_CODE_VERSIONS         2       // we currently have 2 code versions
#define IMC_CODE_VERSION					1
#define APPID_OR_REGINDEX_SELECT            2       // choosing between app ip and register index
#define APP_ID                              0
#define REGISTER_INDEX                      1
#define DRV_MAX_RETRY_NUM					6

#define NUMBER_OF_DRIVER_COMMAND_TYPE       16

DRV_StructTypeDef drvStruct = {.rcvBuf = {0}, .busState = DRV_BUS_IDLE, .busRelease.limit = 100};
DRV_StateTypedef drvState = {.drvInitStat = DRV_STAT_NOT_INITED, .succeedPktTot = 0, .failPktTot = 0};
DRV_SettingTypeDef drvSetting;

// This Lookup Table is made for IMC registers indexes according to the IMC code version
const uint8_t addressTable[NUMBER_OF_IMC_CODE_VERSIONS][NUMBER_OF_DRIVER_COMMAND_TYPE][APPID_OR_REGINDEX_SELECT] =
{
		//    PFC          valve        PUMP        FAULT          VTH        GPIO       CTRL_MODE  STOP_START_CMD TARGET_SPEED TARGET_TRQ TARGET_power SCRIPT_CMD  LOAD_PARAM_CMD  SAVE_PARAM_CMD  DRV_REG_LIMIT_FLAG  DCBUS_VLT
		{{0x03,0x52}, {0x34,0x41}, {0x04,0x70}, {0x00,0x00}, {0x01,0x90}, {0x34,0x40}, {0x01,0x04}, {0x01,0x78}, {0x01,0x79}, {0x01,0x81}, {0xF1,0x00}, {0x04,0x01}, {0x22,0x00}, {0x21,0x00}, {0xF1,0x04}, {0x1B,0x45}},  // version 1  {app id, regindex}
		{{0x03,0x42}, {0x34,0x41}, {0x34,0x41}, {0x00,0x00}, {0x01,0x4C}, {0x34,0x40}, {0xF1,0x02}, {0x01,0x40}, {0xF1,0x00}, {0xF1,0x00}, {0xF1,0x00}, {0x04,0x40}, {0x22,0x00}, {0x21,0x00}, {0xF1,0x04}, {0x1B,0x45}}   // version 2  {app id, regindex}
};

// This Lookup Table is made for IMC Commands Delay (these delay prevents the micro from sending next command of the queue to the imc for specified time)
const uint8_t drvDelayTable[NUMBER_OF_DRIVER_COMMAND_TYPE] = {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 200, 30, 30, 200};	// in ms
const DRV_REG controlModeReg[4] = {DRV_REG_POWER, DRV_REG_SPEED, DRV_REG_TORQUE, DRV_REG_POWER};
Drv_PowerTypedef toggleState[3] = {DRV_PWR_ON, DRV_PWR_OFF, DRV_PWR_OFF};

//Private functions Prototype
void Drv_Deinit_State(void);
uint8_t Drv_Value_To_Percent(uint16_t value);
uint16_t Drv_Round_Percent(uint16_t percentX2);
uint16_t Drv_Generate_Data(DRV_REG reg, uint16_t regValue);
uint16_t Drv_Cal_CRC(uint8_t* buffer);
uint16_t Drv_Get_CRC(uint8_t* buffer);
void Drv_Generate_Packet(DRV_PACKET* packet);
DRV_REG Drv_Extract_Register(unsigned char* table);
void Drv_Fill_Analyze_Packet(unsigned char* buffer, DRV_PACKET* packet);
void Drv_Queue_Packet(uint16_t TimeOut, uint16_t Delay);
void Drv_Fill_Generate_Queue_Packet(DRV_CMD cmd, DRV_REG reg, uint16_t StatusOrValue);
void Drv_Send_Command(void);
unsigned char Drv_Is_Response_For_Command(void);
void Drv_Reset_Queue(void);
void Drv_Parse_Response(void);
unsigned int Drv_Calculate_Elapsed_Time(unsigned int startTime, unsigned int endTime);
void Drv_Update_Status_Bits(void);
void Drv_Update_Command_Bits(void);
void Drv_Set_BusBusy(void);

void Drv_Deinit_State(void)
{
	drvState.drvInitStat = DRV_STAT_NOT_INITED;
	drvState.runStat = DRV_RUN_STOP;
	drvState.pwrStat = DRV_PWR_OFF;
	drvState.pumpStat = DRV_PWR_OFF;
	drvState.valveStat = DRV_PWR_OFF;
	drvState.pfcStat = DRV_PWR_OFF;
	drvState.scriptStat = DRV_SCRIPT_ENABLE;
	drvState.ctrlModeStat = DRV_CTRL_MODE_SPEED;
	drvState.configStat = 0;
	drvState.succeedPktLast = 0;
	drvState.failPktLast = 0;
	drvState.actualPercentX2 = 0;
	drvState.errorLast = drvState.error;
	drvState.error = 0;
	drvState.errorValidated = 0;
	drvState.retryNum = 0;
}

void Drv_Init_State(void)
{
	drvState.pwrStat = DRV_PWR_OFF;
	drvState.runStat = DRV_RUN_STOP;
	drvState.pumpStat = DRV_PWR_OFF;
	drvState.valveStat = DRV_PWR_OFF;
	drvState.pfcStat = DRV_PWR_OFF;
	drvState.scriptStat = DRV_SCRIPT_ENABLE;
	drvState.ctrlModeStat = DRV_CTRL_MODE_SPEED;
	drvState.configStat = 0;
	drvState.drvTemp = 0;
	drvState.drvTempFiltered = 0;
	drvState.drvLimitFlag = 0;
	drvState.drvDcBusVoltage = 0;
	drvState.succeedPktLast = 0;
	drvState.failPktLast = 0;
	drvState.retryNum = 0;
	drvState.needClear = 0;
	drvState.resetRetryNum.limit = 13000;
	drvState.timeoutOff.limit = 4000;
}

void Drv_Deinit_Setting(void)
{
	drvSetting.pwrCmd = DRV_PWR_OFF;
	drvSetting.runCmd = DRV_RUN_STOP;
	Drv_Update_Command_Bits();
}

void Drv_Init_Setting(void)
{
	drvSetting.runCmd = DRV_RUN_STOP;
	drvSetting.pwrCmd = (Drv_PowerTypedef)FUNC_GET_BIT(reg[CMD_BITS], BITS_POWER);
	drvSetting.pumpCmd = (Drv_PowerTypedef)FUNC_GET_BIT(reg[CMD_BITS], BITS_PUMP);
	drvSetting.ctrlModeCmd = (DRV_ControlModeTypeDef)reg[PARAM_CONTROL_MODE];
	drvSetting.ctrlModeReg = controlModeReg[drvSetting.ctrlModeCmd];
	drvSetting.minPercent = reg[PARAM_MIN_PERCENT];
	drvSetting.maxPercent = reg[PARAM_MAX_PERCENT];
	drvSetting.configNum = 0;	// reg[PARAM_CONFIG_NUM]; the param is disabled
	drvSetting.scriptCmd = DRV_SCRIPT_STAT;
	drvSetting.direction = DRV_MOTOR_DIRECTION;
	drvSetting.setPointPercentX2 = reg[CMD_SETPOINT_PERCENT];
}

/**
 * @brief  scale percent (0~200) to value (0~4095)
 * 		   The 0 percent means min percent and 200 percent means max percent
 * @param  percentX2: the percent * 2
 * @retval the value equivalent to the percent
 */
uint16_t Drv_Percent_To_Value(uint16_t percentX2)
{
	uint16_t value;
	if(percentX2 == 0)
	{
		value = 0;
	}
	else
	{
		value = (uint32_t)percentX2 * (drvSetting.maxPercent - drvSetting.minPercent) / 200 + drvSetting.minPercent;
		value = (uint32_t)value * 4095 / 100;
	}
	return value;
}

/**
 * @brief  scale value (0~4095) to percent (0~200)
 * 		   The 0 percent means min percent and 200 percent means max percent
 * @param  value
 * @retval the percent * 2 equivalent to the value
 */
uint8_t Drv_Value_To_Percent(uint16_t value)
{
	uint32_t percentX2;

	if((int16_t)value < 0) // if the spin is in reverse mode then multiply the returned value by -1
	{
		value = (uint32_t)((uint16_t)value*(-1));
	}

	if(value < (drvSetting.minPercent * 4095 / 100))
	{
		percentX2 = 0;
	}
	else
	{
		percentX2 = ((uint32_t)value * 100 / 4095 - drvSetting.minPercent) * 200;
		percentX2 /= (drvSetting.maxPercent - drvSetting.minPercent);

		if(percentX2 > 200)
		{
			percentX2 = 200;
		}
	}

	percentX2 = Drv_Round_Percent(percentX2);

	return (uint8_t)percentX2;
}

/**
 * @brief  round percent to be multiply of 10 (2x5%)
 * @param  percentX2: the percent * 2
 * @retval the rounded percent
 */
uint16_t Drv_Round_Percent(uint16_t percentX2)
{
	uint16_t roundedPercent = percentX2;
	if ((roundedPercent % 10) >= 5)
	{
		roundedPercent += 5;
	}
	roundedPercent = (roundedPercent / 10) * 10;
	return roundedPercent;
}

/**
 * @brief  Generate data that should be sent to driver according to register & its value
 * @param  drvReg: the name of the register,
 * @param  regValue: the status or value of the corresponding register
 * @retval the value equivalent to the status to be sent to the driver
 */
uint16_t Drv_Generate_Data(DRV_REG drvReg, uint16_t regValue)
{
	if(drvReg == DRV_REG_PUMP || drvReg == DRV_REG_PFC)
	{
		if(regValue == ON)
		{
			return 0x0010;
		}
		else
		{
			return 0x0000;
		}
	}
	else if (drvReg == DRV_REG_VALVE)
	{
		if(regValue == ON)
		{
			return 0x0020;
		}
		else
		{
			return 0x0000;
		}
	}
	else if(drvReg == DRV_REG_SCRIPT)
	{
		if(regValue == ENABLE)
		{
			return 0x0011;
		}
		else
		{
			return 0x0000;
		}
	}
	else if(drvReg == DRV_REG_STOP_START)
	{
		if(regValue == DRV_RUN_START)
		{
			return 0x0001;
		}
		else
		{
			return 0x0000;
		}
	}
	else if(drvReg == DRV_REG_SPEED || drvReg == DRV_REG_TORQUE || drvReg == DRV_REG_POWER) // for this command percent of speed in scale (2*percent)
	{
		if(regValue == 0)
		{
			return 0x0000;
		}
		uint16_t value = Drv_Percent_To_Value(regValue);
		if(drvSetting.direction)
		{
			value *= -1;
		}
		return value;
	}
	else
	{
		return regValue;
	}
}

/**
 * @brief  this function calculate the received buffer crc
 * @param  buffer: data buffer which crc is calculated on it
 * @retval calculated CRC
 */
uint16_t Drv_Cal_CRC(uint8_t* buffer)
{
	uint32_t crc = 0;

	crc += buffer[0];
	crc += ((uint16_t)buffer[1]) << 8;
	crc += buffer[2];
	crc += ((uint16_t)buffer[3]) << 8;
	crc += buffer[4];
	crc += ((uint16_t)buffer[5]) << 8;
	crc = 65536 - crc;
	crc = ((crc & 0xff) << 8) + ((crc & 0xff00) >> 8);
	return (uint16_t)(crc & 0xffff);
}

/**
 * @brief  this function get the crc of received buffer
 * @param  buffer: data buffer which crc is extracted from it
 * @retval extracted CRC
 */
uint16_t Drv_Get_CRC(uint8_t* buffer)
{
	uint16_t crc = 0;

	crc = buffer[6];
	crc <<= 8;
	crc += buffer[7];
	return crc;
}

/**
 * @brief  this function fills the command buffer to be sent to the driver
 * @param  packet
 * @retval none
 */
void Drv_Generate_Packet(DRV_PACKET* packet)
{
	packet->buffer[0] = 0x01;
	packet->buffer[1] = packet->command;
	packet->buffer[2] = addressTable[IMC_CODE_VERSION][packet->regiser][APP_ID];
	packet->buffer[3] = addressTable[IMC_CODE_VERSION][packet->regiser][REGISTER_INDEX];
	packet->buffer[4] = lowByte(packet->data);
	packet->buffer[5] = highByte(packet->data);
	packet->crc = Drv_Cal_CRC(packet->buffer);
	packet->buffer[6] = highByte(packet->crc);
	packet->buffer[7] = lowByte(packet->crc);
}

DRV_REG Drv_Extract_Register(unsigned char* table)
{
	unsigned char i;
	DRV_REG reg = DRV_REG_NOPE;
	for(i=0;i<DRV_REG_NOPE;i++)
	{
		if(table[APP_ID] == addressTable[IMC_CODE_VERSION][i][APP_ID] && table[REGISTER_INDEX] == addressTable[IMC_CODE_VERSION][i][REGISTER_INDEX])
		{
			reg = (DRV_REG)i;
			break;
		}
	}
	return reg;
}

void Drv_Fill_Analyze_Packet(unsigned char* buffer, DRV_PACKET* packet)
{
	unsigned short crcCal;

	memcpy(packet->buffer, buffer, 8);
	packet->address = packet->buffer[0];
	packet->command = (DRV_CMD)packet->buffer[1];
	packet->table[0] = packet->buffer[2];
	packet->table[1] = packet->buffer[3];
	packet->regiser = Drv_Extract_Register(packet->table);
	packet->dataL = packet->buffer[4];
	packet->data = (packet->buffer[5] << 8) + packet->buffer[4];
	packet->crc = Drv_Get_CRC(packet->buffer);
	crcCal = Drv_Cal_CRC(packet->buffer);
	if(crcCal == packet->crc)
	{
		drvState.succeedPktLast++;
		drvState.succeedPktTot++;
		packet->rcvFlag = DRV_RCV_PACKET_NEW;
	}
	else
	{
		drvState.failPktLast++;
		drvState.failPktTot++;
	}
}

/**
 * @brief  if the queue is made before this function put commands at end of the queue , or if the queue inst made ,this function sends one command to driver
 * @param  packet,TimeOut: maximum time out for receiving driver response to the corresponding command , Delay: scale (1 menas 100ms) delay for sending current command (ex: 2 means micro will send the current command to driver after 200 ms )
 * @retval none
 */
void Drv_Queue_Packet(uint16_t TimeOut, uint16_t Delay)
{
	if(drvStruct.queueCnt < DRV_MAX_NUMBER_OF_CMDS)
	{
		memcpy(drvStruct.queueBuf[drvStruct.queueCnt], drvStruct.sendPkt.buffer, 8);
		drvStruct.queueBufTimeout[drvStruct.queueCnt] = TimeOut;
		drvStruct.queueBufDelay[drvStruct.queueCnt] = Delay;
		drvStruct.queueCnt++;
		Drv_Send_Command();
	}
}

/**
 * @brief  this function fills the driver packet
 * @param  packet, cmd: driver command like reading or writing or fault clearing or ..., reg: the address of register , data: data to be written in specific driver register
 * @retval none
 */
void Drv_Fill_Generate_Queue_Packet(DRV_CMD cmd, DRV_REG drv_reg, uint16_t StatusOrValue)
{
	uint16_t delay;

	drvStruct.sendPkt.command = cmd;
	drvStruct.sendPkt.regiser = drv_reg;
	drvStruct.sendPkt.data = Drv_Generate_Data(drv_reg, StatusOrValue);
	Drv_Generate_Packet(&drvStruct.sendPkt);

	// Delay Generation
	if(cmd == DRV_CMD_NOPE)
	{
		delay = StatusOrValue;
	}
	else
	{
		delay = drvDelayTable[drv_reg];
	}

	Drv_Queue_Packet(DRV_RSP_TIMEOUT, delay);
}

void Drv_Set_Power_Relay(Drv_PowerTypedef state)
{
	if(state == DRV_PWR_ON)
	{
		CMDs_PWR(CMD_REL_PWR, ON);
		drvState.pwrStat = DRV_PWR_ON;
	}
	else
	{
		CMDs_PWR(CMD_REL_PWR, OFF);
		Drv_Deinit_State();
		Drv_Reset_Queue();
	}
	Drv_Update_Status_Bits();
}

/**
 * @brief  sets the driver power ON or OFF according to the input
 * @param  Drv_PowerTypedef : DRV_PWR_OFF = 0, DRV_PWR_ON = 1, DRV_PWR_TOGGLE = 2
 * @param  Drv_RunTypeDef :  DRV_RUN_STOP = 0, DRV_RUN_START = 1
 * @retval none
 */
void Drv_Set_Power(Drv_PowerTypedef pwrCmd, Drv_RunTypeDef runCmd)
{
	drvSetting.pwrCmd = pwrCmd;
	if((drvSetting.pwrCmd == DRV_PWR_OFF) || (drvSetting.setPointPercentX2 == 0))
	{
		drvSetting.runCmd = DRV_RUN_STOP;
	}
	else
	{
		drvSetting.runCmd = runCmd;
	}
	Drv_Update_Command_Bits();

	// for Power ON
	if (drvSetting.pwrCmd == DRV_PWR_ON)
	{
		TIMING_Clear(&drvState.timeoutOff);

		if (drvState.drvInitStat == DRV_STAT_NOT_INITED)
		{
			// turn on the power relay
			Drv_Set_Power_Relay(DRV_PWR_ON);

			// wait for power on
			Drv_Fill_Generate_Queue_Packet(DRV_CMD_NOPE, DRV_REG_NOPE, 500); //10*50 ms delay

			// clear driver fault
			Drv_Fill_Generate_Queue_Packet(DRV_CMD_CLEAR_STATUS, DRV_REG_FAULT, 0x0000);

			// loading parameter into driver ram
			if(drvSetting.configNum != 0)
			{
				Drv_Fill_Generate_Queue_Packet(DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, drvSetting.configNum);
			}

			// disable scripting if script_CMD parameter is 0
			if(drvSetting.scriptCmd == DRV_SCRIPT_DISABLE)
			{
				Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_SCRIPT, drvSetting.scriptCmd);
			}

			// Update Pump Status
			Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_PUMP, drvSetting.pumpCmd);

			// Set Control Mode (Speed , Torque, Power)
			Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_CTRL_MODE_SELECT, drvSetting.ctrlModeCmd);

		}

		// Set The Setpoint
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, drvSetting.ctrlModeReg, drvSetting.setPointPercentX2);


		// Start/Stop Motor
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_STOP_START, drvSetting.runCmd);
	}
	// for Power OFF
	else
	{
		// Set the Setpoint to Zero
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, drvSetting.ctrlModeReg, 0x0000);

		// Stop Motor
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_STOP_START, DRV_RUN_STOP);
		if(drvSetting.pwrCmd == DRV_PWR_OFF)
		{
			if(drvState.timeoutOff.isCounting == 0)
			{
				Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_PUMP, DRV_PWR_OFF);
				TIMING_Start(&drvState.timeoutOff);
			}
		}
	}
}

/**
 * first command : setting speed or trq to 0
 * second command : stopping motor
 * third command : changing mode command
 */
/**
 * @brief  this function change the driver mode(speed or torque) this function stops the motor before changing the mode if the motor is rotating.
 * @param  mode: DRIVER_SPEED_CTRL_MODE or DRIVER_CURRENT_CTRL_MODE
 * @retval none
 */
void Drv_Set_Ctrl_Mode(uint8_t mode)
{
	// Stop The Motor
	Drv_Set_Power(DRV_PWR_ON, DRV_RUN_STOP);

	// Wait for Motor Stop
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_NOPE, DRV_REG_NOPE, 250);

	// Change The Mode
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_CTRL_MODE_SELECT, mode);

	// Wait for Mode Change
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_NOPE, DRV_REG_NOPE, 50);
}

/**
 * @brief  this function sets the setpoint
 * @param  Setpoint : desired motor speedSetpoint (SPEED OR TORQUE OR POWER MODE, NO DIFFERENCE, ALL MODES HAVE THE SAME SETPOINT)
 * @retval none
 */
void Drv_Set_Setpoint(void)
{
	if (drvState.actualPercentX2 != 0 && drvSetting.setPointPercentX2 == 0)
	{
		Drv_Set_Power(DRV_PWR_ON, DRV_RUN_STOP);
		return;
	}
	else if (drvState.actualPercentX2 == 0 && drvSetting.setPointPercentX2 != 0)
	{
		Drv_Set_Power(DRV_PWR_ON, DRV_RUN_START);
		return;
	}
	else if(drvState.actualPercentX2 == drvSetting.setPointPercentX2)
	{
		return;
	}

	Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, drvSetting.ctrlModeReg, (uint16_t)drvSetting.setPointPercentX2);
}

/**
 * @brief  this function set the motor speed direction according to the input (first the motor is stopped then it starts in desired direction)
 * @param  direction: demonstrates the motor spin direction
 * @retval none
 */
void Drv_Set_Direction(void)
{
	Drv_Set_Power(DRV_PWR_ON, DRV_RUN_STOP);
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_NOPE, DRV_REG_NOPE, 1000);
	Drv_Set_Power(DRV_PWR_ON, DRV_RUN_START);
}

/**
 * @brief  this function LOADS specified parameter set into driver RAM
 * @param  ParameterSetNumber: the number of parameter set
 * @retval none
 */
void Drv_Set_Parameter(uint16_t ParameterSetNumber)
{
	if(ParameterSetNumber != 0)
	{
		// Stop The Motor
		Drv_Set_Power(DRV_PWR_ON, DRV_RUN_STOP);

		// Wait for Motor Stop
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_NOPE, DRV_REG_NOPE, 250);

		// Load The Parameter Set
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_LOAD_PARAM, DRV_REG_LOAD_PARAM, ParameterSetNumber);
	}
}

/**
 * @brief  Turn ON/ Turn OFF the pump
 * @param  state: the new state of pump -> OFF/ON/TOGGLE
 * @retval none
 */
void Drv_Set_Pump(Drv_PowerTypedef state)
{
        if(FUNC_GET_BIT(drvState.drvLimitFlag, DRV_WARNING_WLS) == 0)
        {
                drvSetting.pumpCmd = state;
                if(drvSetting.pumpCmd == DRV_PWR_TOGGLE)
                {
                        drvSetting.pumpCmd = toggleState[drvState.pumpStat];
                }
                VAR_Update_Reg_Bits(CMD_BITS, drvSetting.pumpCmd, BITS_PUMP, 1);
                Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_PUMP, drvSetting.pumpCmd);
        }
}

/**
 * @brief  Turn ON/ Turn OFF the valve
 * @param  state: the new state of valve -> OFF/ON/TOGGLE
 * @retval none
 */
void Drv_Set_Valve(Drv_PowerTypedef state)
{
	unsigned char valvePump;
	drvSetting.valveCmd = state;
	if(drvSetting.valveCmd == DRV_PWR_TOGGLE)
	{
		drvSetting.valveCmd = toggleState[drvState.valveStat];
	}
	if(drvSetting.valveCmd == DRV_PWR_ON)
	{
		drvSetting.pumpCmd = DRV_PWR_OFF;
	}
	valvePump = (drvSetting.valveCmd << 1) + drvSetting.pumpCmd;
	VAR_Update_Reg_Bits(CMD_BITS, valvePump, BITS_PUMP, 2);
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_WRITE, DRV_REG_VALVE, drvSetting.valveCmd);
}

/**
 * @brief  add read fault command to queue
 * @param  none
 * @retval none
 */
void Drv_Read_Fault(void)
{
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_READ_STATUS, DRV_REG_FAULT, 0x0000);
}

/**
 * @brief  add read register command to queue
 * @param  none
 * @retval none
 */
void Drv_Read_Register(DRV_REG reg)
{
	Drv_Fill_Generate_Queue_Packet(DRV_CMD_READ, reg, 0x0000);
}

void Drv_Cal_DropRate(Drv_DropRateTypeDef type)
{
	if(type == DRV_DROPRATE_LAST)
	{
		if(drvState.succeedPktLast > 0)
		{
			drvState.droprateLastX10 = (drvState.succeedPktLast * 1000) / (drvState.succeedPktLast + drvState.failPktLast);
		}
		else
		{
			drvState.droprateLastX10 = 0;
		}
	}
	else
	{
		if(drvState.succeedPktTot > 0)
		{
			drvState.droprateTotX10 = (drvState.succeedPktTot * 1000) / (drvState.succeedPktTot + drvState.failPktTot);
		}
		else
		{
			drvState.droprateTotX10 = 0;
		}
	}
}

/**
 * @brief  this function validates and extracts the received command response buffer and sends the rest of the commands
 * @param  pucBuffer: this input is received buffer which is validated and parsed in this function
 * @retval none
 */
void Drv_Handle_Reception(unsigned char *pucBuffer)
{
	Drv_Set_BusBusy();
	drvStruct.rspReceived = DRV_REG_NOPE;
	memcpy(drvStruct.rcvBuf, pucBuffer, 8);
	DMA_RX_RECEPTION_RESET();
	Drv_Fill_Analyze_Packet(drvStruct.rcvBuf, &(drvStruct.rcvPkt)); // CRC CHECK IS INSIDE
	if(drvStruct.rcvPkt.rcvFlag == DRV_RCV_PACKET_NEW)       //IF CRC OK
	{
		drvStruct.rcvPkt.rcvFlag = DRV_RCV_PACKET_NO;
		Drv_Parse_Response();
		CLEAR_BIT(drvState.error, Connection_Fault);
		if(drvStruct.sendStat == DRV_SEND_STAT_WAIT_RESP && Drv_Is_Response_For_Command())
		{
			drvStruct.retryCnt = 0;
			if(drvStruct.queueBufDelay[drvStruct.queueInd] == 0)
			{
				drvStruct.queueInd++;
				drvStruct.sendStat = DRV_SEND_STAT_IDLE;
				Drv_Send_Command();
			}
			else
			{
				drvStruct.sendStat = DRV_SEND_STAT_WAIT_RUN;
				TIMING_Set_Limit(&drvStruct.timingDelay, drvStruct.queueBufDelay[drvStruct.queueInd]);
				TIMING_Start(&drvStruct.timingDelay);
			}
		}

	}
}

/**
 * @brief  this function checks if a response to the previous command was received in the certain time then sends the rest of the commands
 * @param  none
 * @retval none
 */
void Drv_Handle_Timeout(void)
{
	if(drvStruct.sendStat == DRV_SEND_STAT_WAIT_RESP)
	{
		if(TIMING_Check(&drvStruct.timingTimeout))
		{
			drvStruct.retryCnt++;
			if(drvStruct.retryCnt <= DRV_RSP_MAX_RETRY_COUNT)
			{
				drvState.failPktLast++;
				drvState.failPktTot++;
				drvStruct.sendStat = DRV_SEND_STAT_IDLE;
				Drv_Send_Command();
			}
			else
			{
				drvStruct.retryCnt = 0;
				Drv_Reset_Queue();
				SET_BIT(drvState.error, Connection_Fault);
			}
		}
	}
	else if(drvStruct.sendStat == DRV_SEND_STAT_WAIT_RUN)
	{
		if(TIMING_Check(&drvStruct.timingDelay))
		{
			drvStruct.queueInd++;
			drvStruct.sendStat = DRV_SEND_STAT_IDLE;
			Drv_Send_Command();
		}
	}
	else if(drvStruct.sendStat == DRV_SEND_STAT_ERROR_BUSY)
	{
		// ToDo: the number of send tries should be counted
		drvStruct.sendStat = DRV_SEND_STAT_IDLE;
		Drv_Send_Command();
	}
}

/**
 * @brief this function will sends driver the commands queued in the buffer
 * @param  pucBuffer: the 8-byte command pointer is given to be sent via uart channel 1
 * @retval none
 */
void Drv_Send_Command(void)
{
	unsigned char sendStart;
	if(drvStruct.sendStat == DRV_SEND_STAT_IDLE)
	{
		if(drvStruct.queueInd < drvStruct.queueCnt)
		{
			if(drvStruct.queueBuf[drvStruct.queueInd][1] == DRV_CMD_NOPE)
			{
				TIMING_Set_Limit(&drvStruct.timingDelay, drvStruct.queueBufDelay[drvStruct.queueInd]);
				TIMING_Start(&drvStruct.timingDelay);
				drvStruct.sendStat = DRV_SEND_STAT_WAIT_RUN;
			}
			else
			{
				DMA_RX_RECEPTION_RESET();
				sendStart = UART1_Send_DMA((char*)drvStruct.queueBuf[drvStruct.queueInd], 8);
				if(sendStart == 1)
				{
					drvStruct.sendStat = DRV_SEND_STAT_SENDING;
					Drv_Set_BusBusy();
				}
				else
				{
					drvStruct.sendStat = DRV_SEND_STAT_ERROR_BUSY;
				}
			}
		}
		else
		{
			Drv_Reset_Queue();
		}
	}
}

void Drv_Handle_Send(void)
{
	Drv_Set_BusBusy();
	drvStruct.sendStat = DRV_SEND_STAT_WAIT_RESP;
	TIMING_Set_Limit(&drvStruct.timingTimeout, drvStruct.queueBufTimeout[drvStruct.queueInd]);
	TIMING_Start(&drvStruct.timingTimeout);
}

DRV_StateTypedef* Drv_Get_State(void)
{
	return &drvState;
}

DRV_SettingTypeDef* Drv_Get_Setting(void)
{
	return &drvSetting;
}

DRV_StructTypeDef* Drv_Get_Struct(void)
{
	return &drvStruct;
}

unsigned char Drv_Is_Response_For_Command(void)
{
	if(drvStruct.rcvPkt.command == (drvStruct.queueBuf[drvStruct.queueInd][1]+ 0x80))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void Drv_Reset_Queue(void)
{
	drvStruct.sendStat = DRV_SEND_STAT_IDLE;
	drvStruct.queueInd = 0;
	drvStruct.queueCnt = 0;
}

/**
 * @brief  this function extracts the received buffer and operates the needed functionalities such as(updating registers , turning on or off the driver, clearing faults and ect)
 * @param  buffer: the received buffer to be extracted
 * @retval none
 */
void Drv_Parse_Response(void)
{
	if(drvStruct.rcvPkt.command == DRV_RSP_CLEAR_STATUS)
	{
		drvState.error &= 0xFE0000;
	}
	else if(drvStruct.rcvPkt.command == DRV_RSP_READ)
	{
		if(drvStruct.rcvPkt.regiser == DRV_REG_VTH)
		{
			// Driver Temp Calculation
			drvState.drvTemp = Drv_Calculate_Ntc_Temp(drvStruct.rcvPkt.data);

			if(drvState.drvTempFiltered == 0)
			{
				drvState.drvTempFiltered = drvState.drvTemp;
			}
			drvState.drvTempFiltered = 0.8*drvState.drvTempFiltered + 0.2*drvState.drvTemp;
			VAR_Set_Reg(STAT_TEMP_DRV, (unsigned short)(drvState.drvTempFiltered*10));
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_LIMIT_FLAG)
		{
			drvState.drvLimitFlag = drvStruct.rcvPkt.dataL;
			VAR_Set_Reg(STAT_WARNING, drvState.drvLimitFlag);
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_DC_BUS_VOLTAGE)
		{
			drvState.drvDcBusVoltage = drvStruct.rcvPkt.data*10;
			drvState.drvDcBusVoltage /= 61;
			VAR_Set_Reg(STAT_VOL_PFC, drvState.drvDcBusVoltage);
		}
	}

	else if(drvStruct.rcvPkt.command == DRV_RSP_WRITE)
	{
		if(drvStruct.rcvPkt.regiser == DRV_REG_PUMP)
		{
			if(drvStruct.rcvPkt.dataL == 0x20) // Valve ON
			{
				drvState.pumpStat = DRV_PWR_OFF;
				drvState.valveStat = DRV_PWR_ON;
			}
			else if(drvStruct.rcvPkt.dataL == 0x10) // Pump ON		former value was :0x27
			{
				drvState.pumpStat = DRV_PWR_ON;
				drvState.valveStat = DRV_PWR_OFF;
			}
			else if(drvStruct.rcvPkt.dataL == 0x00) // Both OFF		former value was :0x28
			{
				drvState.pumpStat = DRV_PWR_OFF;
				drvState.valveStat = DRV_PWR_OFF;
			}
			Drv_Update_Status_Bits();
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_STOP_START)
		{
			if(drvStruct.rcvPkt.dataL == DRV_RUN_STOP)
			{
				drvState.runStat = DRV_RUN_STOP;
				drvState.actualPercentX2 = 0;
				VAR_Set_Reg(STAT_PERCENT, drvState.actualPercentX2);
			}
			else if(drvStruct.rcvPkt.dataL == DRV_RUN_START)
			{
				drvState.runStat = DRV_RUN_START;
				drvState.drvInitStat = DRV_STAT_INITED;
			}
			Drv_Update_Status_Bits();
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_PFC)
		{
			if(drvStruct.rcvPkt.dataL == 0x1)
			{
				drvState.pfcStat = DRV_PWR_ON;
			}
			else if(drvStruct.rcvPkt.dataL == 0x0)
			{
				drvState.pfcStat = DRV_PWR_OFF;
			}
			Drv_Update_Status_Bits();
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_SPEED || drvStruct.rcvPkt.regiser == DRV_REG_TORQUE || drvStruct.rcvPkt.regiser == DRV_REG_POWER)
		{
			drvState.actualPercentX2 = Drv_Value_To_Percent(drvStruct.rcvPkt.data);
			VAR_Set_Reg(STAT_PERCENT, drvState.actualPercentX2);
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_CTRL_MODE_SELECT)
		{
			if(drvStruct.rcvPkt.dataL == 0x01 || drvStruct.rcvPkt.dataL == 0x02 || drvStruct.rcvPkt.dataL == 0x03)
			{
				drvState.ctrlModeStat = (DRV_ControlModeTypeDef)drvStruct.rcvPkt.dataL;
			}
		}
		else if(drvStruct.rcvPkt.regiser == DRV_REG_SCRIPT)
		{
			if(drvStruct.rcvPkt.dataL == 0x11)
			{
				drvState.scriptStat = DRV_SCRIPT_ENABLE;
			}
			else if(drvStruct.rcvPkt.dataL == 0x00)
			{
				drvState.scriptStat = DRV_SCRIPT_DISABLE;
			}
		}
	}
	//parameter loading and saving
	else if(drvStruct.rcvPkt.command == DRV_RSP_LOAD_PARAM)//ToDo: the same work as Motor Ctrl Mode response (its' todo) can be done here
	{
		if(drvStruct.rcvPkt.regiser == DRV_REG_LOAD_PARAM)
		{
			drvState.configStat = drvStruct.rcvPkt.dataL; //0x00 -> load done  0x01,0x02 -> load failed
			if(drvStruct.rcvPkt.dataL == 0x00) // load done
			{
//				appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1] = appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
//				reg[DRIVER_CONFIG_NUM] = appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
//				eepromWriteData(DRIVER_CONFIG_NUM, (uint8_t*)&reg[DRIVER_CONFIG_NUM], 2);
			}
			else if(drvStruct.rcvPkt.dataL == 0x01 ||drvStruct.rcvPkt.dataL == 0x02) // load failed
			{
//				appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1] = appSettings.parameterConfirmedValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
//				reg[DRIVER_CONFIG_NUM] = appSettings.parameterValue[DRIVER_CONFIG_NUM - START_OF_PARAMS + 1];
//				LCD_Glass_Update_By_State();
			}
		}
//		if(drvStruct.rcvPkt.regiser == DRV_REG_SAVE_PARAM)
//		{
//		}
	}
	else if(drvStruct.rcvPkt.command == DRV_RSP_READ_STATUS)
	{
		drvState.error &= 0xFF0000;
		drvState.error |= drvStruct.rcvPkt.data;
		if(drvStruct.rcvPkt.data != 0)
		{
			drvState.runStat = DRV_RUN_STOP;
		}
	}
	drvStruct.rspReceived = drvStruct.rcvPkt.regiser;
}

/**
 * @brief  Calculate the driver temperature according to adcAvg value recieved from driver ntc
 * @param  buffer: recieved 2byte driver ntc data
 * @retval return the calculated temp
 */
float Drv_Calculate_Ntc_Temp(uint16_t buffer)
{
	float vlt, res ;
	vlt = ((float)buffer) * 5/4096;
	res = (1000.0 * vlt) / (5 - vlt);
	return interpolateTemp(res);
}

void Drv_Reset_RetryNum(void)
{
	if(drvState.error == 0)
	{
		drvState.retryNum = 0;
		drvState.errorValidated = 0;
	}
}

// This function should be called after check fault response is received
void Drv_Handle_Error(void)
{
	if(drvState.error == 0)
	{
		if(drvState.resetRetryNum.isCounting == 0 && drvState.retryNum)
		{
			TIMING_Start(&drvState.resetRetryNum);
		}
	}
	else
	{
		TIMING_Clear(&drvState.resetRetryNum);
		if(drvState.retryNum < DRV_MAX_RETRY_NUM)
		{
			drvState.retryNum ++;
			drvState.needClear = 1;
		}
		else
		{
			drvState.errorValidated = drvState.error;
		}
	}
	drvState.errorLast = drvState.error;
}

void Drv_Handle_Warning(void)
{
        if(FUNC_GET_BIT(drvState.drvLimitFlag, DRV_WARNING_WLS))
        {
                drvState.pumpStat = DRV_PWR_OFF;
        }
}

void Drv_Clear_If_Needed(void)
{
	if(drvState.needClear == 1)
	{
		Drv_Fill_Generate_Queue_Packet(DRV_CMD_CLEAR_STATUS, DRV_REG_FAULT, 0x0000);
		drvState.needClear = 0;
	}
}

void Drv_Clear_Fault(void)
{
	drvState.errorValidated = 0;
	drvState.retryNum = 0;
	Drv_Handle_Error();
	Drv_Clear_If_Needed();
}

void Drv_Handle_Conflict(void)
{
	if(drvState.errorValidated == 0)
	{
		if(drvState.runStat != drvSetting.runCmd)
		{
			Drv_Set_Power(drvSetting.pwrCmd, drvSetting.runCmd);
		}
		else if((drvState.pumpStat != drvSetting.pumpCmd)) 
		{
			Drv_Set_Pump(drvSetting.pumpCmd);
		}
	}
}

void Drv_Update_Status_Bits(void)
{
	unsigned short status = 0;
	status |= (drvState.pwrStat << BITS_POWER);
	status |= (drvState.runStat << BITS_RUN);
	status |= (drvState.pumpStat << BITS_PUMP);
	status |= (drvState.valveStat << BITS_VALVE);
	status |= (drvState.pfcStat << BITS_PFC);
	VAR_Update_Reg_Bits(STAT_BITS, status, 0, 5);
}

void Drv_Update_Command_Bits(void)
{
	unsigned short command = 0;
	command |= (drvSetting.pwrCmd << BITS_POWER);
	command |= (drvSetting.runCmd << BITS_RUN);
	command |= (drvSetting.pumpCmd << BITS_PUMP);
	command |= (drvSetting.valveCmd << BITS_VALVE);
	VAR_Update_Reg_Bits(CMD_BITS, command, 0, 4);
}

unsigned char Drv_IsBusIdle(void)
{
	if(drvStruct.busState == DRV_BUS_IDLE)
	{
		return 1;
	}
	return 0;
}

void Drv_Set_BusBusy(void)
{
	drvStruct.busState = DRV_BUS_BUSY;
	TIMING_Start(&drvStruct.busRelease);
}

void Drv_Check_BusRelease(void)
{
	if(TIMING_Check_WhenCounting(&drvStruct.busRelease))
	{
		drvStruct.busState = DRV_BUS_IDLE;
	}
}
