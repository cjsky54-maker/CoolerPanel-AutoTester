/*
 * variables.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Masoud Shahrabi
 */

#ifndef VARIABLES_H_
#define VARIABLES_H_
   

#define varLen			100
#define writableVarLen	        50

extern unsigned short reg[varLen];


// writable

#define ID				1       // 2 registers
#define IDMODEL                         3       // 2 registers
#define POWER                           5
#define PUMP                            6
#define AUTO_MODE                       7
#define SPEED_SETPOINT                  8
#define TEMPERATURE_SETPOINT            9
#define CURRENT_SETPOINT                10
#define CLEAR_FAULT                     11       // it auto clears
#define CURRENT_CONTROL_MODE            12
#define SPEED_MIN_PERCENT               13       // this register is not used any more(used in SETTING_PARAMETER_6_VALUE)
#define SPEED_MAX_PERCENT               14       // this register is not used any more(used in SETTING_PARAMETER_7_VALUE)
#define CURRENT_MIN_PERCENT             15
#define CURRENT_MAX_PERCENT             16
#define PFC                             17
#define KEY_LOCKED                      18
//#define YEAR			        19
//#define MONTH				20
//#define DAY				21
//#define HOUR				22
//#define MINUTE		        23
//#define SECOND			24

#define TIME                            19      // 2 registers

#define DAY_W_DATE                      21      // 2 registers

#define TIME_W_ON                       23      // 2 registers

#define TIME_W_OFF                      25      // 2 registers

#define TIME_D_ON                       27      // 2 registers

#define TIME_D_OFF                      29      // 2 registers

#define LCD_STANDBY_CONTRAST_LEVEL      31
#define LCD_NORMAL_CONTRAST_LEVEL       32
#define FIRST_BOOT_IS_PASSED            33
#define FIRST_BOOT_FLAG_AFTER_POWERON   34

//setting parameters value
#define buzzer_status                   35      // SETTING_PARAMETER_1_VALUE
#define lcd_brightness_level            36      // SETTING_PARAMETER_2_VALUE
#define lcd_standby_brightness_level    37      // SETTING_PARAMETER_3_VALUE
#define lcd_standBy_time                38      // SETTING_PARAMETER_4_VALUE
#define temp_calibration_setpoint       39      // SETTING_PARAMETER_5_VALUE     in terms of 0.1 degree
#define SPEED_MIN_PERCENT_REG           40      // SETTING_PARAMETER_6_VALUE
#define SPEED_MAX_PERCENT_REG           41      // SETTING_PARAMETER_7_VALUE
#define TRQ_MIN_PERCENT                 42      // SETTING_PARAMETER_8_VALUE
#define TRQ_MAX_PERCENT                 43      // SETTING_PARAMETER_9_VALUE
#define MOTOR_CONTROL_MODE              44      // SETTING_PARAMETER_10_VALUE     0:speedControl and 1:torqueControl
#define MOTOR_SPIN_DIRECTION            45      // SETTING_PARAMETER_11_VALUE     0:forward and 1:Reverse
#define REMOTE_LEARN                    46      // SETTING_PARAMETER_12_VALUE     (if this parameter is 1 learning remote is available by pressing remote key )
#define AUTO_POWER_ON                   47      // SETTING_PARAMETER_13_VALUE     : auto power on after the power is connected if motor was unexpectedly turned off
#define ENV_OR_DRIVER_TEMP_SHOW         48      // SETTING_PARAMETER_14_VALUE     0 : environment Ntc Temperature    1: driver NTC temperature
#define DRIVER_SCRIPT_EN                49      // SETTING_PARAMETER_15_VALUE     0 : driver Scripting Disable       1: driver Scripting Enabled
#define IMC_CODE_VERSION                50      // SETTING_PARAMETER_16_VALUE     IMC code firmWare version: 0: old     1: New
#define DRIVER_CONFIG_NUM               51      // SETTING_PARAMETER_17_VALUE     we are able to choose betwen 14 different driver configs(these configs are written in driver micro and we tell driver to work with the one we choose)
#define RESET_FACTORY                   52      // SETTING_PARAMETER_18_VALUE     resets the parameters to their default values
#define FIRMWARE_VERSION                53      // SETTING_PARAMETER_19_VALUE     shows the code firmWare version

// readable
#define SPEED                           54
#define TEMPERATURE                     55
#define DRIVERTEMPERATURE               56 
#define FAULTS                          57      // 2 registers
#define SW_VERSION                      59
#define HW_VERSION                      60
#define TORQUE                          61

// defined values
#define CODE_VERSION                    10  
#define DEFUALT_MIN_CURR_PERCENT        185     // in tenth of percent, is less than 1.5 ampere
#define DEFUALT_MAX_CURR_PERCENT        625     // in tenth of percent, is equal to 5 ampere
#define DEFUALT_TEMP_CALIB_SETPOINT     50      // it means 0 if setpoint is 51 then value(51-50)/10 is added to calculated temp
#define MAX_KEY_LOCK_TIMEOUT            4+1     // in seconds ( 4 seconds is for key timeout (1 is added to timeout right after pressing the lock buttoms "1 isnt counted as 1 second")
#define MAX_POWER_OFF_TRY_COUNT         4       // maximum number of tries for turning off motor if timed-out error exist
#define SPEED_CONTROL_MODE              0
#define TRQ_CONTROL_MODE                1
#define DRIVER_SPEED_CTRL_MODE          0
#define DRIVER_CURRENT_CTRL_MODE        1
#define MAX_LEARN_TIME                  5
#define MAX_LEARNED_KEYS_RESET_TIME     8


#endif /* VARIABLES_H_ */