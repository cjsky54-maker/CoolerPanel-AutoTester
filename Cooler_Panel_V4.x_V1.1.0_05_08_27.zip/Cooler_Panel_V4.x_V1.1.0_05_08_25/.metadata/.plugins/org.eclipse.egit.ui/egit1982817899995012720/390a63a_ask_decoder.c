#include "ask_decoder.h"
#include "functions.h"

#define TIMx_GetOnTime()                TIM1_GetCapture1()
#define TIMx_GetPeriod()                TIM1_GetCapture2()
#define TIMx_ITConfig_CCx(NewState)     TIM1_ITConfig(TIM1_IT_CC2, NewState)

#define PERIOD_MIN      1050    // Minimum accepted period (in us)
#define PERIOD_MAX      1700    // Maximum accepted period (in us)
#define DUTY_0_MIN      0.15     // Minimum accepted
#define DUTY_0_MAX      0.34     // Minimum accepted
#define DUTY_1_MIN      0.65     // Minimum accepted
#define DUTY_1_MAX      0.84     // Minimum accepted



/**
  * @brief  Clears ASK_PACKET variables & enables CCx interrupt to start Reception
  * @note   Should be called inside update IRQ Handler
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_StartReception(ASK_PACKET* askPacket)
{   
    askPacket->performRemoteNow = ASK_Check_To_Perform_Remote_Operations(askPacket);
    if(askPacket->index == 0)
    {
      askPacket->pressDuration = 0;
      askPacket->numOfReceivedCorrectPacket = 0;
      askPacket->packetIgnoreCounter = NUMBER_OF_DATA_IGNORE + 1;
      askPacket->status = ASK_STAT_RELEASED;
      for(uint8_t cnt = 0 ; cnt < MAX_NUMBER_OF_ADDR_FOR_REMOTE_SAVE ; cnt++)
      {
        askPacket->sigAddrTemp[cnt] = 0;
      }
    }
    askPacket->index = 0;
    askPacket->sigTot = 0;
    askPacket->sigAddr = 0;
    askPacket->sigData = 0;
    askPacket->rcvFlag = 0;
    TIMx_ITConfig_CCx(ENABLE);
}


/**
  * @brief  Check every recieved pulse to decode the signal
  * @note   Should be called inside CCx IRQ Handler
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_HandleReception(ASK_PACKET* askPacket)
{
  
  askPacket->onTime[askPacket->index] = TIMx_GetOnTime();
  askPacket->period[askPacket->index] = TIMx_GetPeriod();
//  askPacket->onTime = TIMx_GetOnTime();
//  askPacket->period = TIMx_GetPeriod(); // Reading period clear CCx peinding interrupt bit
  if(askPacket->index > 1)
  {
    if (askPacket->period[askPacket->index] > PERIOD_MIN && askPacket->period[askPacket->index] < PERIOD_MAX)
    {
      askPacket->duty = (float)askPacket->onTime[askPacket->index]/(float)askPacket->period[askPacket->index];
      if(askPacket->duty > DUTY_0_MIN && askPacket->duty < DUTY_0_MAX)
      {
        askPacket->sigTot <<= 1;
      }
      else if(askPacket->duty > DUTY_1_MIN && askPacket->duty < DUTY_1_MAX)
      {
        askPacket->sigTot <<= 1;
        askPacket->sigTot |= 1;
      }
      else
      {
        TIMx_ITConfig_CCx(DISABLE);
        askPacket->noiseCnt++;
        return;
      }
    }
    else
    {
      TIMx_ITConfig_CCx(DISABLE);
      askPacket->noiseCnt++;
      return;
    }
  }
    
  askPacket->index++;
  if(askPacket->index== 25)
  {
    askPacket->sigData = askPacket->sigTot & 0xF;
    askPacket->sigAddr = askPacket->sigTot >> 8;
    askPacket->rfRegClearTimer = RF_REG_CLEAR_TIMEOUT;
    reg[RF_KEY] = askPacket->sigData;
    
    askPacket->status = ASK_STAT_PRESSED;
    askPacket->pressDuration++;

    // update last parameters
    askPacket->lastIndex = askPacket->index;
    askPacket->lastSigTot = askPacket->sigTot;
    askPacket->lastSigAddr = askPacket->sigAddr;
    askPacket->lastSigData = askPacket->sigData;
    askPacket->lastPressDuration = askPacket->pressDuration;
    
    if(!getAppSettingsLearnKeyTimeout())
    {
      askPacket->rcvFlag = 1;
    }
    else if(getAppSettingsLearnKeyTimeout() && !ASK_IsRemoteSaved(askPacket))
    {
       if(ASK_SaveRemote(askPacket))
        setAppSettingsLearnKeyTimeout(1);
    }
  }
}


/**
  * @brief  Saves the remote control code to the EEPROM if valid data is received.
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
uint8_t ASK_SaveRemote(ASK_PACKET* askPacket)
{
  for(uint8_t cnt = 0 ; cnt < MAX_NUMBER_OF_ADDR_FOR_REMOTE_SAVE ; cnt++) // fill the sigaddrtemp with the last 5 addresses
  {
    if(askPacket->sigAddrTemp[cnt] == 0)
    {
      askPacket->sigAddrTemp[cnt] = askPacket->lastSigAddr;
      break;
    }
  }
  if(askPacket->sigAddrTemp[MAX_NUMBER_OF_ADDR_FOR_REMOTE_SAVE - 1] != 0) // if the addrtemp is filled completely
  {
    unsigned short addreasToSave = findTheMostRepeatedValue(askPacket->sigAddrTemp ,MAX_NUMBER_OF_ADDR_FOR_REMOTE_SAVE);
    for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
    {
      if((reg[START_OF_REMOTE_ADDRESS + cnt] == 0x00) || (cnt == NUMBER_OF_REMOTES - 1))
      {
        reg[START_OF_REMOTE_ADDRESS + cnt] = addreasToSave;
        return eepromWriteData(START_OF_REMOTE_ADDRESS + cnt,(uint8_t*)&addreasToSave,2);
      }
    }
  }
  return 0;
}


/**
  * @brief  checks if the remote which its data received is saved to EEPROM .
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
uint8_t ASK_IsRemoteSaved(ASK_PACKET* askPacket)
{
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    if(reg[START_OF_REMOTE_ADDRESS + cnt] == askPacket->lastSigAddr)
      return 1;
  }
  return 0;
}

/**
  * @brief  reads NUMBER_OF_REMOTES words from EEPROM to remoteAddresses[] .
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_ReadRemoteAddressesFromEepromToReg(void)
{
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    eepromReadData(START_OF_REMOTE_ADDRESS + cnt,(uint8_t*)&reg[START_OF_REMOTE_ADDRESS + cnt],2);
  }
}


/**
  * @brief  clear saved remotes from the reg and EEPROM .
  * @param  None
  * @retval None
  */
void ASK_ClearRemoteAddresses(void)
{
  eepromClear(START_OF_REMOTE_ADDRESS, NUMBER_OF_REMOTES);
  for(uint8_t cnt = 0 ; cnt < NUMBER_OF_REMOTES ; cnt++)
  {
    reg[START_OF_REMOTE_ADDRESS + cnt] = 0;
  }
  ushortResetBit(&reg[IO_CONTROL_REG],IO_RF_CLEAR);
//  reg[IO_CONTROL_REG] &= ~(uint16_t)IO_RF_CLEAR;
//  reg[IO_CONTROL_REG] &= 0xFFFF - IO_RF_CLEAR;
}


/**
  * @brief  This function is called inside ASK_Perform_Remote_Operations to check whether its the time to perform operation or not.
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
uint8_t ASK_Check_To_Perform_Remote_Operations(ASK_PACKET* askPacket)
{
  if(askPacket->packetIgnoreCounter <= NUMBER_OF_DATA_IGNORE)
  {
    askPacket->packetIgnoreCounter ++;
  }
  
  if(askPacket->rcvFlag == 1 && ASK_IsRemoteSaved(askPacket))
  {
    askPacket->numOfReceivedCorrectPacket ++;
#if REMOTE_TYPE == (WHITE || BW)
    if((askPacket->numOfReceivedCorrectPacket == FIRST_ACCEPTABLE_PACKET_NUM && ((askPacket->lastSigData == REMOTE_POWER_CODE) || (askPacket->lastSigData == REMOTE_PUMPON_CODE) || (askPacket->lastSigData == REMOTE_PUMPOFF_CODE) || (askPacket->lastSigData == REMOTE_AUTOON_CODE) || (askPacket->lastSigData == REMOTE_AUTOOFF_CODE))) || ((askPacket->packetIgnoreCounter > NUMBER_OF_DATA_IGNORE) && ((askPacket->lastSigData == REMOTE_UP_CODE) || (askPacket->lastSigData == REMOTE_DOWN_CODE))) )
    {
      askPacket->packetIgnoreCounter = 0;
      return 1;
    }
#elif REMOTE_TYPE == BLACK
    if((askPacket->numOfReceivedCorrectPacket == FIRST_ACCEPTABLE_PACKET_NUM && ((askPacket->lastSigData == REMOTE_POWER_CODE) || (askPacket->lastSigData == REMOTE_PUMP_CODE) || (askPacket->lastSigData == REMOTE_AUTO_CODE) )) || ((askPacket->packetIgnoreCounter > NUMBER_OF_DATA_IGNORE) && ((askPacket->lastSigData == REMOTE_UP_CODE) || (askPacket->lastSigData == REMOTE_DOWN_CODE))) )
    {
      askPacket->packetIgnoreCounter = 0;
      return 1;
    }
#endif
  }
  return 0;
}
  

/**
  * @brief  This function is called in corresponding interrupt handler once the signal is received.
  * @param  askPacket pointer to a ASK_PACKET structure
  * @retval None
  */
void ASK_Perform_Remote_Operations(ASK_PACKET* askPacket)
{
  if(askPacket->performRemoteNow)
  {
    
    Buzzer_Operation(Remote);
    Perform_Remote_Operations(askPacket->lastSigData);
    //lcd refreshing
    LCD_Glass_Update_By_State();
    setLcdIsInStandby(0);
    setLcdStandByTimer(0);
    LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast());
    askPacket->performRemoteNow = 0;
  }
}

void ASK_Rf_Reg_Clear(ASK_PACKET* askPacket)
{
  if(askPacket->rfRegClearTimer > 0)
    askPacket->rfRegClearTimer -=1;
  if(askPacket->rfRegClearTimer == 0)
    reg[RF_KEY] = 0;
}