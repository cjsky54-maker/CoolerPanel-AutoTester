/*
 * business_logic.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Masoud Shahrabi
 */

#ifndef BUSINESS_LOGIC_H_
#define BUSINESS_LOGIC_H_

#include "stm8l15x_conf.h"
#include "time.h"
#include "driver_protocol.h"
#include "initialization.h"
#include "lcd_seg.h"
#include "variables.h"
   
#define TEMP_SP_MIN             20
#define TEMP_SP_MAX             35
   
//#define RETRY_COUNT_MAX         3
#define AUTO_MODE_COUNT_MAX     2       // in seconds
   
#define TIMER_CHANGING_TIMEOUT_MAX      8       // in seconds
#define SETTING_CHANGING_TIMEOUT        6       // in seconds
#define SETTING_MODE_TIMEOUT            10      // in seconds
#define NUMBER_OF_SETTING_PARAMETERS    END_OF_PARAMS - 35    // 25 is the number of parameters and 1 is for register to be started from section 1...
#define READ_FAULT_PERIOD               5       // in seconds
#define READ_TEMP_PERIOD                2       // in seconds
#define SETTING_ACTIVATION_TIME         160     //(0.025 seconds * 160 periods = 4 seconds)
#define CLOCK_CLEAR_MAX_TIMEOUT         100     // 100 * 25 ms (counter is counted each 25ms)

#if REMOTE_TYPE == WHITE
  #define REMOTE_POWER_CODE               4
  #define REMOTE_UP_CODE                  6
  #define REMOTE_DOWN_CODE                2
  #define REMOTE_PUMPON_CODE              9
  #define REMOTE_PUMPOFF_CODE             0xE
  #define REMOTE_AUTOON_CODE              5
  #define REMOTE_AUTOOFF_CODE             3
#elif REMOTE_TYPE == BLACK
  #define REMOTE_POWER_CODE               8
  #define REMOTE_UP_CODE                  4
  #define REMOTE_DOWN_CODE                0xC
  #define REMOTE_PUMP_CODE                2
  #define REMOTE_AUTO_CODE                0XA
#endif
//#define SPEED_MIN_MAX_STEP              1

typedef enum
{
  Lock,
  Touch,
  Valve,
  None,
} Buzzer_Type;


typedef enum
{
  Cooler = 0,
  Thermal = 1,
} Thermal_Or_Cooler;


typedef struct
{
  uint8_t continuesUpPressTimeout;
  uint8_t continuesDownPressTimeout;
  uint8_t autoMode;
  Thermal_Or_Cooler thermalOrCoolerMode;
  uint8_t speedSetPoint;        // in 0.5 percent
  uint8_t tempSetPoint;         // in 0.5 degrees
  uint8_t currentSetPoint;      // ?
  uint8_t bleConnected;
  uint8_t wifiConnected;
  uint8_t pumpOn;
  uint8_t valveOn;
  uint8_t powerOn;
  uint8_t pfcOn;
  Fault fault;
  uint8_t actualSpeed;          // in 0.5 percent
  float actualTemp;
  float showableTemp;
  uint16_t tempOffsetTimerOn;
  uint16_t tempOffsetTimeOut;
  uint16_t tempOffsetTimerOff;
  uint8_t driverReceiveFlag;
  float tempOffsetOff;
  float tempOffsetOn;
  float tempOffset;
  float tempOffsetOnStep1;
  float tempOffsetOnStep2;
  float driverActualTemp;
  uint8_t limitFlag;
  uint16_t driverDcBusVoltage;
   
//  uint8_t timerOn;
  uint8_t timerChangingTimeout; // in seconds
//  uint16_t powerTimeout;        // in seconds
  uint8_t timerConfirm;
  
  uint8_t currentControlMode;
  uint16_t speedMinPercent;     // in 0.1 percent
  uint16_t speedMaxPercent;
//  uint16_t speedMaxDriver;
  uint16_t currentMinPercent;
  uint16_t currentMaxPercent;
//  uint16_t currentMaxDriver;
  
  uint8_t weekActiveDays;    // bit 0: none, bit 1: monday, bit 2: tuesday, ... , bit 7 satarday
//  uint8_t weekHourOn;
//  uint8_t weekMinuteOn;
//  uint8_t weekSecondOn;
//  uint8_t weekHourOff;
//  uint8_t weekMinuteOff;
//  uint8_t weekSecondOff;
  int32_t weekTimeOn;
  int32_t weekTimeOff;
  
//  uint8_t yearOn;
//  uint8_t monthOn;
//  uint8_t dayOn;
//  uint8_t hourOn;
//  uint8_t minuteOn;
//  uint8_t secondOn;
//  uint8_t yearOff;
//  uint8_t monthOff;
//  uint8_t dayOff;
//  uint8_t hourOff;
//  uint8_t minuteOff;
//  uint8_t secondOff;
  time_t dayTimeOn;
  time_t dayTimeOff;
  uint8_t clockClrTimeOut;
  
  time_t nowTime;
  time_t dayRefTime;
  
  uint8_t pendingOff;
  uint8_t pendingOn;
  
  uint8_t speedMinChangingTimeout;
  uint8_t speedMaxChangingTimeout;
  
  uint8_t keyLock;
  uint8_t keyLockTimeOut;
  uint8_t startLearnTimeOut;
  uint8_t keyLockBlink;
  uint8_t keyBlinkTimeOut;
  
  uint8_t actualTorque;
  uint8_t autoModeCtr;
  uint8_t readFaultCtr;
  uint8_t readStatusCtr;
  uint8_t settingsTouched;
  uint8_t pumpTouched;
  uint8_t autoTouched;
  uint8_t valveTimeout;
  uint8_t lcdIsInStandby;
  uint8_t lcdStandByTimer;
  uint16_t drvStartTimeOut; // if after specific time like 5 sec of starting Drv an error occurs then , fault will be cleared and drv will be turned on again
  uint8_t drvStartTry; // number of times that is tried to start the drv with out fault
  uint32_t globalSucceedPackets;
  uint32_t globalFailPackets;
  uint32_t localSucceedPackets;
  uint32_t localFailPackets;
  // pressed keys flags
  uint8_t autoFlag;
  uint8_t pumpFlag;
  uint8_t powerFlag;
  uint8_t speedSetpointFlag;
  uint8_t tempSetpointFlag;
  unsigned char disNum;
  
} App_State;

typedef struct
{
  uint8_t keyPowerPressFlag ;
  uint8_t settingModeEnable;
  uint8_t settingChangingTimeout;
  uint8_t settingModeTimeout;
  uint8_t learnKeyTimeout;
  uint8_t timerConfirm;
  uint8_t parameterSelecting;
  uint8_t parameterValueSetting;
  uint16_t currentParameter;
  uint8_t waitingForDrvResponse;
  uint16_t parameterValue[NUMBER_OF_SETTING_PARAMETERS];
  uint16_t parameterConfirmedValue[NUMBER_OF_SETTING_PARAMETERS];
} App_Settings;

typedef struct tm tm;

void Deinit_Appstate();
void Deinit_Appsettings();
// KEYS PERFORMANCES
void Perform_Touch_Operations(uint8_t* touches, uint8_t press);
void Perform_Continues_Key_Press();
void Perform_Key_Up_Down(KEY_TYPE key_type);
void Perform_Key_Clock();
void Perform_Key_Power();
void Perform_Key_Pump(uint8_t immidiate);
void Perform_Key_Valve();
void Perform_Key_Auto();
void Perform_Key_Setting();
void Valve_OR_TermalMode_TurningOn_TimeOut();
void Valve_Operation_TimeOut();
void Receive_Packet_Accuracy_Calculation();
void Buzzer_Operation(Buzzer_Type buzzerType);
void Buzzer_TimeOut();
void Perform_Remote_Operations(uint8_t rfOut);
void Set_Auto_Speed(uint8_t immediately);
uint16_t Drv_Calculate_Percent(void);
uint8_t Drv_Calculate_Real_Percent(void);
void Check_Timer();
void Clear_Clock_TimeOut();
void Check_Settings_Operations();
void Check_Fault();
void Check_Drv_Status();
void Check_Drv_Temp();
void Check_Drv_Dc_Bus_Voltage();
void LockingLcdTimeoutCounter();
void startLearnTimeoutCounter();
void SettingStartUpTimeoutCounter();
void LearnKeyOperation(uint8_t task); // task 0:learn off , task 1:learn on , task 2:reset learned remotes
void Calendar_Init(void);
uint8_t Is_Timer_Active_Today();
void Making_Date_And_Time();
void LCD_GLASS_UPDATE_PARAMETER_VALUE(App_Settings appSettings);
void LCD_GLASS_7SEGMENTS_5AND6_VALUE_CALCULATOR(uint16_t value, uint8_t percentStatus,uint8_t degreeStatus , uint16_t scale); // for 7segments number 5 and 6
void LCD_GLASS_UPDATE_SETTING_PAGE(void);  // this function is used to update the setting page every seconds if the setting is enabled
void LCD_GLASS_UPDATE_CURRENT_PARAMETER_NUMBER(App_Settings appSettings);
void LCD_GLASS_UPDATE_STANDBY();
void LCD_Glass_Play_Demo();
void LCD_Glass_Update_By_State();
void KeyBlinkTimeOut();
void Reset_Registers_And_Eeprom_To_Factory_Values();
void Reset_Setting_Parameters_To_Default_Values();
void Update_Ram_Registers_With_Eeprom_Datas();
void disconnectCounter();
void updateTempOffsetTimeOut();  
void tempOffsetGenerator();

LCD_DeadTime_TypeDef LCD_GLASS_Normal_Contrast();
LCD_DeadTime_TypeDef LCD_GLASS_Standby_Contrast();


void setLcdStandByTimer(unsigned char newVal);
unsigned char getLcdStandByTimer();
void setLcdIsInStandby(unsigned char newVal);
unsigned char getLcdIsInStandby();
void setAppSettingsTimerConfirm(uint8_t newVal);
uint8_t getAppSettingsTimerConfirm();
App_State* getAppState();
void setAppStateBleConnected(uint8_t newVal);

//tm Get_DateTime(int year, int month, int day, int hours, int minutes, int seconds);
//tm Get_Off_DateTime();
//tm Get_On_DateTime();
//tm Get_Now_DateTime();


#endif /* BUSINESS_LOGIC_H_ */
