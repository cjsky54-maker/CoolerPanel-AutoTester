/*
 * business_logic.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Masoud Shahrabi
 */

#ifndef DRIVER_PROTOCOL_H_
#define DRIVER_PROTOCOL_H_

#include "stm8l15x_conf.h"



#define DRIVER_RESPONSE_RETRY_COUNT               16
#define DRIVER_RESPONSE_TIMEOUT                   25       // in ms
#define DRIVER_CHECKFAULT_AFTER_START_TIMEOUT     1000      // 5sec = 500*10 in ms
#define MAX_DRV_START_RETRY                       5
#define MAX_NUMBER_OF_CMDS                        10
#define DC_BUS_VOLTAGE_LOWER_HAZARD               360
#define DC_BUS_VOLTAGE_UPPER_HAZARD               380
   


#define START                           1
#define STOP                            0

typedef enum
{
  Driver_Current_Mismatch,
  Motor_Gatekill,
  DC_Bus_Critical_Overvoltage,
  DC_Bus_Overvoltage,
  DC_Bus_Under_Voltage,
  Flux_PLL_Out_Of_Control,
  Reserved1,
  Over_Temperature,
  Rotor_Lock,
  Phase_Loss,
  Reserved2,
  Execution_Fault,
  Reserved3,
  Parameter_Load_Fault,
  UART_Link_Break_Fault,
  Hall_Timeout_Fault,
  Hall_Invalid_Fault,
  Timeout_Fault,
  CRC_Fault,
  Wrong_Format,
  Ac_Voltage_Range_High,
  Ac_Voltage_Range_Low,
  No_Fault,
} Fault;

typedef enum
{
  DRV_CMD_READ_STATUS = 0x00,
  DRV_CMD_CLEAR_STATUS = 0x01,
  DRV_CMD_READ = 0x05,
  DRV_CMD_WRITE = 0x06,
  DRV_CMD_LOAD_PARAM = 0x20,
  DRV_CMD_NOPE = 0xFF,
}DRV_CMD;

typedef enum
{
  DRV_REG_PFC = 0,
  DRV_REG_PUMP = 1,
  DRV_REG_VALVE = 2,
  DRV_REG_FAULT = 3,
  DRV_REG_VTH = 4,
  DRV_REG_GPIO = 5,
  DRV_REG_CTRL_MODE_SELECT = 6,
  DRV_REG_STOP_START = 7,
  DRV_REG_SPEED = 8,
  DRV_REG_TORQUE = 9,
  DRV_REG_POWER = 10,
  DRV_REG_SCRIPT = 11,
  DRV_REG_LOAD_PARAM = 12,
  DRV_REG_SAVE_PARAM = 13,
  DRV_REG_LIMIT_FLAG = 14,
  DRV_REG_DC_BUS_VOLTAGE = 15,
  DRV_REG_NOPE = 16,
}DRV_REG;

typedef struct
{
  DRV_CMD command;		
  DRV_REG regiser;		
  uint16_t data;		
  uint16_t crc;
  uint8_t  buffer[8];			// Buffer for reception of packet
} DRV_PACKET;

void Drv_Generate_Packet(DRV_PACKET* packet);
void Drv_Fill_Generate_Send_Packet(DRV_PACKET* packet, DRV_CMD cmd, DRV_REG reg, uint16_t StatusOrValue);
void Drv_Send_Packet(DRV_PACKET* packet, uint16_t TimeOut, uint8_t Delay);
uint16_t Drv_Generate_Data(DRV_REG reg, uint16_t regValue);

void Drv_Power(uint8_t state);
void Drv_LifeGuard_Action();
void Drv_Ctrl_Mode_Select(uint8_t mode);
void Drv_Set_Speed(uint8_t speed);
void Drv_Set_direction(); // direction 1: reverse mode and direction 0: straight mode
void Drv_Parameter_command(uint16_t ParameterSetNumber);
uint16_t Drv_Get_CRC(uint8_t* buffer);
void Drv_Response_Received(unsigned char *pucBuffer);
void Drv_Start_Activity_Timeout();
void Drv_Activity_Timeout();
void Drv_Send_Command(void);
void Drv_Parse_Response(uint8_t* buffer);
float Drv_Calculate_Ntc_Temp(uint16_t buffer);
char* Payload_Generator();
char* Payload_Deinit_Generator();
void Drv_AcInRange_Check();

/////// setter getters ///////
void Drv_Set_Skip_PowerOn(uint8_t newVal);
uint8_t Drv_Get_Queue_Command_Cnt(void);
uint8_t Drv_Get_is_Pending(void);
float Drv_Get_Actual_Temp(void);
uint8_t Get_Timer_Changing_TimeOut(void);
uint8_t Get_Wifi_Auto_Connect(void);
void Drv_Set_oneWirePhysicallyConnected(uint8_t newval);
void Drv_Set_acVoltageInRange(uint8_t newval);
float Drv_Get_AC_Voltage(void);
#endif /* DRIVER_PROTOCOL_H_ */