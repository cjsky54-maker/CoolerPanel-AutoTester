/*
 * adc_reading.h
 *
 *  Created on: Feb 6, 2020
 *      Author: Mohammad Hossein
 */

#ifndef OTHER_LIB_INC_ADC_READING_H_
#define OTHER_LIB_INC_ADC_READING_H_

#define ADC_CH_NUM      3 
#define ADC_CH_BUF_LEN  50
   
typedef struct
{
  float temp;		                // the temprature in degree
  float owVol;                          // the open wire voltage in V
  float acVol;                          // the AC voltage in V
  float adcAvg[ADC_CH_NUM]; 	        // average of ADC raw data
  unsigned long adcSum[ADC_CH_NUM];     // sum of ADC raw data
} ADC_READING;
   
int findIndex(float target_resistance); 
float interpolateTemp(float target); 
void adc1AveragingBuffer(unsigned short* ADCConvertedValue, ADC_READING* adcReading);
void calculateVoltageTemp(ADC_READING* adcReading); //should be called second in a loop

#endif /* OTHER_LIB_INC_ADC_READING_H_ */
