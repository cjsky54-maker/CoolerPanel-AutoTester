#include "protocol.h"
#include "variables.h"
#include "functions.h"
#include "business_logic.h"
#include "driver_protocol.h"
#include "time.h"

unsigned short reg[varLen];

uint8_t idModelChanged = 0;

extern App_State appState;
extern App_Settings appSettings;

extern RTC_TimeTypeDef   RTC_TimeStr;
extern RTC_DateTypeDef   RTC_DateStr;


// Packet Format:
// Header(2), Length(2), Address(2), Command(2), Register(2), Number of Registers(2), Data(0~2*n), CRC(2)
// AA-BB-00-0E-00-10-00-02-00-01-00-01-00-22
/**
  * @brief  
  * @param  dataPacket: raw packet to be filled with data such as (Header-Length-Address-Command-Register-Number of Registers-Data-CRC)
  * @retval None
  */
void generatePacket(PACKET *dataPacket)
{
	unsigned short i;
	// Add header to Packet
	dataPacket->buffer[0] = 0xAA;
	dataPacket->buffer[1] = 0xBB;

	// calculate packet length and add it
	switch(dataPacket->command)
	{
	case RESPONSE:
		dataPacket->length = 14+2*dataPacket->numReg;
		break;
	case READ:
		dataPacket->length = 14;
		break;
	case WRITE:
		dataPacket->length = 14+2*dataPacket->numReg;
		break;
	case WRITEOK:
		dataPacket->length = 16;
		break;
	}
	dataPacket->buffer[2] = highByte(dataPacket->length);
	dataPacket->buffer[3] = lowByte(dataPacket->length);

	// Add address & command to packet
	dataPacket->buffer[4] = highByte(dataPacket->address);
	dataPacket->buffer[5] = lowByte(dataPacket->address);

	dataPacket->buffer[6] = highByte(dataPacket->command);
	dataPacket->buffer[7] = lowByte(dataPacket->command);

	// convert register to 2 byte and add it to packet
	dataPacket->buffer[8] = highByte(dataPacket->regiser);
	dataPacket->buffer[9] = lowByte(dataPacket->regiser);

	// Add number of registers to packet
	dataPacket->buffer[10] = highByte(dataPacket->numReg);
	dataPacket->buffer[11] = lowByte(dataPacket->numReg);

	// Convert data words to 2 bytes and add them to packet
	if(dataPacket->command == RESPONSE || dataPacket->command == WRITE)
	{
		for(i=0;i<dataPacket->numReg;i++)
		{
			dataPacket->buffer[12+2*i] = highByte(dataPacket->data[i]);
			dataPacket->buffer[13+2*i] = lowByte(dataPacket->data[i]);
		}
	}
        else if(dataPacket->command == WRITEOK)
	{
		dataPacket->buffer[12] = highByte(dataPacket->data[0]);
		dataPacket->buffer[13] = lowByte(dataPacket->data[0]);
	}

	// Calculate crc and add it to packet (crc -> Sum of all packet bytes except header and crc
	dataPacket->crc = 0;
	for(i=2;i<dataPacket->length-2;i++)
	{
		dataPacket->crc += dataPacket->buffer[i];
	}
	dataPacket->buffer[dataPacket->length-2] = highByte(dataPacket->crc);
	dataPacket->buffer[dataPacket->length-1] = lowByte(dataPacket->crc);
}


/**
  * @brief  Returns Reception complete flag 
  * @param  rxPacket: fill raw packet with received data
  * @retval None
  */
unsigned char  receivePacket(PACKET *rxPacket)
{
	unsigned char receptionComplete = 0;
	if(rxPacket->mode == 0)
	{
		if(rxPacket->buffer[0] == 0xAA)
		{
			rxPacket->mode = 1;
			rxPacket->index = 1;
		}
		if(rxPacket->buffer[0]=='O')
		{
			rxPacket->mode = 100;
			rxPacket->index = 1;
		}
	}
	else if(rxPacket->mode == 1)
	{
		if(rxPacket->buffer[1] == 0xBB)
		{
			rxPacket->mode = 2;
			rxPacket->index = 2;
		}
		else
		{
			rxPacket->mode = 0;
			rxPacket->index = 0;
		}
	}
	else if(rxPacket->mode == 2)
	{
		rxPacket->mode = 3;
		rxPacket->index = 3;
	}
	else if(rxPacket->mode == 3)
	{
		rxPacket->length = rxPacket->buffer[2]*256+rxPacket->buffer[3];
		// check packet length limit
		if(rxPacket->length < 1024)
		{
			rxPacket->mode = 4;
			rxPacket->index = 4;
		}
		else
		{
			rxPacket->mode = 0;
			rxPacket->index = 0;
		}
	}
	else if(rxPacket->mode == 4)
	{
		if(rxPacket->index == rxPacket->length-1)
		{
			receptionComplete = 1;	// received our packet
			rxPacket->mode = 0;
			rxPacket->index = 0;
		}
		else
		{
			rxPacket->index++;
		}
	}
	else if(rxPacket->mode == 100)
	{
		if(rxPacket->buffer[1]=='K')
		{
			rxPacket->index = 2;
			rxPacket->mode = 101;
		}
		else
		{
			rxPacket->index = 0;
			rxPacket->mode = 0;
		}
	}
	else if(rxPacket->mode == 101)
	{
		if (rxPacket->buffer[rxPacket->index]=='\r')
		{
			rxPacket->mode = 102;
		}
		if (rxPacket->index<10)
		{
			rxPacket->index++;
		}
		else
		{
			rxPacket->mode = 0;
			rxPacket->index=0;
		}

	}
	else if(rxPacket->mode == 102)
	{
		if (rxPacket->buffer[rxPacket->index]=='\n')
		{
			rxPacket->buffer[rxPacket->index+1] = 0;
			receptionComplete = 2;	// received AT command
		}
		rxPacket->mode = 0;
		rxPacket->index=0;
	}
	// if mode goes beyond accepted values, reset packet
	else
	{
		rxPacket->mode = 0;
		rxPacket->index = 0;
	}
	rxPacket->timeOut = 0;
	return receptionComplete;
}

/**
  * @brief  (if the the received packet state remains in state 1 or 2 longer than the desirable timeout then ,it resets the received parameters)or(if the time out from received packet is more than the desirable value while the mode isnt 0 then reset received parameters)
  * @param  rxPacket:received packet    timeOutNum: desirable timeout
  * @retval None
  */
void timeoutReception(PACKET *rxPacket, unsigned char timeOutNum)
{
	if (rxPacket->mode != 0)
	{
		rxPacket->timeOut++;
		if(rxPacket->timeOut > timeOutNum)
		{
			rxPacket->mode = 0;
			rxPacket->index = 0;
			rxPacket->timeOut = 0;
		}
	}
}


/**
  * @brief  this function checks the probably received packet error and Returns error code
  * @param  dataPacket: recevied packet for checking if there is any error or not
  * @retval None
  */
unsigned char analysePacket(PACKET* dataPacket)
{
	unsigned short i;
	// Check header of packet
	if(dataPacket->buffer[0] == 0xAA && dataPacket->buffer[1] == 0xBB)
	{
		// Check crc
		dataPacket->crc = 0;
		for (i=2;i<dataPacket->length-2;i++)
		{
			dataPacket->crc += dataPacket->buffer[i];
		}
		if(dataPacket->crc == (dataPacket->buffer[dataPacket->length-2] * 256 + dataPacket->buffer[dataPacket->length-1]))
		{
			dataPacket->address = dataPacket->buffer[4] * 256 + dataPacket->buffer[5];
			dataPacket->command = dataPacket->buffer[6] * 256 + dataPacket->buffer[7];
			dataPacket->regiser = dataPacket->buffer[8] * 256 + dataPacket->buffer[9];
			dataPacket->numReg = dataPacket->buffer[10] * 256 + dataPacket->buffer[11];
			if (dataPacket->numReg > maxDataPacketLength)
                                return ERROR_PCKT_LEN;	// Data length error

			for(i=0;i<dataPacket->numReg;i++)
			{
				dataPacket->data[i] = dataPacket->buffer[12+2*i]*256+dataPacket->buffer[13+2*i];
			}
			return 0;	// No Error
		}
		else
		{
			return ERROR_PCKT_CRC;	// CRC Error
		}
	}
	else
	{
		return ERROR_PCKT_HEADER;	// Header Error
	}
}

/**
  * @brief  this function sets server params and registers values according to received data
  * @param  inPacket: received packet       outPacket: packet to be filled for being sent to the server
  * @retval None
  */
void executePacket(PACKET* inPacket, PACKET *outPacket)
{
	unsigned short i;
	unsigned char writeOK = 1, writeNum = 0, writeError = 0;
	unsigned short lastReg = 0;
//	uint8_t idChanged = 0;
        uint8_t writeFailed = 0;
//	uint8_t simFlashWriteFailed = 0;
//	uint8_t paramsFlashWriteFailed = 0;
//	uint8_t writableFlashParamChanged = 0;

//	// Bootloader variables
//	unsigned char flashStatus;
	unsigned short packData[2];
//	unsigned int version, common, command;
//	ERRORSTATUS errorStat = {.errorSource = 0, .errorDetails = 0};
//
//	uint8_t eeFlashStatus = 0;

	if(inPacket->address == boardAddress)
	{
		// return requested data
		if(inPacket->command == READ)
		{
			lastReg = inPacket->regiser + inPacket->numReg;
			// Check register range
			if (lastReg < varLen)
			{
				for(i=0;i<inPacket->numReg;i++)
				{
					outPacket->data[i] = reg[inPacket->regiser+i];
				}
				fillGeneratePacket(outPacket, RESPONSE, inPacket->regiser, inPacket->numReg, outPacket->data);
			}
//			else
//			{
//				// Read WrittenOkStatus which is placed in address = 0x1000
//				if(inPacket->regiser == 0x1000 && inPacket->numReg<257)
//				{
//					for(i=0;i<inPacket->numReg;i++)
//					{
//						outPacket->data[i] = halfWord(writtenOkStatus, 2*i, LSB_FIRST);
//					}
//					fillGeneratePacket(outPacket, RESPONSE, inPacket->regiser, inPacket->numReg, outPacket->data);
//				}
//			}
		}
		else if(inPacket->command == WRITE)
		{
			lastReg = inPacket->regiser + inPacket->numReg;
			// Check register range
			if (lastReg < varLen)
			{
				//Check if parameters are writable & write them
				if(lastReg < writableVarLen)
				{
//					FLASH_Unlock();
					for(i=0;i<inPacket->numReg;i++)
					{
                                          if(((inPacket->regiser + i == IO_CONTROL_REG) && !(inPacket->data[i] & IO_Manual_Bit)))
                                            reg[inPacket->regiser+i] &= 0xFFFF - IO_Manual_Bit;
                                          if(((inPacket->regiser + i == IO_CONTROL_REG) && (inPacket->data[i] & IO_Manual_Bit)) || (inPacket->regiser + i != IO_CONTROL_REG))
                                          {
                                            reg[inPacket->regiser+i] = inPacket->data[i];
                                            
                                            if (inPacket->regiser + i == CLEAR_FAULT)
                                            {
                                              if(reg[CLEAR_FAULT])
                                              {
                                                if (appState.powerOn && appState.fault != No_Fault && appState.fault != Driver_Current_Mismatch && !appSettings.settingModeEnable)
                                                  Drv_Power(ON); // clearing driver fault and restart motor
                                              }
                                            }
                                            if (inPacket->regiser + i == KEY_LOCKED)
                                            {
                                              if((reg[KEY_LOCKED] == 1 && appState.keyLock == OFF) || ((reg[KEY_LOCKED] == 0 && appState.keyLock == ON)))
                                                appState.keyLockTimeOut = MAX_KEY_LOCK_TIMEOUT - 1;
                                            }
                                            
                                            if (inPacket->regiser + i == ID || inPacket->regiser + i == ID + 1)
                                            {
                                              eepromWriteData(ID, (uint8_t*)&reg[ID], 4);
                                            }
                                            if (inPacket->regiser + i == IDMODEL || inPacket->regiser + i == IDMODEL + 1)
                                            {
                                              eepromWriteData(IDMODEL, (uint8_t*)&reg[IDMODEL], 4);
                                            }
                                            if (inPacket->regiser + i == POWER)
                                            {
                                              if (reg[POWER] == 0)
                                              {
                                                // set power off
                                                Drv_Power(OFF);
                                                appState.pendingOff = 1;
                                                appSettings.keyPowerPressFlag = 1;
                                              }
                                              else
                                              {
                                                // set power on
                                                Drv_Power(ON);
                                                appState.powerOn = 1;
                                                if(appState.powerRelayOn)
                                                  appState.pendingOn = 1;
                                              }
                                              appState.powerFlag = 1;
                                              reg[POWER] = appState.powerOn;
                                            }
                                            if (inPacket->regiser + i == PUMP)
                                            {
                                              DRV_PACKET packet;
                                              Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_PUMP, reg[PUMP]);
                                              reg[PUMP] = appState.pumpOn;
                                            }
                                            if (inPacket->regiser + i == PFC)
                                            {
                                              DRV_PACKET packet;
                                              Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_WRITE, DRV_REG_PFC, reg[PFC]);
                                              reg[PFC] = appState.pfcOn;
                                            }
                                            if (inPacket->regiser + i == AUTO_MODE)
                                            {
                                              appState.autoMode = reg[AUTO_MODE];
                                              if (!appState.autoMode)
                                              {
                                                appState.speedSetPoint = Drv_Calculate_Percent(); // autoSpeedSetPoint is poured in speedSetPoint
                                                eepromWriteData(AUTO_MODE, (uint8_t*)&reg[AUTO_MODE], 2);
                                                if((appState.actualSpeed && reg[MOTOR_CONTROL_MODE] == 1)||(appState.actualTorque && (reg[MOTOR_CONTROL_MODE] == 2 || reg[MOTOR_CONTROL_MODE] == 3)))
                                                  Drv_Set_Speed(appState.speedSetPoint);
                                              }
                                              else
                                              {
                                                eepromWriteData(AUTO_MODE, (uint8_t*)&reg[AUTO_MODE], 2);
                                                Set_Auto_Speed(1);
                                              }
                                            }
                                            if (inPacket->regiser + i == THERMAL_OR_COOLER_MODE)
                                            {
                                              if((reg[THERMAL_OR_COOLER_MODE] == Thermal && appState.thermalOrCoolerMode == Cooler) || (reg[THERMAL_OR_COOLER_MODE] == Cooler && appState.thermalOrCoolerMode == Thermal))
                                                appState.autoTouched = SETTING_ACTIVATION_TIME - 1;
                                            }
                                            if (inPacket->regiser + i == SPEED_SETPOINT)
                                            {
                                              if (appState.autoMode)
                                                appState.speedSetPoint = reg[SPEED_SETPOINT];
                                              else
                                              {
                                                Drv_Set_Speed(reg[SPEED_SETPOINT]);
                                                reg[SPEED_SETPOINT] = appState.speedSetPoint;
                                              }
                                            }
                                            if (inPacket->regiser + i == TEMPERATURE_SETPOINT)
                                            {
                                              appState.tempSetPoint = reg[TEMPERATURE_SETPOINT];
                                            }
  //                                                if (inPacket->regiser + i == SPEED_MIN_PERCENT)
  //						{
  //                                                  if (/*reg[SPEED_MIN_PERCENT]*/reg[SPEED_MIN_PERCENT_REG] <= (MAXIMUM_MIN_RPM_PERCENT * 10))     // less than 30%
  //                                                    appSettings.parameterConfirmedValue[SPEED_MIN_PERCENT_REG - START_OF_PARAMS] = reg[SPEED_MIN_PERCENT_REG];
  //                                                    //appState.speedMinPercent = reg[SPEED_MIN_PERCENT];
  //                                                  else
  //                                                  {
  //                                                    reg[SPEED_MIN_PERCENT_REG] = appSettings.parameterConfirmedValue[SPEED_MIN_PERCENT_REG - START_OF_PARAMS];
  //                                                    //reg[SPEED_MIN_PERCENT] = appState.speedMinPercent;
  //                                                    // respond error
  //                                                    writeFailed = 1;
  //                                                  }
  //						}
  //                                                if (inPacket->regiser + i == SPEED_MAX_PERCENT)
  //						{
  //                                                  if (/*reg[SPEED_MAX_PERCENT]*/reg[SPEED_MAX_PERCENT_REG] <= 1000 && /*reg[SPEED_MAX_PERCENT]*/ reg[SPEED_MAX_PERCENT_REG] >= (MINIMUM_MAX_RPM_PERCENT * 10))            // more than 60%
  //                                                    appSettings.parameterConfirmedValue[SPEED_MAX_PERCENT_REG - START_OF_PARAMS] = reg[SPEED_MAX_PERCENT_REG];
  //                                                    //appState.speedMaxPercent = reg[SPEED_MAX_PERCENT];
  //                                                  else
  //                                                  {
  //                                                    reg[SPEED_MAX_PERCENT_REG] = appSettings.parameterConfirmedValue[SPEED_MAX_PERCENT_REG - START_OF_PARAMS];
  //                                                    //reg[SPEED_MAX_PERCENT] = appState.speedMaxPercent;
  //                                                    // respond error
  //                                                    writeFailed = 1;
  //                                                  }
  //						}
  //                                                if (inPacket->regiser + i == SPEED_MAX_DRIVER)
  //						{
  //                                                  // todo
  //						}
  //                                                if (inPacket->regiser + i == CURRENT_MIN_PERCENT)
  //						{
  //                                                  if (reg[CURRENT_MIN_PERCENT] <= (MAXIMUM_MIN_RPM_PERCENT * 10))   // less than 30%
  //                                                    appState.currentMinPercent = reg[CURRENT_MIN_PERCENT];
  //                                                  else
  //                                                  {
  //                                                    reg[CURRENT_MIN_PERCENT] = appState.currentMinPercent;
  //                                                    // respond error
  //                                                    writeFailed = 1;
  //                                                  }
  //						}
  //                                                if (inPacket->regiser + i == CURRENT_MAX_PERCENT)
  //						{
  //                                                  if (reg[CURRENT_MAX_PERCENT] <= 1000 && reg[CURRENT_MAX_PERCENT] >= (MINIMUM_MAX_RPM_PERCENT * 10))        // more than 60%
  //                                                    appState.currentMaxPercent = reg[CURRENT_MAX_PERCENT];
  //                                                  else
  //                                                  {
  //                                                    reg[CURRENT_MAX_PERCENT] = appState.currentMaxPercent;
  //                                                    // respond error
  //                                                    writeFailed = 1;
  //                                                  }
  //						}

  //                                                if (inPacket->regiser + i == CURRENT_MAX_DRIVER)
  //						{
  //                                                  // todo
  //						}
                                            if (inPacket->regiser + i == TIME || inPacket->regiser + i == TIME + 1)
                                            {
                                              appState.nowTime = (((int32_t)reg[TIME]) << 16) + ((int32_t)reg[TIME+1]);
                                              if ((appState.nowTime - appState.dayRefTime > 86400) || (appState.nowTime - appState.dayRefTime < 0))
                                              {
                                                appState.dayRefTime = (appState.nowTime / 86400) * 86400;
                                              }
                                              // update time
                                              tm* nowTime = gmtime(&appState.nowTime);
  //                                                  nowTime->tm_wday
                                              
                                              RTC_DateStr.RTC_WeekDay = (RTC_Weekday_TypeDef)(nowTime->tm_wday % 7);       // in tm sunday is 0 but in RTC_Date it is 7
                                              RTC_DateStr.RTC_Date = nowTime->tm_mday;
                                              RTC_DateStr.RTC_Month = (RTC_Month_TypeDef)(nowTime->tm_mon + 1);
                                              RTC_DateStr.RTC_Year = nowTime->tm_year - 100;
                                              RTC_SetDate(RTC_Format_BIN, &RTC_DateStr);

                                              RTC_TimeStr.RTC_Hours   = nowTime->tm_hour;
                                              RTC_TimeStr.RTC_Minutes = nowTime->tm_min;
                                              RTC_TimeStr.RTC_Seconds = nowTime->tm_sec;
                                              RTC_SetTime(RTC_Format_BIN, &RTC_TimeStr);
                                            }
                                            if (inPacket->regiser + i == DAY_W_DATE)
                                            {
                                              appState.weekActiveDays = lowByte(reg[DAY_W_DATE]);
                                            }
                                            if (inPacket->regiser + i == TIME_W_ON || inPacket->regiser + i == TIME_W_ON + 1)
                                            {
                                              appState.weekTimeOn = (((int32_t)reg[TIME_W_ON]) << 16) + ((int32_t)reg[TIME_W_ON+1]);
                                              if (appState.weekTimeOn < 0 || appState.weekTimeOn > 86400)
                                                appState.weekTimeOn = appState.weekTimeOn % 86400;
                                            }
                                            if (inPacket->regiser + i == TIME_W_OFF || inPacket->regiser + i == TIME_W_OFF + 1)
                                            {
                                              appState.weekTimeOff = (((int32_t)reg[TIME_W_OFF]) << 16) + ((int32_t)reg[TIME_W_OFF+1]);
                                              if (appState.weekTimeOff < 0 || appState.weekTimeOff > 86400)
                                                appState.weekTimeOff = appState.weekTimeOff % 86400;
                                            }
                                            if (inPacket->regiser + i == TIME_D_ON || inPacket->regiser + i == TIME_D_ON + 1)
                                            {
                                              appState.dayTimeOn = (((int32_t)reg[TIME_D_ON]) << 16) + ((int32_t)reg[TIME_D_ON+1]);
                                            }
                                            if (inPacket->regiser + i == TIME_D_OFF || inPacket->regiser + i == TIME_D_OFF + 1)
                                            {
                                              appState.dayTimeOff = (((int32_t)reg[TIME_D_OFF]) << 16) + ((int32_t)reg[TIME_D_OFF+1]);
                                            }
                                            
                                            if((inPacket->regiser + i >= START_OF_PARAMS) && (inPacket->regiser + i <= END_OF_PARAMS - 1))
                                            {
                                              appSettings.parameterValue[inPacket->regiser + i - 35] = reg[inPacket->regiser + i];
                                              appSettings.currentParameter = inPacket->regiser + i - 35;
                                              Parameter_Change_Operation();
                                              appSettings.currentParameter = 1;
                                            }
                                            if(inPacket->regiser + i == IO_CONTROL_REG)
                                            {
//                                              if(reg[IO_CONTROL_REG] & IO_BACKLIGHT) //IO_BACKLIGHT
//                                                CMDs_PWR(CMD_BL, ON);
//                                              else
//                                                CMDs_PWR(CMD_BL, OFF);
//                                              if(reg[IO_CONTROL_REG] & IO_RF_KEY) //IO_RF_KEY
//                                                CMDs_PWR(CMD_RF_KEY, ON);
//                                              else
//                                                CMDs_PWR(CMD_RF_KEY, OFF);
//                                              if(reg[IO_CONTROL_REG] & IO_SIG_RELAY) //IO_SIG_RELAY
//                                                CMDs_PWR(CMD_REL_SIG, ON);
//                                              else
//                                                CMDs_PWR(CMD_REL_SIG, OFF); 
////                                              if(reg[IO_CONTROL_REG] & IO_USART_DIR) //IO_USART_DIR
////                                              {}
//                                              if(reg[IO_CONTROL_REG] & IO_POW_RELAY) //IO_POW_RELAY
//                                                CMDs_PWR(CMD_REL_PWR, ON);
//                                              else
//                                                CMDs_PWR(CMD_REL_PWR, OFF);
//                                              if(reg[IO_CONTROL_REG] & IO_CMD_CLK) //IO_CMD_CLK
//                                                CMDs_PWR(CMD_CLK, ON);
//                                              else
//                                                CMDs_PWR(CMD_CLK, OFF);
                                              CMDs_PWR_Mannual(0x3F & reg[IO_CONTROL_REG]);
                                              
                                              if(reg[IO_CONTROL_REG] & IO_ALL_LCD_FIGS_ON) //IO_ALL_LCD_FIGS_ON
                                                LCD_Glass_Play_All();
                                              if(reg[IO_CONTROL_REG] & IO_ALL_LCD_FIGS_OFF) //IO_ALL_LCD_FIGS_OFF
                                                LCD_Glass_Off_All();
                                            }
                                          }
                                          else
                                            writeFailed = 1;
                                          
                                          writeNum++;
                                          
                                          if (writeFailed)
                                            packData[0] = writeError;
                                          else
                                            packData[0] = writeOK;
                                          
                                          fillGeneratePacket(outPacket, WRITEOK, inPacket->regiser, writeNum, packData);
                                        }
				}
			}
			else
			{
				packData[0] = writeError;
				fillGeneratePacket(outPacket, WRITEOK, inPacket->regiser, writeNum, packData);
			}
		}
	}
}


//unsigned char lowByte(unsigned short int number)
//{
//	unsigned short int ustemp = 0;
//	unsigned char output;
//	ustemp = number & 0xFF;
//	output = ustemp;
//	return output;
//}
//
//
//unsigned char highByte(unsigned short int number)
//{
//	unsigned short int ustemp = 0;
//	unsigned char output;
//	ustemp = number & 0xFF00;
//	ustemp >>= 8;
//	output = ustemp;
//	return output;
//}


//unsigned short halfWord(unsigned char *byte_array, unsigned char first_index, unsigned char order)
//{
//	unsigned short halfword = 0;
//	if (order == LSB_FIRST)
//		halfword = ((unsigned short)byte_array[first_index+1] << 8) + byte_array[first_index];
//	else if (order == MSB_FIRST)
//		halfword = ((unsigned short)byte_array[first_index+1] << 8) + byte_array[first_index];
//
//	return halfword;
//}
//
//
//unsigned int word(unsigned char *byte_array, unsigned char first_index, unsigned char order)
//{
//	unsigned char i;
//	unsigned int word = 0;
//	if (order == LSB_FIRST)
//	{
//		for(i=3;i>0;i--)
//		{
//			word += byte_array[first_index+i];
//			word <<= 8;
//		}
//		word += byte_array[first_index];
//	}
//	else if (order == MSB_FIRST)
//	{
//		for(i=0;i<3;i++)
//		{
//			word += byte_array[first_index+i];
//			word <<= 8;
//		}
//		word += byte_array[first_index+3];
//	}
//
//	return word;
//}

/**
  * @brief  this function fill packet which is going to be sent to the target device
  * @param  returns 0 if the regnum is within the allowed amount and returns 1 if not   packet: an instnace of communication packet    command: the command to be written in packet   reg: the start register of target device for data to be written in    numReg: number of registers that data will embedded in     data:data which is gonna be written in device registers
  * @retval None
  */
unsigned char fillGeneratePacket(PACKET* packet, unsigned short command, unsigned short reg, unsigned short numReg, unsigned short* data)
{
	unsigned short i;
	if(numReg < maxDataPacketLength)
	{
		packet->address = boardAddress;
		packet->command = command;
		packet->regiser = reg;
		packet->numReg = numReg;
		if(packet->data != data)
		{
			for(i=0;i<numReg;i++)
			{
				packet->data[i] = data[i];
			}
		}
		generatePacket(packet);
		return 0;
	}
	return 1;
}

uint8_t* getIdModelChanged()
{
  return &idModelChanged;
}