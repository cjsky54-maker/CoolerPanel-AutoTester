/**
******************************************************************************
* @file    Project/STM8L15x_StdPeriph_Template/stm8l15x_it.c
* @author  MCD Application Team
* @version V1.6.1
* @date    30-September-2014
* @brief   Main Interrupt Service Routines.
*          This file provides template for all peripherals interrupt service routine.
******************************************************************************
* @attention
*
* <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
*
* Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
* You may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*        http://www.st.com/software_license_agreement_liberty_v2
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the License is distributed on an "AS IS" BASIS, 
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "stm8l15x_it.h"
#include "initialization.h"
#include "bs818a_2.h"
#include "lcd_seg.h"
#include "adc_reading.h"
#include "business_logic.h"
#include "math.h"
#include "driver_protocol.h"
#include "bluetooth.h"
#include "protocol.h"
#include "functions.h"
#include "stdio.h"
#include "variables.h"
#include "lcd_seg.h"
#include "ask_decoder.h"
//#include "string.h" 

/** @addtogroup STM8L15x_StdPeriph_Template
* @{
*/

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
//char hello[] = {"Salam!"};
unsigned char data1, data2, RF_OUT, cnt2 = 0, RF_RCV_SIG=0, cnt3=0, anyKeyOnRemote=0 , sigIndex = 0, sigValue[30], ASK_StartPeriod = 0, adcReadDelay = 0;
unsigned short sigDuty[30], sigPeriod[30];
uint32_t sigTot = 0;
float sigPWM[30];

//unsigned char keyTocuhCor[7] = {KEY_DOWN, KEY_UP, KEY_CLOCK, KEY_POWER, KEY_WATER, KEY_AUTO, KEY_SETTINGS};
ADC_READING adcReading = {.acVoltageInRangeTimerCounter = MAX_AC_VOLTAGE_IN_RANGE_TIMER_COUNTER - 1, .acVoltageInRange = 1};
BS818A_2 bs818;
PACKET pckt6;
ASK_PACKET askPacket;


//extern ADC_READING adcReading;
//extern BS818A_2 bs818;
//extern LCD_GLASS lcdGlass;
//extern uint16_t ADC1ConvertedValue[ADC1_BUF_LEN];
//extern App_State appState;
//extern unsigned char lcdIsInStandby, lcdStandByTimer;
//extern uint8_t queueCommandCnt;

//extern uint8_t settingsTouched;
//extern App_Settings appSettings;

//extern uint8_t Rx1Buffer[8];

//BLUETOOTH_STATUS btStatus = {.resetMode = 0, .isDxBt24 = 0, .versionRead = 0};
//unsigned char respBtAtFlag = 0, respWfAtFlag = 0;


//extern RTC_TimeTypeDef   RTC_TimeStr;
//extern RTC_DateTypeDef   RTC_DateStr;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/

#ifdef _COSMIC_
/**
  * @brief Dummy interrupt routine
  * @par Parameters:
  * None
  * @retval 
  * None
  */
INTERRUPT_HANDLER(NonHandledInterrupt,0)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}
#endif

/**
  * @brief TRAP interrupt routine
  * @par Parameters:
  * None
  * @retval 
  * None
  */
INTERRUPT_HANDLER_TRAP(TRAP_IRQHandler)
{
  /* In order to detect unexpected events during development,
  	 it is recommended to set a breakpoint on the following instruction.
  */
}
/**
  * @brief FLASH Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(FLASH_IRQHandler,1)
{
  /* In order to detect unexpected events during development,
  	 it is recommended to set a breakpoint on the following instruction.
  */
}
/**
  * @brief DMA1 channel0 and channel1 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(DMA1_CHANNEL0_1_IRQHandler,2)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  USART_ITConfig(USART1, USART_IT_TC, ENABLE);
  
  DMA_ClearFlag(DMA1_FLAG_TC1);
  DMA_ClearITPendingBit(DMA1_IT_TC1);
}
/**
  * @brief DMA1 channel2 and channel3 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(DMA1_CHANNEL2_3_IRQHandler,3)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  
  ////  UART_Send(2, Rx1Buffer, 8);
  
  TIM3_SetCounter(0);
  //  for (int i = 0; i < 8; i++)
  //  {
  //    Driver_Receive_Byte(Rx1Buffer[i]);
  //  }
  //  Driver_Finish_Message();
  
  Drv_Response_Received(getRx1BufferPointer());
  //  Drv_Activity_Timeout();
  
  DMA_ClearFlag(DMA1_FLAG_TC2);
}
/**
  * @brief RTC / CSS_LSE Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(RTC_CSSLSE_IRQHandler,4)
{
  /* In order to detect unexpected events during development,
 	 it is recommended to set a breakpoint on the following instruction.
  */
  
  //  UART_Send(2, "triggered\r\n", 11);
    RTC_ClearITPendingBit(RTC_IT_ALRA);
//    CSSLSE->CSR &= !CSSLSE_CSR_CSSF;
  
}
/**
  * @brief External IT PORTE/F and PVD Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTIE_F_PVD_IRQHandler,5)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief External IT PORTB / PORTG Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTIB_G_IRQHandler,6)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief External IT PORTD /PORTH Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTID_H_IRQHandler,7)
{
  /* In order to detect unexpected events during development,
  	 it is recommended to set a breakpoint on the following instruction.
  */
}

/**
  * @brief External IT PIN0 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI0_IRQHandler,8)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  /* Cleat Interrupt pending bit */
  //BS818A_2_Read(&bs818);
  
  //if (bs818.error == BS_ERROR_NO)
  //  Perform_Touch_Operations(bs818.touchs, bs818.pressedNum > 0);
  /*  
  for(i=0;i<7;i++)
  {
    if(bs818.touchs[i] == PRESSED)
    {
      if(lcdGlass.figs[keyTocuhCor[i]] == ON)
        state = OFF;
      else
        state = ON;
      LCD_GLASS_Update_Fig_Struct(keyTocuhCor[i], state);
    }
  }
  */
  EXTI_ClearITPendingBit(EXTI_IT_Pin0);
}

/**
  * @brief External IT PIN1 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI1_IRQHandler,9)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN2 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI2_IRQHandler,10)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN3 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI3_IRQHandler,11)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  Drv_LifeGuard_Action();
  EXTI_ClearITPendingBit(EXTI_IT_Pin3);
}

/**
  * @brief External IT PIN4 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI4_IRQHandler,12)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
#if RF_MDL_TYPE == RXC6
//  if(reg[REMOTE_CLEAR])
//  {
  delay_ms(1);
  RF_OUT = GPIO_ReadInputData(GPIOG) & 0xF;
  reg[RF_KEY] = RF_OUT;
  RF_RCV_SIG = GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_4);
  //RF_OUT1 = GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_0);
  //RF_OUT2 = GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_1);
  //RF_OUT3 = GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_2);
  //RF_OUT4 = GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_3);
  //RF_OUT = RF_OUT1 + (RF_OUT2 << 1) + (RF_OUT3 << 2) + (RF_OUT4 << 3);
  //uint8_t RF_OUT2 = RF_OUT1 + (RF_OUT2 << 1) + (RF_OUT3 << 2) + (RF_OUT4 << 3);
  RF_OUT = ((RF_OUT & 0x1) << 3) | ((RF_OUT & 0x2) << 1) | ((RF_OUT & 0x4) >> 1) | ((RF_OUT & 0x8) >> 3); //reverse data bits
  Perform_Remote_Operations(RF_OUT);
  LCD_Glass_Update_By_State();
  if(RF_RCV_SIG)
  {
    anyKeyOnRemote = PRESSED;
    Buzzer_Operation(Remote);
    setLcdIsInStandby(0);
    setLcdStandByTimer(0);
    LCD_DeadTimeConfig(LCD_GLASS_Normal_Contrast());
  }
  else
  {
    anyKeyOnRemote = RELEASED;
    cnt3=0;
  }
//  }
  EXTI_ClearITPendingBit(EXTI_IT_Pin4);
#endif
}

/**
  * @brief External IT PIN5 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI5_IRQHandler,13)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief External IT PIN6 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI6_IRQHandler,14)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */

//  EXTI_ClearITPendingBit(EXTI_IT_Pin6);
}

/**
  * @brief External IT PIN7 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(EXTI7_IRQHandler,15)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  BS818A_2_Read(&bs818);
  if((bs818.error == BS_ERROR_NO) && !(reg[IO_CONTROL_REG] & IO_Manual_Bit))
    Perform_Touch_Operations(bs818.touchs, bs818.pressedNum);
  EXTI_ClearITPendingBit(EXTI_IT_Pin7);
}
/**
  * @brief LCD /AES Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(LCD_AES_IRQHandler,16)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  LCD_GLASS_Update();
  LCD_ClearITPendingBit();
}
/**
  * @brief CLK switch/CSS/TIM1 break Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(SWITCH_CSS_BREAK_DAC_IRQHandler,17)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}

/**
  * @brief ADC1/Comparator Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(ADC1_COMP_IRQHandler,18)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  if(ADC_GetITStatus(ADC1,ADC_IT_OVER) != RESET)
  {
    DMA_Reconfig(DMA1_Channel0);   
    ADC_ClearITPendingBit(ADC1, ADC_IT_OVER);
  }
}

/**
  * @brief TIM2 Update/Overflow/Trigger/Break /USART2 TX Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM2_UPD_OVF_TRG_BRK_USART2_TX_IRQHandler,19)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  App_State* appstate = getAppState();
  if(TIM2_GetITStatus(TIM2_IT_Update) != RESET)
  {
    cnt2++;
    
    // ADC read and average and relative register set
    if(adcReadDelay > 2) //2*250ms = 0.5s delay
    {
      adc1AveragingBuffer(getADC1ConvertedValue(), &adcReading, AC_VOLTAGE);
      calculateAdcValues(&adcReading, AC_VOLTAGE);
      Drv_AcInRange_Check();
      adc1AveragingBuffer(getADC1ConvertedValue(), &adcReading, OW_VOLTAGE);
      calculateAdcValues(&adcReading, OW_VOLTAGE);
    }
    else
      adcReadDelay ++;
    Drv_Set_oneWirePhysicallyConnected(adcReading.owLineConnected);
    Drv_Set_acVoltageInRange(adcReading.acVoltageInRange);
    
    if(cnt2 == 1/* || cnt2 == 3*/)
    {
      if(reg[FIRST_BOOT_FLAG_AFTER_POWERON])
      {
//        appstate->powerOn = 0;
//        reg[POWER] = 0;
//        appstate->pendingOff = 0;
//        appstate->timerChangingTimeout = 0;
//        appstate->dayTimeOff = -1;
//        CMDs_PWR(CMD_REL_PWR, OFF);
//        appstate->powerRelayOn = 0x00;
          
        Drv_Power(ON);
        appstate->powerOn = 1;
        reg[POWER] = 1;
        if(appstate->powerRelayOn)
          appstate->pendingOn = 1;  
      }
 
//      //// bluetooth config
//      BT_CheckConnection();
////      BT_CheckResponse();
//      BT_ChangeName(getIdModelChanged());
//      BT_ResetOperations();
//      appstate->bleConnected = BT_GetConnectionStatus();
//      
//      
//      timeoutReception(&pckt6, 4);
    }
    if(cnt2 == 1)
    {
      Making_Date_And_Time();
      
      
      Set_Auto_Speed(0);
      Check_Timer();
      if(!Drv_Get_Queue_Command_Cnt() && appstate->powerOn && appstate->powerRelayOn)
      {
        Check_Fault();
        if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 1)
          Check_Drv_Temp();
        else if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 2)
          Check_Drv_Status();
        else if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 3)
          Check_Drv_Dc_Bus_Voltage();
      }
      Check_Settings_Operations();
      LEDs_PWR(ON);
      
        
      //// locking Keys TimeOut ////
      LockingLcdTimeoutCounter();
      LCD_GLASS_UPDATE_STANDBY();
      LCD_Glass_Update_By_State();
      
      startLearnTimeoutCounter();
      
      Receive_Packet_Accuracy_Calculation();
      
      Valve_Operation_TimeOut();
    }
    else if(cnt2 == 2)
    {
      if(reg[ENV_OR_DRIVER_TEMP_SHOW] == 0)
      {
        adc1AveragingBuffer(getADC1ConvertedValue(), &adcReading, TEMP);
        calculateAdcValues(&adcReading, TEMP);
        
        if (appstate->actualTemp  == 0)
          appstate->actualTemp = adcReading.temp ;
        appstate->actualTemp = appstate->actualTemp * 0.8 + adcReading.temp * 0.2 + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0);
        
        tempOffsetGenerator();
        appstate->showableTemp = appstate->actualTemp + (((float)reg[temp_calibration_setpoint] - 50.0)/10.0) - appstate->tempOffset;
        
        reg[TEMPERATURE] = (uint16_t)(appstate->showableTemp * 1000);
      }
    }
    else if(cnt2 == 3)
    {
      /////////////////////////
      if(appstate->timerChangingTimeout)
      {
        LCD_GLASS_Update_SevenSeg_Struct(0, 10);
        LCD_GLASS_SET_changesCompleted(1);
      }
      /*if (appstate->speedMaxChangingTimeout || appstate->speedMinChangingTimeout)
      {
      LCD_GLASS_Update_SevenSeg_Struct(4, 10);
      LCD_GLASS_Update_SevenSeg_Struct(5, 10);
      LCD_GLASS_Update_Fig_Struct(FIG_POINT_SMALL, DISABLE);
    }*/
      ///////////////////// app setting /////////////////////
      LCD_GLASS_UPDATE_SETTING_PAGE();
      ///////////////////////////////////////////////////////
      
      /////reading driver ntc temp(sending coressponding command)
//      if((reg[ENV_OR_DRIVER_TEMP_SHOW] == 1) && !Drv_Get_Queue_Command_Cnt())
//      {
//        DRV_PACKET packet;
//        Drv_Fill_Generate_Send_Packet(&packet, DRV_CMD_READ, DRV_REG_VTH, 0x0000);
//      }
        
      
      ////////// checking infineon pump reg
      //      if (zaman <= 12)
      //        zaman++;
      //      else if(!Drv_Get_Queue_Command_Cnt())
      //      {
      //        uint8_t pumpreg[8] = {0x01, 0x05, addressTable[PUMP_CMD][reg[IMC_CODE_VERSION]][APP_ID], addressTable[PUMP_CMD][reg[IMC_CODE_VERSION]][REGISTER_INDEX], 0x00, 0x00};
      //        uint8_t crc32 = Drv_Get_CRC(pumpreg);
      //        pumpreg[6] = highByte(crc32);
      //        pumpreg[7] = lowByte(crc32);
      //        Send_Command(pumpreg);
      //      }
      
    }
    else if(cnt2 == 4)
    {
      cnt2 = 0;
      LEDs_PWR(OFF);
      //      UART_Send(3, hello, 6);
    }
    TIM2_ClearITPendingBit(TIM2_IT_Update);
  }
}

/**
  * @brief Timer2 Capture/Compare / USART2 RX Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM2_CC_USART2_RX_IRQHandler,20)
{
  /* In order to detect unexpected events during development,
     it is recommended to set a breakpoint on the following instruction.
  */
  if( (USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET) )// (USART_GetFlagStatus(USART2, USART_FLAG_OR) != RESET) )
  {
    unsigned char rcvFlag6,err6;
    data2 = USART_ReceiveData8(USART2);
    pckt6.buffer[pckt6.index] = data2;
    rcvFlag6 = receivePacket(&pckt6);
    // receive our packet
    if(rcvFlag6 == 1)
    {
      //UART_Send(2,"rcvFlag6 == 1\r\n",15);
      rcvFlag6 = 0;
      err6 = analysePacket(&pckt6);
      // if there is no error in received packet, response to it
      if(err6 == 0)
      {
        PACKET outPckt6;
        executePacket(&pckt6, &outPckt6);
        //                  UART_Send_DMA(6, outPckt6.buffer, outPckt6.length);
        UART_Send(2, outPckt6.buffer, outPckt6.length);
      }
    }
  }

  TIM2_ClearITPendingBit(TIM2_IT_Update);
}


/**
  * @brief Timer3 Update/Overflow/Trigger/Break Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM3_UPD_OVF_TRG_BRK_USART3_TX_IRQHandler,21)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(TIM3_GetITStatus(TIM3_IT_Update) != RESET)
  {
    Buzzer_TimeOut();
#if RF_MDL_TYPE == RXC6
    if(anyKeyOnRemote && cnt3 < 100)
      cnt3++;
    if((cnt3 == 100) && (RF_OUT == REMOTE_UP_CODE || RF_OUT == REMOTE_DOWN_CODE))
    {
      Perform_Remote_Operations(RF_OUT);
      LCD_Glass_Update_By_State();
      cnt3 -= 25;
    }
#endif
    
    Perform_Continues_Key_Press();
      
    Drv_Start_Activity_Timeout();
    Drv_Activity_Timeout();
        
    //// valve startUp ////
    Valve_OR_TermalMode_TurningOn_TimeOut();
    
    //// setting startUp ////
    SettingStartUpTimeoutCounter();
    
    //    DMA_Cmd(DMA1_Channel2, DISABLE);
    //    DMA_SetCurrDataCounter(DMA1_Channel2, 8);
    //    DMA_ClearFlag(DMA1_FLAG_TC2);
    //    DMA_Cmd(DMA1_Channel2, ENABLE);
    KeyBlinkTimeOut();
    Clear_Clock_TimeOut();
    ASK_Perform_Remote_Operations(&askPacket);
    TIM3_ClearITPendingBit(TIM3_IT_Update);
  }
}

//uint8_t cc = 0;
/**
  * @brief Timer3 Capture/Compare /USART3 RX Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM3_CC_USART3_RX_IRQHandler,22)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  
  if (USART_GetFlagStatus(USART3, USART_FLAG_RXNE) != RESET)
  {
    unsigned char data3 = USART_ReceiveData8(USART3);
//    unsigned char respBtAtFlag, err6, rcvFlag6;
//    
//    if(BT_GetSendingAtCmd() == 0)
//    {
//      pckt6.buffer[pckt6.index] = data3;
//      rcvFlag6 = receivePacket(&pckt6);
//      //UART_Send(2,(const char*)&rcvFlag6,1);
//    }
//    else if(BT_GetSendingAtCmd() == 1)
//    {
//      respBtAtFlag = BT_RecieveAtResponse(data3);
//    }
//    
//    // receive our packet
//    if(rcvFlag6 == 1)
//    {
//      //UART_Send(2,"rcvFlag6 == 1\r\n",15);
//      rcvFlag6 = 0;
//      if (BT_GetConnectionStatus() == DISCONNECTED)//(btRespFlag==0)
//      {
//        BT_SetConnectionStatus(CONNECTED);
//        setAppStateBleConnected(1);
//      }
//      BT_ResetConnectionTimeout();
//      err6 = analysePacket(&pckt6);
//      // if there is no error in received packet, response to it
//      if(err6 == 0)
//      {
//        PACKET outPckt6;
//        executePacket(&pckt6, &outPckt6);
//        //                  UART_Send_DMA(6, outPckt6.buffer, outPckt6.length);
//        //UART_Send(3, outPckt6.buffer, outPckt6.length);
//      }
//      // this is for bootloader commands
//      //          else
//      //          {
//      //                  errorStat.errorSource = err6;
//      //                  errorStat.errorDetails = 0;
//      //                  fillGenerateAckPacket(&outPckt6, 0, errorStat);
//      ////                  UART_Send_DMA(6, outPckt6.buffer, outPckt6.length);
//      //                  UART_Send(3, outPckt6.buffer, outPckt6.length);
//      ////                  sprintf(pucBuffer, "Fault occurred on analysing bluetooth packet with error code: %d", err6);
//      ////                  Send_Log(pucBuffer, ERROR_LOG, BT_SRC);
//      //          }
//    }
//    // receive AT response (OK...)
//    else if(rcvFlag6 == 2)
//    {
//      rcvFlag6 = 0;
//      BT_ExtractCmd(pckt6.buffer);
//      setAppStateBleConnected(BT_GetConnectionStatus());        
//      Buzzer_Play(10);
//    }
//    
//    // receive other AT responses
//    if(respBtAtFlag == 1)
//    {
//      respBtAtFlag = 0;
//      BT_ExtractCmd(BT_GetRespBuffer());
//    }
  }
}
/**
  * @brief TIM1 Update/Overflow/Trigger/Commutation Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM1_UPD_OVF_TRG_COM_IRQHandler,23)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(TIM1_GetITStatus(TIM1_IT_Update) != RESET)
  {
#if RF_MDL_TYPE == CY41
//    sigIndex = 0;
//    sigTot = 0;
//    TIM1_ITConfig(TIM1_IT_CC2, ENABLE);
    ASK_StartReception(&askPacket);
#endif
    TIM1_ClearITPendingBit(TIM1_IT_Update);
  }
}


/**
  * @brief TIM1 Capture/Compare Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM1_CC_IRQHandler,24)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  if(TIM1_GetITStatus(TIM1_IT_CC2) != RESET)
  {
#if RF_MDL_TYPE == CY41
    ASK_HandleReception(&askPacket);
#endif
  }
}

/**
  * @brief TIM4 Update/Overflow/Trigger Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(TIM4_UPD_OVF_TRG_IRQHandler,25)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}
/**
  * @brief SPI1 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(SPI1_IRQHandler,26)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */		
}

/**
  * @brief USART1 TX / TIM5 Update/Overflow/Trigger/Break Interrupt  routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(USART1_TX_TIM5_UPD_OVF_TRG_BRK_IRQHandler,27)
{
  /* In order to detect unexpected events during development,
  it is recommended to set a breakpoint on the following instruction.
  */
  if(USART_GetITStatus(USART1, USART_IT_TC) != RESET)
  {
    // Changing Direction of Onewire to Input
    CMDs_PWR(CMD_USART_DIR, DIR_RX); 
    
    USART_ClearFlag(USART1, USART_FLAG_TC);
    USART_ClearITPendingBit(USART1, USART_IT_TC);
    USART_ITConfig(USART1, USART_IT_TC, DISABLE);
  }
}

/**
  * @brief USART1 RX / Timer5 Capture/Compare Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(USART1_RX_TIM5_CC_IRQHandler,28)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
  data1 = USART_ReceiveData8(USART1);
  
  //  Driver_Receive_Byte(data1);
  //  TIM3_SetCounter(0);
  //  UART_Send(2, &data1, 1);
  //  volatile uint8_t sr = USART2->SR;
  //  USART_SendData8(USART2, data1);
  //  USART_ClearFlag(USART1, USART_FLAG_RXNE);
  //  TIM5_ClearFlag(TIM5_FLAG_CC1 | TIM5_FLAG_CC2);
}

/**
  * @brief I2C1 / SPI2 Interrupt routine.
  * @param  None
  * @retval None
  */
INTERRUPT_HANDLER(I2C1_SPI2_IRQHandler,29)
{
    /* In order to detect unexpected events during development,
       it is recommended to set a breakpoint on the following instruction.
    */
}


/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/